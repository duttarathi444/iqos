<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Lending_received extends CI_Controller {
    
    protected $access;
	protected $access2;
    
    public function __construct()
    {
        parent::__construct();
		$this->load->model('user');
        $this->load->library('session');
        $this->load->helper('url');
        
        $data['secure_id']=$_GET['a'];
        $this->access=$data['secure_id'];
        $data['check_valid']=$this->token_valid($data['secure_id']);
	    if($data['check_valid'][0]['id']!=1){
	        $this->load->view('product_module');
	    }
		
		if($this->session->userdata('email_id') == TRUE)
		{
			
			$data['email_id'] = $this->session->userdata('email_id');
			$this->access2=$data['email_id'];
		}
		else
        {
            $data['s_out'] = 'Session Expired..';
            $this->load->view('login',$data);
        }
        
    }
    
    public function token_valid($b){
	    $this->load->model('Menu2_model');
		$data['role_id'] = $this->session->userdata('role_id');
		$data['user_id'] = $this->session->userdata('user_id');
	    $data['enter_code']=$b-128;
	    //$data['user_id']=1;
	    $data['valid_token']=$this->Menu2_model->token_valid_data($data);
	        return $data['valid_token'];
	}
    
    public function lend_back_master()
	{	
		$data['email_id']=$this->access2;
		$data['role_id'] = $this->session->userdata('role_id');
		$data['user_id'] = $this->session->userdata('user_id');
        $this->load->model('Lending_back_model');
        //$data['user_id']=1;
        $data['secure_code']=$this->access;
        $data['lend_back_details']=$this->Lending_back_model->all_lend_back_data($data);
        $this->load->view('lend_back_master_view',$data);
    }
    
    public function lend_product_back(){
		$data['role_id'] = $this->session->userdata('role_id');
		$data['user_id'] = $this->session->userdata('user_id');
		$data['email_id']=$this->access2;
        $this->load->model('Lending_back_model');
        $data['head_id']=$_POST['head_id'];
        //$data['user_id']=1;
        $data['secure_code']=$this->access;
        $data['lend_back_data']=$this->Lending_back_model->product_lend_back_by_id($data);
        $this->load->view('lend_back_product',$data);
    }
    
    public function lend_back_data(){
		$data['email_id']=$this->access2;
        $this->load->model('Lending_back_model');
		$data['role_id'] = $this->session->userdata('role_id');
		$data['user_id'] = $this->session->userdata('user_id');
        $data['header_id']=$_POST['header_id'];
        $data['products_id']=$_POST['al-products'];
        $data['quantities']=$_POST['al-quantities'];
        $data['return_dates']=$_POST['al-return_date'];
        $data['ex-return_dates']=$_POST['ex-return_date'];
        //$data['user_id']=1;
        $data['secure_code']=$this->access;
        $data['lend_back_submit']=$this->Lending_back_model->lend_back_data_submit($data);
            $data['alert_flag'] = 1;
			$data['alert_message'] = "Lend Received data has been added successfully";
            $data['lend_back_details']=$this->Lending_back_model->all_lend_back_data($data);
			$data['key_id'] = $data['header_id'];
			$data['activity_id'] = 2;
			$data['page_id'] = 13;
			$data['module_id'] = 13;
			$this->load->model('Admin_model');
			$this->Admin_model->bye_user_log($data);
            $this->load->view('lend_back_master_view',$data);
    }
    
    public function view_lend_back_details(){
		$data['role_id'] = $this->session->userdata('role_id');
		$data['user_id'] = $this->session->userdata('user_id');
		$data['email_id']=$this->access2;
        $this->load->model('Lending_back_model');
        $data['head_id']=$_POST['head_id'];
        //$data['user_id']=1;
        $data['all_lend_back']=$this->Lending_back_model->land_back_view_by_id($data);
        $data['secure_code']=$this->access;
		$data['key_id'] = $data['head_id'];
		$data['activity_id'] = 4;
		$data['page_id'] = 13;
		$data['module_id'] = 13;
		$this->load->model('Admin_model');
		$this->Admin_model->bye_user_log($data);
        $this->load->view('view_all_lend_back',$data);
    }
    
    // public function land_back_edit(){
    //     $this->load->model('Lending_back_model');
    //     $data['head_id']=$_POST['head_id3'];
    //     $data['user_id']=1;
    //     $data['total_data']=$this->Lending_back_model->lend_back_data_total($data);
    //     $data['lend_back_edit_data']=$this->Lending_back_model->lend_back_edit_data($data);
    //     $this->load->view('lend_back_product_edit',$data);
    // }
    
    public function Lend_back_delete(){
		$data['role_id'] = $this->session->userdata('role_id');
		$data['user_id'] = $this->session->userdata('user_id');
		$data['email_id']=$this->access2;
        $this->load->model('Lending_back_model');
        $data['head_id']=$_POST['head_id4'];
        //$data['user_id']=1;
        $data['all_lend_back']=$this->Lending_back_model->Lend_back_delete_by_id($data);
        $data['secure_code']=$this->access;
        $data['alert_flag'] = 1;
			$data['alert_message'] = "Lend Received data has been Delete successfully";
        $data['lend_back_details']=$this->Lending_back_model->all_lend_back_data($data);
		$data['key_id'] = $data['head_id'];
		$data['activity_id'] = 3;
		$data['page_id'] = 13;
		$data['module_id'] = 13;
		$this->load->model('Admin_model');
		$this->Admin_model->bye_user_log($data);
        $this->load->view('lend_back_master_view',$data);
    }
    
    public function lending_report(){
		$data['email_id']=$this->access2;
		$data['role_id'] = $this->session->userdata('role_id');
		$data['user_id'] = $this->session->userdata('user_id');
        //$data['user_id']=1;
        $data['secure_code']=$this->access;
        $this->load->model('Report_model');
		$data['product_data'] = $this->Report_model->product_stock_movement_data();
        $this->load->view('lending_report_view',$data);
    }
    
    public function lending_report_data(){
		$data['email_id']=$this->access2;
		$data['role_id'] = $this->session->userdata('role_id');
		$data['user_id'] = $this->session->userdata('user_id');
        $this->load->model('Lending_back_model');
        $this->load->model('Report_model');
        $data['secure_code']=$this->access;
        $data['lend_item']=$_POST['lend_item'];
        $data['items']=$_POST['items'];
        $data['from_date']=$_POST['from_date'];
        $data['to_date']=$_POST['to_date'];
        //$data['user_id']=1;
        $data['product_data'] = $this->Report_model->product_stock_movement_data();
        $data['all_lend_data']=$this->Lending_back_model->lending_report_data($data);
        $this->load->view('all_lending_report',$data);
    }
    
}