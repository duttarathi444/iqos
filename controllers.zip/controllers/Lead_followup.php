<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Lead_followup extends CI_Controller {
    
    public $access;
    
    public function __construct()
    {
        parent::__construct();
		$this->load->model('user');
        $this->load->library('session');
        $this->load->helper('url');
		if($this->session->userdata('email_id') == TRUE)
		{
			
			$data['email_id'] = $this->session->userdata('email_id');
			$this->access=$data['email_id'];
		}
		else
		{
			$data['s_out'] = 'Session Expired..';
			$this->load->view('login',$data);
		}
        
   
        
    }
    
//     public function token_valid($b){
// 	    $this->load->model('Menu2_model');
// 	    $data['enter_code']=$b-128;
// 	    $data['user_id']=1;
// 	    $data['valid_token']=$this->Menu2_model->token_valid_data($data);
// 	        return $data['valid_token'];
// 	}
    
    public function lead_followup_master()
	{
		$data['email_id']=$this->access;
		$data['role_id'] = $this->session->userdata('role_id');
		$data['user_id'] = $this->session->userdata('user_id');
        $this->load->model('Lead_followup_model');
        // $data['secure_code']=$this->access;
        //$data['user_id']=1;
        $data['all_lead'] = $this->Lead_followup_model->all_lead_show($data);
        $this->load->view('lead_follow_master',$data);
    }
    
    public function lead_add()
	{
		$data['email_id']=$this->access;
		$data['role_id'] = $this->session->userdata('role_id');
		$data['user_id'] = $this->session->userdata('user_id');
        // $data['secure_code']=$this->access;
        $this->load->view('lead_follow_add',$data);
    }
    
    public function lead_data_add()
	{
		$data['email_id']=$this->access;
		$data['role_id'] = $this->session->userdata('role_id');
		$data['user_id'] = $this->session->userdata('user_id');
        $data['lead_month'] =$_POST['lead_month'];
        $data['lead_year'] =$_POST['lead_year'];
        $data['lead_date'] =$_POST['lead_date'];
        $data['lead_name'] =$_POST['lead_name'];
        $data['lead_mail'] =$_POST['lead_mail'];
        $data['lead_phone'] =$_POST['lead_phone'];
        $data['status1'] =$_POST['status1'];
        $data['status2'] =$_POST['status2'];
        $data['status3'] =$_POST['status3'];
        $data['source'] =$_POST['source'];
        $data['met_note'] =$_POST['met_note'];
        $data['remin_date'] =$_POST['remin_date'];
        //$data['user_id']=1;
        $this->load->model('Lead_followup_model');
        $data['lead_result']=$this->Lead_followup_model->add_lead_followup($data);
        echo json_encode($data['lead_result']);
    }
    
    public function lead_view()
	{
		$data['email_id']=$this->access;
		$data['role_id'] = $this->session->userdata('role_id');
		$data['user_id'] = $this->session->userdata('user_id');
		$this->load->model('Lead_followup_model');
		// $data['secure_code']=$this->access;
		//$data['user_id']=1;
		$data['lead_id']=$_POST['lead_id'];
		$data['key_id'] = $data['lead_id'];
		$data['activity_id'] = 4;
		$data['page_id'] = 10;
		$data['module_id'] = 10;
		$this->load->model('Admin_model');
		$this->Admin_model->bye_user_log($data);
		$data['view_lead']=$this->Lead_followup_model->show_lead_by_id($data);
		$this->load->view('lead_follow_show',$data);
    }
    
    public function lead_edit()
	{
		$data['email_id']=$this->access;
        $this->load->model('Lead_followup_model');
		$data['role_id'] = $this->session->userdata('role_id');
		$data['user_id'] = $this->session->userdata('user_id');
        //$data['user_id']=1;
        $data['lead_id']=$_POST['lead_id'];
        $data['edit_lead']=$this->Lead_followup_model->show_lead_by_id($data);
        $this->load->view('lead_follow_edit',$data);
    }
    
    public function lead_edit_data()
	{
		if($this->input->post('TS') != $this->session->userdata('form_ts'))
		{
			$data['email_id']=$this->access;
			$this->session->set_userdata('form_ts',$this->input->post('TS'));	
			$data['role_id'] = $this->session->userdata('role_id');
			$data['user_id'] = $this->session->userdata('user_id');
			$this->load->model('Lead_followup_model');
			$data['lead_month'] =$_POST['lead_month'];
			$data['lead_year'] =$_POST['lead_year'];
			$data['lead_date'] =$_POST['lead_date'];
			$data['lead_name'] =$_POST['lead_name'];
			$data['lead_mail'] =$_POST['lead_mail'];
			$data['lead_phone'] =$_POST['lead_phone'];
			$data['status1'] =$_POST['status1'];
			$data['status2'] =$_POST['status2'];
			$data['status3'] =$_POST['status3'];
			$data['source'] =$_POST['source'];
			$data['met_note'] =$_POST['met_note'];
			$data['remin_date'] =$_POST['remin_date'];
			$data['user_id']=1;
			$data['lead_id']=$_POST['lead_id'];
			$data['edit_lead']=$this->Lead_followup_model->edit_lead_data($data);
			$data['alert_flag'] = 1;
			$data['alert_message'] = "Lead details for Id has been updated successfully";
			$data['activity_id'] = 2;
			$data['key_id'] = $data['lead_id'];
			$data['page_id'] = 10;
			$data['module_id'] = 10;
			$this->load->model('Admin_model');
			$this->Admin_model->bye_user_log($data);
			$data['all_lead'] = $this->Lead_followup_model->all_lead_show($data);
			$this->load->view('lead_follow_master',$data);
		}
		else
			{
				$data['role_id'] = $this->session->userdata('role_id');
				$data['user_id'] = $this->session->userdata('user_id');
				$this->load->model('Lead_followup_model');
				$data['all_lead'] = $this->Lead_followup_model->all_lead_show($data);
				$this->load->view('lead_follow_master',$data);
			}
    }
    
}