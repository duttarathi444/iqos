<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {
	
    public function __construct()
    {
        parent::__construct();
        $this->load->model('user');
        $this->load->library('session');
        $this->load->helper('url');
    }

    public function index()
    {
        global $data;
        $this->load->view('login_1',$data);
    } 
    public function temp()
    {    
        global $data;
        $this->load->view('agent-module',$data);
    }

	public function login()
	{
		$this->load->view('login',$data);
        $data['activity_id'] = 5;
        $data['key_id'] =0;
        $data['page_id'] = 14;
        $data['module_id'] = 18;
        $this->load->model('Admin_model');
        $this->Admin_model->bye_user_log($data);
	}
    
	public function logout()
    {
        $this->session->sess_destroy();
        redirect($base_url);
    }

	public function user_auth()
	{
        session_cache_limiter('private, must-revalidate');
        session_cache_expire(60);
        session_start();
        if(!isset($_SESSION['email']))
        
        $data['email'] = $_POST['email'];
        $data['password'] = $_POST['password'];
        $this->load->model('user');
        $rs = $this->user->user_auth($data);
		if($rs)
		{
			foreach($rs as $result)
			{
				$ret_code = $result['login_status'];
				$role_id = $result['role_id'];
			}

		}
		if($ret_code == 1001)
		{
            $this->session->set_userdata(array('email_id' => $result['email_id'],
                         'role_id' => $result['role_id'],
                         'user_id' => $result['user_id']));

            $data['email_id'] = $this->session->userdata('email_id');

            $data['role_id'] = $this->session->userdata('role_id');
            $data['user_id'] = $this->session->userdata('user_id');
            
            //$url=base_url()."index.php/Admin/product_module";
			//redirect($url);
				
			if($role_id == 1)
			{   
		         $url=base_url()."index.php/Admin/product_module";
				 redirect($url);
			}
			
			elseif($role_id == 2)
			{
				
				$url=base_url()."index.php/admin/product_module2";
				 redirect($url);
			}
			else
			{
				$this->load->view('not-found');
			}
			
		}
		else
		{
			$this->session->set_flashdata('error', 'Please enter correct Password.');
			redirect($base_url);
		}
	}

}































