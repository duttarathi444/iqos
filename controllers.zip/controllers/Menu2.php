<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Menu2 extends CI_Controller{
    
    public function __construct()
    {
        parent::__construct();
        $this->load->helper('url');
        $this->load->library('session');
		$this->load->library('email');
        //$this->load->config('email');
        
        
    }
    
    public function secure_code_check(){

		if($this->session->userdata('email_id') == TRUE) 
        { 
            $data['email_id'] = $this->session->userdata('email_id');
			$this->load->model('Menu2_model');
			$randomid = mt_rand(100000,999999);
			$data['secure_code']=$randomid;
			$data['user_id'] = $this->session->userdata('user_id');
			$data['token_data']=$this->Menu2_model->add_token_data($data);

			if($data['token_data']>1){
				$to =$data['email_id'];
				$subject = "Token for Extra Menu";
				$txt = "Please use the One Time Token for accessing extra menus. ".$data['secure_code']." ";
				$headers = "From: webmaster@iqos.com";
				mail($to,$subject,$txt,$headers);
				
				echo json_encode($data['secure_code']+128);
			}

		}
	}
	
	public function token_validation(){
	   $this->load->model('Menu2_model');
	    $data['secure_code']=$_POST['secure_code']-128;
	    $data['enter_code']=$_POST['enter_code'];
		$data['user_id'] = $this->session->userdata('user_id');
	    $data['valid_token']=$this->Menu2_model->token_valid_data($data);
	    echo json_encode($data['valid_token']);
	}
	
	public function token_valid($b){
	    $this->load->model('Menu2_model');
	    $data['enter_code']=$b-128;
		$data['user_id'] = $this->session->userdata('user_id');
	    $data['valid_token']=$this->Menu2_model->token_valid_data($data);
	        return $data['valid_token'];
	}
	
	public function lend_module_view(){
	    $data['secure_id']=$_GET['a'];
	    $data['check_valid']=$this->token_valid($data['secure_id']);
	    if($data['check_valid'][0]['id']==1){
	        $this->load->view('Lend_module',$data);
	    }else{
	        $this->load->view('product_module');
	    }
	}
    
}