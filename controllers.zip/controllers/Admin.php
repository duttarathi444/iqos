<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {
	
	 	public function __construct()
    {
        parent::__construct();
		$this->load->model('user');
        $this->load->library('session');
        $this->load->helper('url');
    }
	/* public function admin_module()
{

	if($this->session->userdata('email_id') == TRUE) 
	{ 	
		$this->load->model('user');
		$data['roll_id'] = $this->session->userdata('roll_id');
		$data['user_id'] = $this->session->userdata('user_id');
		$module_access_list = $this->user->user_access_list_by_module($data);
		
		if($module_access_list)
		{
			foreach($module_access_list as $m_access_list)
			{
				if($m_access_list['module_id'] == 1)
				{
					$data['admin_settings'] = $m_access_list['module_user_access_view'];
				}
				elseif($m_access_list['module_id'] == 2)
				{
					$data['admin_invoice'] = $m_access_list['module_user_access_view'];
				}
				elseif($m_access_list['module_id'] == 3)
				{
					$data['admin_compliance'] = $m_access_list['module_user_access_view'];
				}
				elseif($m_access_list['module_id'] == 4)
				{
					$data['admin_reports'] = $m_access_list['module_user_access_view'];
				}
				else
				{
					$data['admin_noaccess'] = 1;
				}
			}
		}
		$this->load->view('admin-module',$data);
	}
		
	else
	{   $data['s_out'] = 'Session Expired..    ';
		$this->load->view('login',$data);
	}
} */

public function product_module()
{  
    if($this->session->userdata('email_id') == TRUE) 
	{
        $data['email_id'] = $this->session->userdata('email_id');
		$data['role_id'] = $this->session->userdata('role_id');
        $data['user_id'] = $this->session->userdata('user_id');
		//$data['admin']=$this->session->userdata('role_id');
		
        $this->load->view('product_module',$data);
	}
	else
	{   $data['s_out'] = 'Session Expired..    ';
		$this->load->view('login',$data);
	}
	
	
}

public function product_module2()
{  
    if($this->session->userdata('email_id') == TRUE) 
	{
        $data['email_id'] = $this->session->userdata('email_id');
		$data['role_id'] = $this->session->userdata('role_id');
        $data['user_id'] = $this->session->userdata('user_id');
		//$data['admin']=$this->session->userdata('role_id');
		
        $this->load->view('product_module2',$data);
	}
	else
	{   $data['s_out'] = 'Session Expired..    ';
		$this->load->view('login',$data);
	}
	
	
}




public function admin_tools()
{
	if($this->session->userdata('user_email') == TRUE) 
	{ 	
		$this->load->model('user');
		$data['role_id'] = $this->session->userdata('role_id');
		$data['user_id'] = $this->session->userdata('user_id');
		$module_access_list = $this->user->user_access_list_by_module($data);
		
		if($module_access_list)
		{
			foreach($module_access_list as $m_access_list)
			{
				if($m_access_list['module_id'] == 5)
				{
					$data['client_master'] = $m_access_list['module_user_access_view'];
				}
				elseif($m_access_list['module_id'] == 6)
				{
					$data['agent_master'] = $m_access_list['module_user_access_view'];
				}
				elseif($m_access_list['module_id'] == 7)
				{
					$data['hub_master'] = $m_access_list['module_user_access_view'];
				}
				elseif($m_access_list['module_id'] == 8)
				{
					$data['unit_master'] = $m_access_list['module_user_access_view'];
				}
				elseif($m_access_list['module_id'] == 9)
				{
					$data['tax_code_master'] = $m_access_list['module_user_access_view'];
				}
				elseif($m_access_list['module_id'] == 10)
				{
					$data['route_master'] = $m_access_list['module_user_access_view'];
				}
				elseif($m_access_list['module_id'] == 11)
				{
					$data['fsa_master'] = $m_access_list['module_user_access_view'];
				}
				elseif($m_access_list['module_id'] == 12)
				{
					$data['service_code_master'] = $m_access_list['module_user_access_view'];
				}
				elseif($m_access_list['module_id'] == 13)
				{
					$data['rate_card_master'] = $m_access_list['module_user_access_view'];
				}
				elseif($m_access_list['module_id'] == 14)
				{
					$data['rate_master'] = $m_access_list['module_user_access_view'];
				}
				elseif($m_access_list['module_id'] == 15)
				{
					$data['scan_master'] = $m_access_list['module_user_access_view'];
				}
				elseif($m_access_list['module_id'] == 16)
				{
					$data['module_permission_master'] = $m_access_list['module_user_access_view'];
				}
				elseif($m_access_list['page_permission_id'] == 17)
				{
					$data['page_permission'] = $m_access_list['module_user_access_view'];
				}
				elseif($m_access_list['page_permission_id'] == 18)
				{
					$data['users_master'] = $m_access_list['module_user_access_view'];
				}
				else
				{
					$data['admin_noaccess'] = 1;
				}
			}
		}
		$this->load->view('admin-tools',$data);
	}	
	else
	{   $data['s_out'] = 'Session Expired..    ';
		$this->load->view('login',$data);
	}
	
	
}


public function client_master()
{  
	 if($this->session->userdata('user_email') == TRUE) 
	{ 	
	$this->load->model('user');
	$data['role_id'] = $this->session->userdata('role_id');
	$data['user_id'] = $this->session->userdata('user_id');   

	$arrc =  $_POST['basic'];
	$arrlength = count($arrc);
	$this->load->model('admin_model');
	$this->load->model('User');
	$data['client_master_list']=$this->admin_model->client_list();
	$data['arrlength'] = $arrc;
	
	$data['page_id'] = 2;
	$data['client_access_list']=$this->User->user_access_list_by_page($data);
	$this->load->view('client_master',$data);
	
	}	
	else
	{   $data['s_out'] = 'Session Expired..    ';
		$this->load->view('login',$data);
	}
	
}



public function client_add()
{  
	 if($this->session->userdata('user_email') == TRUE) 
	{ 	
		$this->load->model('user');
		$this->load->model('admin_model');
		$data['role_id'] = $this->session->userdata('role_id');
		$data['user_id'] = $this->session->userdata('user_id'); 
	    $data['province_master_list']=$this->admin_model->province_master_list();
		$this->load->view('client_registration',$data);
	
	}	
	else
	{   $data['s_out'] = 'Session Expired..    ';
		$this->load->view('login',$data);
	}
}

public function client_registration()
{    
    
    if($this->input->post('TS') != $this->session->userdata('form_ts'))
        {

               if($this->session->userdata('user_email') == TRUE) 
               { 
               	$this->session->set_userdata('form_ts',$this->input->post('TS'));   
            	$this->load->model('user');
            	$data['role_id'] = $this->session->userdata('role_id');
            	$data['user_id'] = $this->session->userdata('user_id'); 
            	$data['company_name']=$_POST['company_name'];
            	$data['c_telephone']=$_POST['c_telephone'];
            	$data['c_fax']=$_POST['c_fax'];
            	$data['c_address']=$_POST['c_address'];
            	$data['province']=$_POST['province'];
                $data['city']=$_POST['region'];
                $data['postal_code']=$_POST['postal_code'];
                $data['hst']=$_POST['hst_no'];
                $data['pst']=$_POST['pst_no'];
                $data['qst']=$_POST['qst_no'];
            	
            	$data['shiptrack_id']=$_POST['shiptrack_id'];
            	$data['gst_no']=$_POST['gst_no'];
            	
            	if($_POST['client_name1'] !="")
            	{
            		$data['client_name1']=$_POST['client_name1'];
            	}
            	else
            	{
            		$data['client_name1'] ='NA';
            	}
            	
            	if($_POST['client_telephone1'] !="")
            	{
            		$data['client_telephone1']=$_POST['client_telephone1'];
            	}
            	else
            	{
            		$data['client_telephone1'] ='NA';
            	}
            	
            
            	if($_POST['client_email1'] !="")
            	{
            		$data['client_email1']=$_POST['client_email1'];
            	}
            	else
            	{
            		$data['client_email1'] ='';
            	}
            	
            	if($_POST['client_name2'] !="")
            	{
            		$data['client_name2']=$_POST['client_name2'];
            	}
            	else
            	{
            		$data['client_name2'] ='';
            	}
            	
            	if($_POST['client_telephone2'] !="")
            	{
            		$data['client_telephone2']=$_POST['client_telephone2'];
            	}
            	else
            	{
            		$data['client_telephone2'] ='';
            	}
            	
            	if($_POST['client_email2'] !="")
            	{
            		$data['client_email2']=$_POST['client_email2'];
            	}
            	else
            	{
            		$data['client_email2'] ='NA';
            	}
            	
            	$data['alert_flag'] = 0;
            	$data['alert_message'] = "";
            	
            	
            	$this->load->model('admin_model');
            	$data['alert_flag'] = 0;
            	if($data['company_name']!="" && $data['c_telephone']!='')
            	{
            		$data['client_list']=$this->admin_model->client_registration($data);
            		
            		if($data['client_list'])
            		{
            			foreach($data['client_list'] as $c_list)
            			{
            				$new_client_id = $c_list['new_client_id'];
            			}
            		}
            		
            		$target_dir="././client_ftp/cl-".$new_client_id."/";
            		if(!file_exists($target_dir))
            		{
            			mkdir($target_dir,0755);
            		}
            		$data['new_client_id'] = $new_client_id;
            		$data['ftp_path'] = "purpuligo.com/booya/client_ftp/cl-".$new_client_id;
            		$this->admin_model->ftp_path_update($data);
            		$data['alert_flag'] = 1;
            		$data['alert_message'] = "New client registration is successful. New Client Id is ".$new_client_id;
            		
            		if($new_client_id > 0)
            		{
            			$to = $data['client_email1'];
            			$subject = "Welcome to Metro portal";
            			$txt = "Welcome to the world of Metro!. New Account has been created for file transferring. The path for FTP is - ".$data['ftp_path']." . Thanks.";
            			$headers = "From: webmaster@metroweb.com";
            
            			mail($to,$subject,$txt,$headers);
            		}
            		
            		
            		
            	}
            	else
            	{
            		$data['alert_flag'] = 0;
            		$data['alert_message'] = "";
            	}
            	
            	$data['company_name']="";
            	$data['c_telephone']="";
            	$data['c_fax']="";
            	$data['c_address']="";
            	$_POST['client_name1']="";
            	$_POST['client_telephone1']="";
            	$data['client_email1']="";
            	$_POST['client_name2']="";
            	$_POST['client_telephone2']="";
            	$data['client_email2']="";
            	
            	$data['shiptrack_id']=$_POST['shiptrack_id'];
            	$data['gst_no']=$_POST['gst_no'];
            	
                    
                    $data['activity_id'] = 1;
                    $data['key_id'] = $data['new_client_id'];
                    $data['page_id'] = 2;
                    $data['module_id'] = 1;
                    $this->load->model('Admin_model');
                    $this->Admin_model->bye_user_log($data);
            
            
            	$data['client_master_list']=$this->admin_model->client_list();
            	$this->load->view('client_master',$data);
              }	
            	else
            	{   $data['s_out'] = 'Session Expired..    ';
            		$this->load->view('login',$data);
            	}
        }
        else
            {
               	$data['role_id'] = $this->session->userdata('role_id');
            	$data['user_id'] = $this->session->userdata('user_id'); 
                $data['user_id'] = $data['agent_id'];
                $this->load->model('admin_model');
               $data['client_master_list']=$this->admin_model->client_list();
            	$this->load->view('client_master',$data);
            }
            	
            	
}
	
public function client_edit()
{
    
     
        
        	if($this->session->userdata('user_email') == TRUE) 
               { 	
            	$this->load->model('user');
            	$data['role_id'] = $this->session->userdata('role_id');
            	$data['user_id'] = $this->session->userdata('user_id');
            	$data['client_id'] = $_POST['client_id2'];
            	$this->load->model('admin_model');
            	 $data['province_master_list']=$this->admin_model->province_master_list();
            	$data['alert_flag'] = 0;
            	$data['alert_message'] = "";
            	$data['client_list']=$this->admin_model->edit_client($data);
            	$this->load->view('client_edit',$data);
            	}	
        	else
            	{   $data['s_out'] = 'Session Expired..    ';
            		$this->load->view('login',$data);
            	}
        
        
        
	
}


public function client_view()
{   
	if($this->session->userdata('user_email') == TRUE) 
   { 	
	$this->load->model('user');
	$data['role_id'] = $this->session->userdata('role_id');
	$data['user_id'] = $this->session->userdata('user_id');
	$data['client_id'] = $_POST['client_id6'];
	$this->load->model('admin_model');
	$data['alert_flag'] = 0;
	$data['alert_message'] = "";
	$data['client_list']=$this->admin_model->edit_client($data);
	
	$data['activity_id'] = 4;
	$data['key_id'] = $data['client_id'];
	$data['page_id'] = 2;
	$data['module_id'] = 1;
	$this->load->model('Admin_model');
	$this->Admin_model->bye_user_log($data);
	
	$this->load->view('client_view',$data);
	}	
	else
	{   $data['s_out'] = 'Session Expired..    ';
		$this->load->view('login',$data);
	}
}


public function agent_master()
{   

	if($this->session->userdata('user_email') == TRUE) 
	{ 	
		
	$data['role_id'] = $this->session->userdata('role_id');
	$data['user_id'] = $this->session->userdata('user_id');
	$arrc =  $_POST['basic'];
	$arrlength = count($arrc);
	$this->load->model('admin_model');
	$data['agent_master_list']=$this->admin_model->agent_list();
	$data['arrlength'] = $arrc;
	$data['delete_flag'] = 0;
	$this->load->view('agent_master',$data);
	}	
	else
	{   $data['s_out'] = 'Session Expired..    ';
		$this->load->view('login',$data);
	}
}


public function agent_add()
{
	if($this->session->userdata('user_email') == TRUE) 
	{ 	
	$this->load->model('admin_model');	
	$data['role_id'] = $this->session->userdata('role_id');
	$data['user_id'] = $this->session->userdata('user_id');
	 $data['province_master_list']=$this->admin_model->province_master_list();
	$this->load->view('agent_registration',$data);
	}	
	else
	{   $data['s_out'] = 'Session Expired..    ';
		$this->load->view('login',$data);
	}
}

public function agent_reg()
{
    
    if($this->input->post('TS') != $this->session->userdata('form_ts'))
       {
    
        	if($this->session->userdata('user_email') == TRUE) 
        	{ 
        	$this->session->set_userdata('form_ts',$this->input->post('TS'));
        	$data['role_id'] = $this->session->userdata('role_id');
        	$data['user_id'] = $this->session->userdata('user_id');
        	$data['company_name']=$_POST['company_name'];
        	$data['c_telephone']=$_POST['c_telephone'];
        	$data['c_fax']=$_POST['c_fax'];
        	$data['c_address']=$_POST['c_address'];
        	$data['address']=$_POST['c_address'];
        	$data['shiptrack_id']=$_POST['shiptrack_id'];
        	$data['gst_no']=$_POST['gst_no'];
        	$data['province']=$_POST['province'];
            $data['city']=$_POST['region'];
            $data['postal_code']=$_POST['postal_code'];
            $data['hst']=$_POST['hst_no'];
            $data['pst']=$_POST['pst_no'];
            $data['qst']=$_POST['qst_no'];
        	$data['role']=2;
        	
        	if($_POST['agent_name1'] !="")
        	{
        		$data['agent_name1']=$_POST['agent_name1'];
        		$data['first_name']=$_POST['agent_name1'];
        		$data['last_name']="";
        	}
        	else
        	{
        		$data['agent_name1'] ='NA';
        	}
        	
        	if($_POST['agent_telephone1'] !="")
        	{
        		$data['agent_telephone1']=$_POST['agent_telephone1'];
        		$data['phone']=$_POST['agent_telephone1'];
        	}
        	else
        	{
        		$data['agent_telephone1'] ='NA';
        	}
        	
        
        	if($_POST['agent_email1'] !="")
        	{
        		$data['agent_email1']=$_POST['agent_email1'];
        		$data['email'] = $data['agent_email1'];
        	}
        	else
        	{
        		$data['agent_email1'] ='';
        	}
        	
        	if($_POST['agent_name2'] !="")
        	{
        		$data['agent_name2']=$_POST['agent_name2'];
        	}
        	else
        	{
        		$data['agent_name2'] ='';
        	}
        	
        	if($_POST['agent_telephone2'] !="")
        	{
        		$data['agent_telephone2']=$_POST['agent_telephone2'];
        	}
        	else
        	{
        		$data['agent_telephone2'] ='';
        	}
        	
        	if($_POST['agent_email2'] !="")
        	{
        		$data['agent_email2']=$_POST['agent_email2'];
        	}
        	else
        	{
        		$data['agent_email2'] ='';
        	}
        	$data['alert_flag'] = 0;
        	$data['alert_message'] = "";
        	
        	$this->load->model('admin_model');
        	$data['alert_flag'] = 0;
        	if($data['company_name']!="" && $data['agent_email1']!='')
        	{
        		$data['password'] = substr(md5(rand().rand()), 0, 6);
        		$data['agent_list']=$this->admin_model->agent_registration($data);
        		
        		
        		if($data['agent_list']){
        			foreach($data['agent_list'] as $agent_id_c){
        				$agent_id_new = $agent_id_c['agent_id'];
        				$password = $agent_id_c['password'];
        				$data['agent_id_new'] = $agent_id_c['agent_id'];
        			}
        			
        			$this->load->model('User');
        			$data['user_details'] = $this->User->user_registration($data);
        			if($data['user_details'])
        			{
        				foreach($data['user_details'] as $u_details)
        				{
        					$token = $u_details['token'];
        				}
        			}
        			$data['agent_id_new'] = $agent_id_new;
        			$data['alert_flag'] = 1;   
        			$data['alert_message'] = "Agent registration is successful. New Agent ID is ".$agent_id_new;
        		}
        		
        		if($agent_id_new >0)
        		{
        			$to = $data['agent_email1'];
        			$subject = "Welcome to Metro portal";
        			$txt = "Welcome to the world of Metro!. Your User ID is for accessing application is ".$data['agent_email1']." and One time Password is ".$data['password'];
        			$txt = $txt." Please go through the url http://www.purpuligo.com/booya/index.php/User_auth/d999b2e6cb1d7a06d5b025c43af1eaf/".$token;
        			$headers = "From: webmaster@metroweb.com";
        
        			mail($to,$subject,$txt,$headers);
        		}
        	}
        	else
        	{
        		$data['alert_flag'] = 0; 
        		$data['alert_message']="";
        	}
        	$data['agent_email1'] = "";
        	$data['company_name'] = "";
        	
        	        $data['activity_id'] = 1;
                    $data['key_id'] = $data['agent_id_new'];
                    $data['page_id'] = 1;
                    $data['module_id'] = 1;
                    $this->load->model('Admin_model');
                    $this->Admin_model->bye_user_log($data);
        	
        	
        	
        	$data['agent_master_list']=$this->admin_model->agent_list();
        	$this->load->view('agent_master',$data);
        	}	
        	else
        	{   $data['s_out'] = 'Session Expired..    ';
        		$this->load->view('login',$data);
        	}
       }
       
       else
		{
			$data['agent_id'] = $this->session->userdata('user_id');
			$data['user_id'] = $data['agent_id'];
			$data['role_id'] = $this->session->userdata('role_id');
			$this->load->model('admin_model');
		    $data['agent_master_list']=$this->admin_model->agent_list();
        	$this->load->view('agent_master',$data);
		}
        	
        	
}

public function admin_invoice()
{
	if($this->session->userdata('user_email') == TRUE) 
	{ 	
		
		$data['role_id'] = $this->session->userdata('role_id');
		$data['user_id'] = $this->session->userdata('user_id');
		$this->load->view('admin_invoice',$data);
	}	
	else
	{   $data['s_out'] = 'Session Expired..    ';
		$this->load->view('login',$data);
	}
}
	


public function agent_edit()
{
    
    
        	 if($this->session->userdata('user_email') == TRUE) 
            	{ 	
            	 $data['role_id'] = $this->session->userdata('role_id');
            	 $data['user_id'] = $this->session->userdata('user_id');
            	 $data['agent_id'] = $_POST['agent_id2'];
            	 $this->load->model('admin_model');
            	  $data['province_master_list']=$this->admin_model->province_master_list();
            	 $data['alert_flag'] = 0;
            	 $data['alert_message'] = "";
            	 $data['agent_list']=$this->admin_model->edit_agent($data);
            	 $this->load->view('agent_edit',$data);
            	 }	
        	else
            	{   $data['s_out'] = 'Session Expired..    ';
            		$this->load->view('login',$data);
            	}
    
        
   
    
}

public function agent_delete()
{
	if($this->session->userdata('user_email') == TRUE) 
	{ 	
		
	$data['role_id'] = $this->session->userdata('role_id');
	$data['user_id'] = $this->session->userdata('user_id');
	$data['agent_id'] = $_POST['agent_id3'];
	$this->load->model('admin_model');
	$data['alert_flag'] = 0;
	$data['alert_message'] = "";
	$this->admin_model->agent_delete($data);
	$data['alert_flag'] = 1;
	$data['alert_message'] = "Agent Id ".$data['agent_id']." has been Deleted successfuly.";
	$data['agent_master_list']=$this->admin_model->agent_list();
    $data['activity_id'] = 3;
    $data['key_id'] = $data['agent_id'];
    $data['page_id'] = 1;
    $data['module_id'] = 1;
    $this->load->model('Admin_model');
    $this->Admin_model->bye_user_log($data);
	
	
	$this->load->view('agent_master',$data);
	}	
	else
	{   $data['s_out'] = 'Session Expired..    ';
		$this->load->view('login',$data);
	}
}


public function agentdetails_update()
{   
if($this->session->userdata('user_email') == TRUE) 
 { 	
		
	$data['role_id'] = $this->session->userdata('role_id');
	$data['user_id'] = $this->session->userdata('user_id');
	$data['company_name']=$_POST['company_name'];
	$data['c_telephone']=$_POST['c_telephone'];
	$data['c_fax']=$_POST['c_fax'];
	$data['c_address']=$_POST['c_address'];
	$data['agent_id'] = $_POST['agent_id'];
	$data['shiptrack_id']=$_POST['shiptrack_id'];
	$data['gst_no']=$_POST['gst_no'];
    $data['province']=$_POST['province'];
    $data['city']=$_POST['region'];
    $data['postal_code']=$_POST['postal_code'];
    $data['hst']=$_POST['hst_no'];
    $data['pst']=$_POST['pst_no'];
    $data['qst']=$_POST['qst_no'];
	
	if($_POST['agent_name1'] !="")
	{
		$data['agent_name1']=$_POST['agent_name1'];
	}
	else
	{
		$data['agent_name1'] ='NA';
	}
	
	if($_POST['agent_telephone1'] !="")
	{
		$data['agent_telephone1']=$_POST['agent_telephone1'];
	}
	else
	{
		$data['agent_telephone1'] ='NA';
	}
	

	if($_POST['agent_email1'] !="")
	{
		$data['agent_email1']=$_POST['agent_email1'];
	}
	else
	{
		$data['agent_email1'] ='NA';
	}
	
	if($_POST['agent_name2'] !="")
	{
		$data['agent_name2']=$_POST['agent_name2'];
	}
	else
	{
		$data['agent_name2'] ='NA';
	}
	
	if($_POST['agent_telephone2'] !="")
	{
		$data['agent_telephone2']=$_POST['agent_telephone2'];
	}
	else
	{
		$data['agent_telephone2'] ='NA';
	}
	
	if($_POST['agent_email2'] !="")
	{
		$data['agent_email2']=$_POST['agent_email2'];
	}
	else
	{
		$data['agent_email2'] ='NA';
	}
	$data['alert_flag'] = 0;
	$data['alert_message'] = "";
	$this->load->model('admin_model');
	$data['agent_list']=$this->admin_model->agent_update($data);
	
	$arrc =  $_POST['basic'];
	$arrlength = count($arrc);
	$this->load->model('admin_model');
	$data['agent_master_list']=$this->admin_model->agent_list();
	$data['arrlength'] = $arrc;
	$data['alert_flag'] = 1;
	$data['alert_message'] = "Agent Id ".$data['agent_id']." details have been Updated successfuly.";
	$data['agent_master_list']=$this->admin_model->agent_list();
	
	$data['activity_id'] = 2;
    $data['key_id'] = $data['agent_id'];
    $data['page_id'] = 1;
    $data['module_id'] = 1;
    $this->load->model('Admin_model');
    $this->Admin_model->bye_user_log($data);
	
	$this->load->view('agent_master',$data);
	}	
	else
	{   $data['s_out'] = 'Session Expired..    ';
		$this->load->view('login',$data);
	}
} 



public function clientdetails_update()
{
if($this->session->userdata('user_email') == TRUE) 
  { 	
		
	$data['role_id'] = $this->session->userdata('role_id');
	$data['user_id'] = $this->session->userdata('user_id');
	$data['company_name']=$_POST['company_name'];
	$data['c_telephone']=$_POST['c_telephone'];
	$data['c_fax']=$_POST['c_fax'];
	$data['c_address']=$_POST['c_address'];
    $data['province']=$_POST['province'];
    $data['city']=$_POST['region'];
    $data['postal_code']=$_POST['postal_code'];
    $data['hst']=$_POST['hst_no'];
    $data['pst']=$_POST['pst_no'];
    $data['qst']=$_POST['qst_no'];
	
	$data['shiptrack_id']=$_POST['shiptrack_id'];
	$data['gst_no']=$_POST['gst_no'];


	if($_POST['client_name1'] !="")
	{
		$data['client_name1']=$_POST['client_name1'];
	}
	else
	{
		$data['client_name1'] ='NA';
	}
	
	if($_POST['client_telephone1'] !="")
	{
		$data['client_telephone1']=$_POST['client_telephone1'];
	}
	else
	{
		$data['client_telephone1'] ='NA';
	}
	

	if($_POST['client_email1'] !="")
	{
		$data['client_email1']=$_POST['client_email1'];
	}
	else
	{
		$data['client_email1'] ='NA';
	}
	
	if($_POST['client_name2'] !="")
	{
		$data['client_name2']=$_POST['client_name2'];
	}
	else
	{
		$data['client_name2'] ='NA';
	}
	
	if($_POST['client_telephone2'] !="")
	{
		$data['client_telephone2']=$_POST['client_telephone2'];
	}
	else
	{
		$data['client_telephone2'] ='NA';
	}
	
	if($_POST['client_email2'] !="")
	{
		$data['client_email2']=$_POST['client_email2'];
	}
	else
	{
		$data['client_email2'] ='NA';
	}
	
	$data['clnt_idd']=$_POST['clnt_idd'];
	
	$this->load->model('admin_model');
    $data['agent_list']=$this->admin_model->client_update($data);
	
	$data['activity_id'] = 2;
	$data['key_id'] = $data['clnt_idd'];
	$data['page_id'] = 2;
	$data['module_id'] = 1;
	$this->load->model('Admin_model');
	$this->Admin_model->bye_user_log($data);
   
   
    $arrc =  $_POST['basic'];
	$arrlength = count($arrc);

	$data['alert_flag'] = 0;
	$data['alert_message'] = "";
	$this->load->model('admin_model');
	$data['client_master_list']=$this->admin_model->client_list();
	
	$data['alert_flag'] = 1;
	$data['alert_message'] = "Client Id ".$data['clnt_idd']." details have been Updated successfuly.";
	$data['arrlength'] = $arrc;
	$this->load->view('client_master',$data);
	}	
	else
	{   $data['s_out'] = 'Session Expired..    ';
		$this->load->view('login',$data);
	}
   
}

public function unit_master_add()
{
   if($this->session->userdata('user_email') == TRUE) 
	{ 	
		
		$data['role_id'] = $this->session->userdata('role_id');
		$data['user_id'] = $this->session->userdata('user_id'); 
		$this->load->view('unit_master_add',$data);
	}	
	else
	{   $data['s_out'] = 'Session Expired..    ';
		$this->load->view('login',$data);
	}
	
	
}

public function hub_master_add()
{   
  if($this->session->userdata('user_email') == TRUE) 
	{ 	
		
		$data['role_id'] = $this->session->userdata('role_id');
		$data['user_id'] = $this->session->userdata('user_id');
		
		$data['agent_master_list']=$this->admin_model->agent_list();
		$this->load->view('hub_master_add',$data);
	}	
	else
	{   $data['s_out'] = 'Session Expired..    ';
		$this->load->view('login',$data);
	}
	
}

public function unit_master()
{  
if($this->session->userdata('user_email') == TRUE) 
{ 	
		
	$data['role_id'] = $this->session->userdata('role_id');
	$data['user_id'] = $this->session->userdata('user_id');	
	$arrc =  $_POST['basic'];
	$arrlength = count($arrc);
	$this->load->model('admin_model');
	$data['unit_master_list']=$this->admin_model->unit_list();
	$data['arrlength'] = $arrc;
	$this->load->view('unit_master',$data);
	}	
	else
	{   $data['s_out'] = 'Session Expired..    ';
		$this->load->view('login',$data);
	}
}

public function service_code_master()
{  
   if($this->session->userdata('user_email') == TRUE) 
	{ 	
		
	$data['role_id'] = $this->session->userdata('role_id');
	$data['user_id'] = $this->session->userdata('user_id');	
	$arrc =  $_POST['basic'];
	$arrlength = count($arrc);
	$this->load->model('admin_model');
	$this->load->model('User');
	
	$data['page_id'] = 1;
	//$data['user_id'] = 1;
	
	$data['client_access_list']=$this->User->user_access_list_by_page($data);
	$data['service_code_master_list']=$this->admin_model->service_code_list();
	$data['arrlength'] = $arrc;
	$this->load->view('service_code_master',$data);
	}	
	else
	{   $data['s_out'] = 'Session Expired..    ';
		$this->load->view('login',$data);
	}

}


public function scan_code_master()
{   
  if($this->session->userdata('user_email') == TRUE) 
	{ 	
		
	$data['role_id'] = $this->session->userdata('role_id');
	$data['user_id'] = $this->session->userdata('user_id');
	$arrc =  $_POST['basic'];
	$arrlength = count($arrc);
	//echo "//".$arrlength;
	$this->load->model('admin_model');
	$data['scan_code_master_list']=$this->admin_model->scan_code_list();
	$data['arrlength'] = $arrc;
	$this->load->view('scan_code_master',$data);
	}	
	else
	{   $data['s_out'] = 'Session Expired..    ';
		$this->load->view('login',$data);
	}

}

public function client_delete()
{
  if($this->session->userdata('user_email') == TRUE) 
	{ 	
		
	$data['role_id'] = $this->session->userdata('role_id');
	$data['user_id'] = $this->session->userdata('user_id');
	$data['client_id'] = $_POST['client_id3'];
	$this->load->model('admin_model');
	$data['alert_flag'] = 0;
	$data['alert_message'] = "";
	$this->admin_model->client_delete($data);
	$data['alert_flag'] = 1;
	$data['alert_message'] = "client Id ".$data['client_id']." has been Deleted successfuly.";
	$data['client_master_list']=$this->admin_model->client_list();
	$data['activity_id'] = 3;
	$data['key_id'] = $data['client_id'];
	$data['page_id'] = 2;
	$data['module_id'] = 1;
	$this->load->model('Admin_model');
	$this->Admin_model->bye_user_log($data);
	
	
	
	$this->load->view('client_master',$data);
	}	
	else
	{   $data['s_out'] = 'Session Expired..    ';
		$this->load->view('login',$data);
	}
}

/*	public function client_views()
{
   
	 $arrc =  $_POST['basic'];
	$arrlength = count($arrc);
	$this->load->model('admin_model');
	$data['client_master_list']=$this->admin_model->client_list();
	$this->load->view('client_view',$data);
} */

public function agent_view()
{
  if($this->session->userdata('user_email') == TRUE) 
	{ 	
		
	$data['role_id'] = $this->session->userdata('role_id');
	$data['user_id'] = $this->session->userdata('user_id');  
	$data['agent_id'] = $_POST['agent_id6'];
	
	 $this->load->model('admin_model');
	 $data['alert_flag'] = 0;
	 $data['alert_message'] = "";
	 $data['agent_list']=$this->admin_model->edit_agent($data);
    $data['activity_id'] = 4;
    $data['key_id'] = $data['agent_id'];
    $data['page_id'] = 1;
    $data['module_id'] = 1;
    $this->load->model('Admin_model');
    $this->Admin_model->bye_user_log($data);
	 
	 $this->load->view('agent_view',$data);
	 }	
	else
	{   $data['s_out'] = 'Session Expired..    ';
		$this->load->view('login',$data);
	}
}


public function hub_master()
{   
  if($this->session->userdata('user_email') == TRUE) 
   { 	
		
	$data['role_id'] = $this->session->userdata('role_id');
	$data['user_id'] = $this->session->userdata('user_id');
	$this->load->model('admin_model');
	$data['hub_master_list']=$this->admin_model->hub_master_list();
	$this->load->view('hub_master',$data);
	}	
	else
	{   $data['s_out'] = 'Session Expired..    ';
		$this->load->view('login',$data);
	}
}

public function hub_add()
{
   if($this->session->userdata('user_email') == TRUE) 
	{ 	
		
	$data['role_id'] = $this->session->userdata('role_id');
	$data['user_id'] = $this->session->userdata('user_id');
	$this->load->model('admin_model');
	$this->load->model('Tax_model');
	
	$data['province_master_list']=$this->admin_model->province_master_list();
	$data['agent_master_list']=$this->admin_model->agent_list();
    $data['tax_master_list']=$this->Tax_model->bye_tax_list();
    


	
	$this->load->view('hub_master_add',$data);
	}	
	else
	{   $data['s_out'] = 'Session Expired..    ';
		$this->load->view('login',$data);
	}
}

public function hub_registration()
{
	if($this->session->userdata('user_email') == TRUE) 
	{ 	
		
	$data['role_id'] = $this->session->userdata('role_id');
	$data['user_id'] = $this->session->userdata('user_id');
	$data['hub_code']=$_POST['hub_code'];
	$data['hub_name']=$_POST['hub_name'];
	$data['taxcode']=$_POST['taxcode'];
	$data['address1']=$_POST['address1'];
	$data['address2']=$_POST['address2'];
	$data['province']=$_POST['province'];
	$data['city']=$_POST['region'];
	$data['postal_code']=$_POST['postal_code'];
	$data['tail_gate_rate']=$_POST['tail_gate_rate'];
	$data['stair_flight_rate_1']=$_POST['stair_flight_rate_1'];
	$data['stair_flight_rate_2']=$_POST['stair_flight_rate_2'];
	$data['man_rate']=$_POST['man_rate'];
	$data['wait_time_rate']=$_POST['wait_time_rate'];
	$data['hstcode']=$_POST['hst'];
	$data['pstcode']=$_POST['pst'];
	$data['qstcode']=$_POST['qst'];
	
    $arr =  $_POST['client'];
    foreach ($arr as $names)
    {
        $s_str .= $names.",";
    }
    
    $data['client']=$s_str;

	if($_POST['contact'] !="")
	{
		$data['contact']=$_POST['contact'];
	}
	else
	{
		$data['contact'] ='';
	}
	if($_POST['phone_no1'] !="")
	{
		$data['phone_no1']=$_POST['phone_no1'];
	}
	else
	{
		$data['phone_no1'] ='';
	}
	if($_POST['scac'] !="")
	{
		$data['scac']=$_POST['scac'];
	}
	else
	{
		$data['scac'] ='';
	}
	
	
	$this->load->model('admin_model');
	$data['hub_id'] = $this->admin_model->hub_reg($data);
	if($hub_id)
	{
		foreach($hub_id as $h_id)
		{
			$data['new_hub_id'] = $h_id['hub_id'];
		}
	}
	$data['alert_flag'] = 1;
	$data['alert_message'] = "New Hub ID ".$data['new_hub_id']. " registration is successful.";
	$data['hub_master_list']=$this->admin_model->hub_master_list();

	$this->load->view('hub_master',$data);
	}	
	else
	{   $data['s_out'] = 'Session Expired..    ';
		$this->load->view('login',$data);
	}
}

    public function get_region_category_by_province()
    {
        
		/* if($this->session->userdata('user_email') == TRUE) 
        { 	
        $data['role_id'] = $this->session->userdata('role_id');
        $data['user_id'] = $this->session->userdata('user_id');$this->load->model('Rate_model'); */
        $data['product_id'] = $this->input->post('id',TRUE);
		$this->load->model('admin_model');
		$data['result'] = $this->admin_model->bye_type_list_by_product($data);
        echo json_encode($data['result']);
        /* } */
    }


	public function client_list_ajx()
	{
		$this->load->model('admin_model');
		$client_list=$this->admin_model->client_list();
		echo json_encode($client_list);
	}

	public function get_fsa_by_zone()
	{

		if($this->session->userdata('user_email') == TRUE) 
		{ 	
			$data['role_id'] = $this->session->userdata('role_id');
			$data['user_id'] = $this->session->userdata('user_id');$this->load->model('Rate_model');
			$data['product_id'] = $this->input->post('id',TRUE);
			$this->load->model('admin_model');
			$data = $this->admin_model->bye_fsa_by_zone($data);
			echo json_encode($data);
		}
	}
	
	public function get_hub_client_list()
	{
		if($this->session->userdata('user_email') == TRUE) 
		{ 	
			$data['role_id'] = $this->session->userdata('role_id');
			$data['user_id'] = $this->session->userdata('user_id');
			$data['hub_id'] = $this->input->post('id',TRUE);
			$this->load->model('admin_model');
			$data = $this->admin_model->bye_hub_client_list($data);
			echo json_encode($data);
		}
		
	}
	
	
	
	public function hub_view()
{
   if($this->session->userdata('user_email') == TRUE) 
	{ 	
		
	$data['role_id'] = $this->session->userdata('role_id');
	$data['user_id'] = $this->session->userdata('user_id');
	$this->load->model('admin_model');
	$this->load->model('Tax_model');
	$data['hub_id'] = $_POST['hub_id2'];
	
	 
	 if($data['hub_id']!='')
	 {
	 $data['hub_list']=$this->admin_model->bye_hub_view($data);
      }
	$data['activity_id'] = 4;
    $data['key_id'] = $data['hub_id'];
    $data['page_id'] = 3;
    $data['module_id'] = 1;
    $this->load->model('Admin_model');
    $this->Admin_model->bye_user_log($data);
	
	
	$this->load->view('hub_view',$data);
	}	
	else
	{   $data['s_out'] = 'Session Expired..    ';
		$this->load->view('login',$data);
	}
}

	public function hub_delete()
	{
	    if($this->session->userdata('user_email') == TRUE) 
        { 	
			$data['role_id'] = $this->session->userdata('role_id');
			$data['user_id'] = $this->session->userdata('user_id');
			$data['hub_id'] = $_POST['hub_id3'];
			$this->load->model('admin_model');
			$this->admin_model->hub_delete($data);
			$data['alert_flag'] = 0;
			$data['alert_message'] = "";
			//$data['hub_master_list']=$this->admin_model->hub_master_list();
			$data['alert_flag'] = 1;
			$data['alert_message'] = "Hub details for Id ".$data['hub_id']." has been deleted";
			$data['activity_id'] = 3;
			$data['key_id'] = $data['hub_id'];
			$data['page_id'] = 3;
			$data['module_id'] = 1;
			$this->load->model('Admin_model');
			$this->Admin_model->bye_user_log($data);
				 $data['hub_master_list']=$this->admin_model->hub_master_list();
	             $this->load->view('hub_master',$data);
			//$this->load->view('driver_master',$data);
	   }
		else
		{   
			$data['s_out'] = 'Session Expired..    ';
			$this->load->view('login',$data);
		}
	}

	
public function hub_edit()
{
    
     
        
        	if($this->session->userdata('user_email') == TRUE) 
               { 	
            	$this->load->model('user');
            	$data['role_id'] = $this->session->userdata('role_id');
            	$data['user_id'] = $this->session->userdata('user_id');
            	$data['hub_id'] = $_POST['client_id2'];
            	$this->load->model('admin_model');
            	 $data['province_master_list']=$this->admin_model->province_master_list();
            	 
            	 if($data['hub_id']!=''){
            	    $data['hub_list']=$this->admin_model->bye_hub_view($data); 
            	 }
            	 
            	//$data['alert_flag'] = 0;
            	///$data['alert_message'] = "";
            	//$data['client_list']=$this->admin_model->edit_client($data);
            	$this->load->view('hub_edit',$data);
            	}	
        	else
            	{   $data['s_out'] = 'Session Expired..    ';
            		$this->load->view('login',$data);
            	}
        
        
        
	
}
	 
	 public function hub_update()
    	 {
    	   if($this->session->userdata('user_email') == TRUE) 
    	     {
	         	$data['role_id'] = $this->session->userdata('role_id');
				$data['user_id'] = $this->session->userdata('user_id');
    	     
        	       $data['hub_id']=$_POST['hub_id'];
        	     echo $data['hub_id'];
        	     $data['hub_code']=$_POST['hub_code'];
        	      echo $data['hub_code'];
        	     
        	    
    			 $data['hub_name']=$_POST['hub_name'];
    			  echo $data['hub_name'];
        	    
    			 $data['taxcode']=$_POST['taxcode'];
    			  echo $data['taxcode'];
        	    
    			 $data['hst']=$_POST['hst'];
    			  echo $data['hst'];
        	    
    			 $data['pst']=$_POST['pst'];
    			  echo $data['pst'];
        	    
    			 $data['qst']=$_POST['qst'];
    			  echo $data['qst'];
        	    
    			 $data['address1']=$_POST['address1'];
    			  echo $data['address1'];
        	    
    			 $data['address2']=$_POST['address2'];
    			  echo $data['address2'];

    			 $data['province']=$_POST['province'];
    			  echo $data['province'];
                   if($_POST['region']!='')
                   {
                       $data['region']=0;
                   }
                   else
                   {
    			 $data['region']=$_POST['region'];
                   }

    			 $data['postal_code']=$_POST['postal_code'];
    			     			  echo $data['postal_code'];

    			 $data['contact']=$_POST['contact'];
    			 echo $data['contact'];
    			 $data['phone_no1']=$_POST['phone_no1'];
    			 $data['scac']=$_POST['scac'];
    			 	 	     
    		
    			 	 	  
    		//	 $this->load->model('Compliance_model');
    		//	 $this->load->model('driver_model');
    			 $this->load->model('admin_model');
    		//	 $data['driver_master_list']=$this->Compliance_model->hub_updates($data);
    			 $data['$hub_master_list']=$this->admin_model->hub_updates($data);
				 $data['activity_id'] = 2;
				$data['key_id'] = $data['hub_id'];
				$data['page_id'] = 3;
				$data['module_id'] = 1;
				$this->load->model('Admin_model');
				$this->Admin_model->bye_user_log($data);
    			 
    		    	//$data['driver_id']=$_POST['driver_id'];
    			 
    	         //$data['driver_master_list']=$this->driver_model->driver_list($data);
    			 	 //$data['agent_master_list']=$this->Compliance_model->bye_agent_list();
    			 	 
    			 	 	$data['hub_master_list']=$this->admin_model->hub_master_list();
			$this->load->view('hub_master',$data);
			
    	     
    	     }
    	     else
    	     {
    	       $data['s_out'] = 'Session Expired..    ';
        	    $this->load->view('login',$data);   
    	     }
    	     
    	 }
    	 
    	 
   public function admin_reports()
	{
	  $this->load->view('admin_reports',$data);  
	}
	

}








