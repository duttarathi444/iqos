<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Special_note extends CI_Controller {
	
	protected $access;
	
    public function __construct()
    {
        parent::__construct();
        $this->load->model('user');
        $this->load->library('session');
        $this->load->helper('url');
        
        $data['secure_id']=$_GET['a'];
        $this->access=$data['secure_id'];
        $data['check_valid']=$this->token_valid($data['secure_id']);
	    if($data['check_valid'][0]['id']!=1){
	        $this->load->view('product_module');
	    }
        
    }
    
    public function token_valid($b){
	    $this->load->model('Menu2_model');
	    $data['enter_code']=$b-128;
	    $data['user_id']=1;
	    $data['valid_token']=$this->Menu2_model->token_valid_data($data);
	        return $data['valid_token'];
	}
	
	public function note_master()
	{
        if($this->session->userdata('email_id') == TRUE) 
        { 
			 $data['email_id'] = $this->session->userdata('email_id');
            $data['roll_id'] = $this->session->userdata('role_id');
            $data['user_id'] = $this->session->userdata('user_id');
            $data['secure_code']=$this->access;
            $this->load->model('Note_model');
            $data['note_master_list']=$this->Note_model->note_master_list($data);
            $this->load->view('special_note_master',$data);
        }
        else
        {
            $data['s_out'] = 'Session Expired..';
            $this->load->view('login',$data);
        }
	}
	
    public function note_add()
    {
        if($this->session->userdata('email_id') == TRUE) 
        {
			 $data['email_id'] = $this->session->userdata('email_id');
            $data['roll_id'] = $this->session->userdata('roll_id');
            $data['user_id'] = $this->session->userdata('user_id');
			$this->load->model('stock_model');
			$data['secure_code']=$this->access;
			$data['customer_list']=$this->stock_model->all_customers_list($data['user_id']);
			$data['product_list'] = $this->stock_model->all_products_list($data['user_id']);
            $this->session->set_userdata('form_ts',$this->input->post('TS'));
            $this->load->view('special_note_add',$data);
        }
        else
        {
            $data['s_out'] = 'Session Expired..';
            $this->load->view('login',$data);
        }
    }
  
    public function note_registration()
    {
		if($this->input->post('TS') != $this->session->userdata('form_ts'))
		{
				if($this->session->userdata('email_id') == TRUE) 
				{
				    $data['secure_code']=$this->access;
					$data['email_id'] = $this->session->userdata('email_id');
					$this->session->set_userdata('form_ts',$this->input->post('TS'));	
					$data['role_id'] = $this->session->userdata('role_id');
					$data['user_id'] = $this->session->userdata('user_id');	
					$data['reg_date']=$_POST['reg_date'];
					$data['g_s_nm']=$_POST['g_s_nm'];
					$data['g_s_email']=$_POST['g_s_email'];
					$data['p_bougt_1']=$_POST['p_bougt_1'];
					$data['p_bougt_2']=$_POST['p_bougt_2'];
					$data['p_bougt_3']=$_POST['p_bougt_3'];
					$data['p_bougt_4']=$_POST['p_bougt_4'];
					$data['p_bougt_5']=$_POST['p_bougt_5'];
					$data['p_s_pasw_email']=0;
					$data['f_whome']=$_POST['f_whome'];
					$data['g_f_75_rec']=$_POST['g_f_75_rec'];
					$data['g_s_25_rec']=$_POST['g_s_25_rec'];
					$data['g_s_100_rec']=$_POST['g_s_100_rec'];
					$data['tr_date']=$_POST['tr_date'];
					$data['u_g_f_email']=$_POST['u_g_f_email'];
					$data['g_f_nm']=$_POST['g_f_nm'];
					$data['p_serial1']=$_POST['p_serial1'];
					$data['p_serial2']=$_POST['p_serial2'];
					$data['p_serial3']=$_POST['p_serial3'];
					$data['p_serial4']=$_POST['p_serial4'];
					$data['p_serial5']=$_POST['p_serial5'];
					$data['g_f_pasw_email']=0;
					$data['p_by_whom']=$_POST['p_by_whom'];
					$data['p_75rec_date']=$_POST['p_75rec_date'];
					$data['p_25rec_date']=$_POST['p_25rec_date'];
					$data['p_100rec_date']=$_POST['p_100rec_date'];
					$data['deposit1']=$_POST['deposit1'];
					$data['deposit2']=$_POST['deposit2'];
					$data['deposit3']=$_POST['deposit3'];
					$data['oder_id']=$_POST['oder_id'];
					$data['g_s_ph_no']=$_POST['g_s_ph_no'];
					$data['g_f_ph_no']=$_POST['g_f_ph_no'];
					$data['g_s_postal_code']=$_POST['g_s_postal_code'];
					$data['p_type1']=$_POST['p_type1'];
					$data['p_type2']=$_POST['p_type2'];
					$data['p_type3']=$_POST['p_type3'];
					$data['p_type4']=$_POST['p_type4'];
					$data['p_type5']=$_POST['p_type5'];
					$data['p_remark']=$_POST['p_remark'];
					$data['p_note']=$_POST['p_note'];
					$data['g_son_dob']=$_POST['g_son_dob'];
					$this->load->model('Note_model');
					$data['alert_flag'] = 0;
					$data['alert_message'] = "";
					$this->Note_model->note_reg($data);
					$data['alert_flag'] = 1;
					$data['alert_message'] = " New Special Note Id has been generated Successfully.";
					
					$data['note_master_list']=$this->Note_model->note_master_list($data);
					$this->load->view('special_note_master',$data);
				}
				else
				{
					$data['s_out'] = 'Session Expired..';
					$this->load->view('login',$data);
				}
		}
		else
			{
				$data['role_id'] = $this->session->userdata('role_id');
				$data['user_id'] = $this->session->userdata('user_id');
				$this->load->model('Note_model');
				$data['note_master_list']=$this->Note_model->note_master_list($data);
				$this->load->view('special_note_master',$data);
			}
    }	
   
    public function special_note_edit()
	{
        if($this->session->userdata('email_id') == TRUE) 
        {
            $data['secure_code']=$this->access;
			 $data['email_id'] = $this->session->userdata('email_id');
            $data['note_id'] = $_POST['product_id'];
            $data['user_id'] = $this->session->userdata('user_id');
            $this->load->model('Note_model');
			$this->load->model('stock_model');
			$data['customer_list']=$this->stock_model->all_customers_list($data);
			$data['product_list'] = $this->stock_model->all_products_list($data['user_id']);
            $data['note_list']=$this->Note_model->special_note_edit($data);
            $this->load->view('special_note_edit',$data);
        }
        else
        {
            $data['s_out'] = 'Session Expired..';
            $this->load->view('login',$data);
        }
    }

    public function special_note_update()
  	{   
		if($this->input->post('TS') != $this->session->userdata('form_ts'))
		{
	  
				if($this->session->userdata('email_id') == TRUE) 
				{
				    $data['secure_code']=$this->access;
					$data['email_id'] = $this->session->userdata('email_id');
					$this->session->set_userdata('form_ts',$this->input->post('TS'));	
					$data['role_id'] = $this->session->userdata('role_id');
					$data['user_id'] = $this->session->userdata('user_id');	
					$data['reg_date']=$_POST['reg_date'];
					$data['g_s_nm']=$_POST['g_s_nm'];
					$data['g_s_email']=$_POST['g_s_email'];
					$data['p_bougt_1']=$_POST['p_bougt_1'];
					$data['p_bougt_2']=$_POST['p_bougt_2'];
					$data['p_bougt_3']=$_POST['p_bougt_3'];
					$data['p_bougt_4']=$_POST['p_bougt_4'];
					$data['p_bougt_5']=$_POST['p_bougt_5'];
					$data['p_s_pasw_email']=0;
					$data['f_whome']=$_POST['f_whome'];
					$data['g_f_75_rec']=$_POST['g_f_75_rec'];
					$data['g_s_25_rec']=$_POST['g_s_25_rec'];
					$data['g_s_100_rec']=$_POST['g_s_100_rec'];
					$data['tr_date']=$_POST['tr_date'];
					$data['u_g_f_email']=$_POST['u_g_f_email'];
					$data['g_f_nm']=$_POST['g_f_nm'];
					$data['p_serial1']=$_POST['p_serial1'];
					$data['p_serial2']=$_POST['p_serial2'];
					$data['p_serial3']=$_POST['p_serial3'];
					$data['p_serial4']=$_POST['p_serial4'];
					$data['p_serial5']=$_POST['p_serial5'];
					$data['g_f_pasw_email']=0;
					$data['p_by_whom']=$_POST['p_by_whom'];
					$data['p_75rec_date']=$_POST['p_75rec_date'];
					$data['p_25rec_date']=$_POST['p_25rec_date'];
					$data['p_100rec_date']=$_POST['p_100rec_date'];
					$data['deposit1']=$_POST['deposit1'];
					$data['deposit2']=$_POST['deposit2'];
					$data['deposit3']=$_POST['deposit3'];
					$data['oder_id']=$_POST['oder_id'];
					$data['g_s_ph_no']=$_POST['g_s_ph_no'];
					$data['g_f_ph_no']=$_POST['g_f_ph_no'];
					$data['g_s_postal_code']=$_POST['g_s_postal_code'];
					$data['p_type1']=$_POST['p_type1'];
					$data['p_type2']=$_POST['p_type2'];
					$data['p_type3']=$_POST['p_type3'];
					$data['p_type4']=$_POST['p_type4'];
					$data['p_type5']=$_POST['p_type5'];
					$data['p_remark']=$_POST['p_remark'];
					$data['p_note']=$_POST['p_note'];
					$data['g_son_dob']=$_POST['g_son_dob'];
					//echo "sourav";
					$data['note_id'] =$_POST['code_idd'];
					
					//echo "".$data['note_id'];
					
					$this->load->model('Note_model');
					$data['alert_flag'] = 0;
					$data['alert_message'] = "";
					$this->Note_model->special_note_update($data);
					$data['alert_flag'] = 1;
					$data['alert_message'] = "Note details for Id ".$data['note_id']." has been updated successfully";
					 $data['activity_id'] = 2;
					$data['key_id'] = $data['note_id'];
					$data['page_id'] = 11;
					$data['module_id'] = 11;
					$this->load->model('Admin_model');
					$this->Admin_model->bye_user_log($data) ;
					$data['note_master_list']=$this->Note_model->note_master_list($data);
					$this->load->view('special_note_master',$data);
				}
				else
				{
					$data['s_out'] = 'Session Expired..';
					$this->load->view('login',$data);
				}
		}
		else
			{
				$data['role_id'] = $this->session->userdata('role_id');
				$data['user_id'] = $this->session->userdata('user_id');
				$this->load->model('Note_model');
				$data['note_master_list']=$this->Note_model->note_master_list($data);
				$this->load->view('special_note_master',$data);
			}
  	}
	
	
	
	public function special_note_view()
	{
        if($this->session->userdata('email_id') == TRUE) 
        {
            $data['secure_code']=$this->access;
			 $data['email_id'] = $this->session->userdata('email_id');
			$data['role_id'] = $this->session->userdata('role_id');
			$data['user_id'] = $this->session->userdata('user_id');
            $data['note_id'] = $_POST['product_id6'];
            $this->load->model('Note_model');
			$data['key_id'] = $data['note_id'];
			 $data['activity_id'] = 4;
			$data['page_id'] = 11;
			$data['module_id'] = 11;
			$this->load->model('Admin_model');
			$this->Admin_model->bye_user_log($data) ;
            $data['specl_note_list']=$this->Note_model->special_note_edit($data);
            $this->load->view('special_note_view',$data);
			
        }
        else
        {
            $data['s_out'] = 'Session Expired..';
            $this->load->view('login',$data);
        }
    }

    public function note_delete()
    {
        if($this->session->userdata('email_id') == TRUE) 
        {
            $data['secure_code']=$this->access;
			 $data['email_id'] = $this->session->userdata('email_id');
			$data['role_id'] = $this->session->userdata('role_id');
			$data['user_id'] = $this->session->userdata('user_id');
            $data['note_id3'] = $_POST['product_id3'];
            $this->load->model('Note_model');
			$data['alert_flag'] = 0;
            $data['alert_message'] = "";
            $this->Note_model->special_note_delete($data);
  			$data['alert_flag'] = 1;
            $data['alert_message'] = "Special Note details for Id ".$data['note_id3']." has been deleted";
			 $data['key_id'] = $data['note_id3'];
			$data['activity_id'] = 3;
			$data['page_id'] = 11;
			$data['module_id'] = 11;
			$this->load->model('Admin_model');
			$this->Admin_model->bye_user_log($data); 
            $data['note_master_list']=$this->Note_model->note_master_list($data);
            $this->load->view('special_note_master',$data);
        }
        else
        {
            $data['s_out'] = 'Session Expired..';
            $this->load->view('login',$data);
        }
        
    }
	
    public function barcode_exist()
    {
        if($this->session->userdata('email_id') == TRUE) 
        {
            $data['secure_code']=$this->access;
            $this->load->model('Note_model');
            $data['code'] = $_POST['code'];
            $data['barcode']=$this->Note_model->exist_barcode($data);
            echo json_encode($data['barcode']);
        }
        else
        {
            $data['s_out'] = 'Session Expired..';
            $this->load->view('login',$data);
        }
    }
			
  
}

	
	
	
	
	
	
	
	
	
	
	





























