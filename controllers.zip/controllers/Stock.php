<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Stock extends CI_Controller {
	
	public $access;
    public function __construct()
	{
		parent::__construct();
		$this->load->model('user');
		$this->load->library('session');
		$this->load->helper('url');
		if($this->session->userdata('email_id') == TRUE)
		{
			
			$data['email_id'] = $this->session->userdata('email_id');
			$this->access=$data['email_id'];
		}
		else
		{
			$data['s_out'] = 'Session Expired..';
			$this->load->view('login',$data);
		}
	}
	
	public function stock_master()
	{
		$data['email_id']=$this->access;
		//echo "".$data['email_id'];
		// $this->load->model('user');
		$data['role_id'] = $this->session->userdata('role_id');
		$data['user_id'] = $this->session->userdata('user_id');
		//echo $data['user_id'];
		// $arrc =  $_POST['basic'];
		//  $arrlength = count($arrc);
		$this->load->model('stock_model');
		$data['stock_master_list']=$this->stock_model->bye_stock_list($data);
		//  $data['arrlength'] = $arrc;
		// $data['delete_flag'] = 0; 
		

		$this->load->view('stock_master',$data);
       
		
		
	}
	
	public function stock_module()
	{
		$data['email_id']=$this->access;
	    $this->load->view('stock_module');
	}

		
	 public function stock_add()
  {
        $data['email_id']=$this->access;
        $data['role_id'] = $this->session->userdata('role_id');
        $data['user_id'] = $this->session->userdata('user_id');
		$this->session->set_userdata('form_ts',$this->input->post('TS'));

		$this->load->model('Product_model');
		 //$this->load->model('Rate_model');
		 //$data['rate_master_list']=$this->Rate_model->bye_hub_list();
	    //$data['agent_master_list']=$this->admin_model->agent_list();
	    $data['product_master_list']=$this->Product_model->bye_product_list();
		//print_r($data['product_master_list']);
		$this->load->view('stock_add',$data);
		
		
  }
  
  
    public function upload_image($file_name,$filename){
		$config['file_name'] = $filename;
		$config['overwrite'] = TRUE;
		$config['upload_path'] = $_SERVER['DOCUMENT_ROOT'].'/iqos/assets/stock_img/';
        $config['allowed_types'] = 'gif|jpg|png';
		$this->load->library('upload', $config);
		$this->upload->initialize($config);
		if($this->upload->do_upload($file_name)){
			return $filename;
		}
	}
  
  
   public function stock_in()
   {
		if($this->input->post('TS') != $this->session->userdata('form_ts'))
		{   
	
				$data['email_id']=$this->access;
				$data['role_id'] = $this->session->userdata('role_id');
				$data['user_id'] = $this->session->userdata('user_id');
				$this->session->set_userdata('form_ts',$this->input->post('TS'));
				//$data['user_id']=1;
                $data['receivded_from']=$_POST['receivded_from'];
                $data['shipment_name']=$_POST['shipment_name'];
                $data['carton_no']=$_POST['carton_no'];
                $data['receive_date']=$_POST['receive_date'];
                
                $data['products_id']=$_POST['al-products'];
                //$data['barcodes']=$_POST['al-barcodes'];
                $data['quantities']=$_POST['al-quantities'];
                
                $name = $_FILES["image1"]["name"];
		        if ($name != '') {
			    $data['ext'] = explode(".", $name)[1];
		        }
                
				$data['alert_flag'] = 0;
				$data['alert_message'] = "";
		
				$this->load->model('stock_model');
				$data['result'] = $this->stock_model->stock_reg($data);
				
				$name = $_FILES["image1"]["name"];
		        if ($name != '') {
        	    $data['img_name1'] = $this->upload_image('image1',$data['result'][0]['img_path']);
		        }
				
				$data['alert_flag'] = 1;
				$data['alert_message'] = "New Stock has been added successfully";
				$data['stock_master_list']=$this->stock_model->bye_stock_list($data);
				$this->load->view('stock_master',$data);
			
		}
		else
			{
				$data['role_id'] = $this->session->userdata('role_id');
				$data['user_id'] = $this->session->userdata('user_id');
				$this->load->model('stock_model');
				$data['stock_master_list']=$this->stock_model->bye_stock_list($data);
				$this->load->view('stock_master',$data);
			}
		
		
        
	   
   }
   
   
    public function product_list(){
        $this->load->model('stock_model');
        $data['order_id'] = $_POST['id'];
        $rs=$this->stock_model->product_by_orid($data);
        echo json_encode($rs);
    }
   
   
    
    public function stock_edit()
	{
	    
	
	   	//echo "sougata";
		
		 $data['order_no'] = $_POST['order_no'];
		 //echo $data['order_no'];
	    $this->load->model('stock_model');
		$this->load->model('Product_model');
	     $data['product_master_list']=$this->Product_model->bye_product_list();
		  if($data['order_no']!='')
		 {
	     $data['stock_list']=$this->stock_model->stock_edit($data);
		 } 
		  
		
		 //print_r($data['stock_list']);
         $this->load->view('stock_edit',$data);
		 
		
	 }
	 
	 
	 public function stockdetails_update()
  	{   
	      
		  $data['order_no'] = $_POST['order_no'];
	      	//echo $data['order_no'];
	        $data['name']=$_POST['province'];
       		  $data['product_id']=$_POST['product_id'];
				//echo $data['product_id'];
				$data['region']=$_POST['region'];
				$data['postal_code']=$_POST['postal_code'];
				$data['barcode']=$_POST['barcode'];
                $data['recevided_from']=$_POST['recevided_from'];
                $data['shipment']=$_POST['shipment'];
                $data['carton']=$_POST['carton'];
				// $data['rdate']=$_POST['rdate'];
              
               // $data['log_id']=$_POST['login_id'];
				$data['alert_flag'] = 0;
				$data['alert_message'] = "";
				
	   
        $this->load->model('stock_model');
	   $data['stock_master_list']= $this->stock_model->bye_stock_update($data);
		$data['alert_flag'] = 1;
		$data['alert_message'] = "Product details for Id has been updated successfully";
	    $data['stock_master_list']=$this->stock_model->bye_stock_list($data);
	    $this->load->view('stock_master',$data);
        
		
		
       
  	}
	
	
	public function stock_view()
	{
	   //echo "sougata";
		
		 $data['order_no'] = $_POST['order_id6'];
		 //echo $data['order_no'];
	    $this->load->model('stock_model');
	    
	     $data['stock_list']=$this->stock_model->stock_edit($data);
         $this->load->view('stock_view',$data);
		 
        
    }
	 
   public function product_sale(){
	   $data['email_id']=$this->access;
	   $data['role_id'] = $this->session->userdata('role_id');
		$data['user_id'] = $this->session->userdata('user_id');
       $this->load->model('stock_model');
	   $data['product_sale_details']=$this->stock_model->all_products_details($data);
       $this->load->view('product_sale_master',$data);
   }
   
   public function product_stock_out()
   {
	   $data['email_id']=$this->access;
       $this->load->model('stock_model');
       $data['user_id'] = $this->session->userdata('user_id');
	   $data['customer_list']=$this->stock_model->all_customers_list($data);
	   //$this->stock_model->all_products_list();
	   $data['device_list'] = $this->stock_model->device_list();
	   $data['heets_list'] = $this->stock_model->heets_list();
	   
       $this->load->view('product_sale_add',$data);
   }
    
    public function all_customer(){
        $data['cus_id'] = $_POST['cus_id'];
        $this->load->model('stock_model');
	    $data['customer_data']=$this->stock_model->customer_data($data);
	    echo json_encode($data['customer_data']);
    }
	
	public function all_product_list(){
		$data['email_id']=$this->access;
		$data['role_id'] = $this->session->userdata('role_id');
		$data['user_id'] = $this->session->userdata('user_id');
	   $data['cus_id'] = $_POST['cus_id'];
        $this->load->model('stock_model');
	    $data['product_data']=$this->stock_model->product_by_id($data);
	    echo json_encode($data['product_data']);
	}
	
	
	
	public function sale_information()
	{
		if($this->input->post('TS') != $this->session->userdata('form_ts'))
		{
			$data['email_id']=$this->access;
			$this->session->set_userdata('form_ts',$this->input->post('TS'));	
			$data['role_id'] = $this->session->userdata('role_id');
			$data['user_id'] = $this->session->userdata('user_id');
			$this->load->model('stock_model');
			$data['select_date'] = $_POST['select_date'];
			$data['cus_email_id'] = $_POST['cus_email_id'];
			$data['product_id'] = $_POST['product_id'];
			$data['serial_no'] = $_POST['serial_no'];
			$data['sap_no'] = $_POST['sap_no'];
			$data['quantity'] = $_POST['quantity'];
			$data['res_valid'] = $_POST['res_valid'];
			$data['registation_date'] = $_POST['registation_date'];
			$data['pe1_date'] = $_POST['pe1_date'];
			$data['pe2_date'] = $_POST['pe2_date'];
			$data['pe3_date'] = $_POST['pe3_date'];
			
			$data['product_ids'] = $_POST['product_ids'];
			$data['product_quantity'] = $_POST['product_quantitys'];
			
			$data['submited_id']=$this->stock_model->sale_submited_data($data);
			if($data['submited_id']>0){
			$data['alert_flag'] = 1;
			$data['alert_message'] = "New Sale has been added successfully";
			$data['product_sale_details']=$this->stock_model->all_products_details($data);
			$this->load->view('product_sale_master',$data);
			}
		}
		else
			{
				$data['role_id'] = $this->session->userdata('role_id');
				$data['user_id'] = $this->session->userdata('user_id');
				$this->load->model('stock_model');
				$data['product_sale_details']=$this->stock_model->all_products_details($data);
				$this->load->view('product_sale_master',$data);
			}
	}
	
	public function view_stock_in_details()
	{
		$data['email_id']=$this->access;
		$data['role_id'] = $this->session->userdata('role_id');
		$data['user_id'] = $this->session->userdata('user_id');
	    $this->load->model('stock_model');
	    $data['order_id'] = $_POST['order_id6'];
	    $data['stock_in_data']=$this->stock_model->stock_in_details_view($data);
	    $data['path'] = $_SERVER['HTTP_HOST'].'/iqos/assets/stock_img/';
		$data['key_id'] = $data['order_id'];
		$data['activity_id'] = 4;
		$data['page_id'] = 4;
		$data['module_id'] = 4;
		$this->load->model('Admin_model');
		$this->Admin_model->bye_user_log($data);
	    $this->load->view('stock_in_view',$data);
	}
	
	public function all_product_show(){
	    $this->load->model('stock_model');
	    $data['cus_id'] = $_POST['cus_id'];
	    $data['stock_in_data']=$this->stock_model->product_details_by_id($data);
	    echo json_encode($data['stock_in_data']);
	}
	
  
   public function product_swap(){
	   $data['email_id']=$this->access;
        $this->load->model('stock_model');
        $data['sale_id'] = $_POST['sale_id6'];
        $data['user_id'] = $this->session->userdata('user_id');
	    $data['sale_products_data']=$this->stock_model->sale_product_by_id($data);
	   $data['customer_list']=$this->stock_model->all_customers_list($data);
	   $data['product_list'] = $this->stock_model->all_products_list();
	   $data['swap_list']=$this->stock_model->view_prd_swap_list($data);
       $this->load->view('product_swap',$data);
       
        }
   
   
   
   public function product_land()
   {
     $this->load->model('stock_model');
	 $data['email_id']=$this->access;
	 $data['user_id'] = $this->session->userdata('user_id');
      $data['customer_list']=$this->stock_model->all_customers_list($data);
	 $data['product_list'] = $this->stock_model->all_products_list();
    $this->load->view('product_lend',$data);
       
 
   }
   
   
    public function product_back()
   {
	   $data['email_id']=$this->access;
     $this->load->model('stock_model');
     $data['user_id'] = $this->session->userdata('user_id');
      $data['customer_list']=$this->stock_model->all_customers_list($data);
	 $data['product_list'] = $this->stock_model->all_products_list();
    $this->load->view('product_back',$data);
       
 
   }

    public function stock_in_edit()
	{
		$data['email_id']=$this->access;
        $this->load->model('stock_model');
        $this->load->model('Product_model');
	    $data['order_id'] = $_POST['order_no'];
	    $data['stock_in_data']=$this->stock_model->stock_in_details_view($data);
	    $data['edit'] = 1;
	   // print_r($data['stock_in_data']);
	    $data['product_master_list']=$this->Product_model->bye_product_list();
	    $this->load->view('stock_in_edit',$data);
    }
	
	public function stock_product_delete(){
	    $this->load->model('stock_model');
	    $data['prd_stock_id'] = $_POST['prd_stock_id'];
	    $data['delete_stock_in_data']=$this->stock_model->delete_stock_in_product($data);
	    echo json_encode($data['delete_stock_in_data']);
	}
	
	public function stock_in_edit_data()
	{
		if($this->input->post('TS') != $this->session->userdata('form_ts'))
		{
				$data['email_id']=$this->access;
				$this->session->set_userdata('form_ts',$this->input->post('TS'));	
				$data['role_id'] = $this->session->userdata('role_id');
				$data['user_id'] = $this->session->userdata('user_id');
				$this->load->model('stock_model');
				$data['carton_no'] = $_POST['carton_no'];
				$data['receive_date'] = $_POST['receive_date'];
				$data['receivded_from'] = $_POST['receivded_from'];
				$data['shipment_name'] = $_POST['shipment_name'];
				$data['order_id'] = $_POST['all_order_id'];
				//$data['user_id'] = 1;

				$name = $_FILES["image1"]["name"];
				if ($name != '') {
				$data['ext'] = explode(".", $name)[1];
				}else{
				$data['ext'] = '';
				}

				$data['all_stock_id'] = $_POST['all_stock_id'];
				$data['all_product_id'] = $_POST['all_product_id'];
				//$data['all_barcode_no'] = $_POST['all_barcode_no'];
				$data['all_product_quantity'] = $_POST['all_product_quantity'];

				$data['al-products'] = $_POST['al-products'];
				// $data['al-barcodes'] = $_POST['al-barcodes'];
				$data['al-quantities'] = $_POST['al-quantities'];
				$data['edited_stock_in_data']=$this->stock_model->stock_in_data_edit($data);
				//print_r($data['edited_stock_in_data']);
				if($data['edited_stock_in_data']!=''){
				$name = $_FILES["image1"]["name"];
				if ($name != '') {
				$data['img_name1'] = $this->upload_image('image1',$data['edited_stock_in_data'][0]['invoice_img']);
				}
				}

				$data['alert_flag'] = 1;
				$data['alert_message'] = "Data has been Update successfully";
				$data['activity_id'] = 2;
				$data['key_id'] = $data['order_id'];
				$data['page_id'] = 4;
				$data['module_id'] = 4;
				$this->load->model('Admin_model');
				$this->Admin_model->bye_user_log($data);
				$data['stock_master_list']=$this->stock_model->bye_stock_list($data);
				$this->load->view('stock_master',$data);
		}
		else
			{
				$data['role_id'] = $this->session->userdata('role_id');
				$data['user_id'] = $this->session->userdata('user_id');
				$this->load->model('stock_model');
				$data['stock_master_list']=$this->stock_model->bye_stock_list($data);
				$this->load->view('stock_master',$data);
			}
	}
	
	public function stock_delete()
	{
		$data['email_id']=$this->access;
		$data['role_id'] = $this->session->userdata('role_id');
		$data['user_id'] = $this->session->userdata('user_id');
		$this->load->model('stock_model');
		$data['order_id'] = $_POST['order_id3'];
		$data['deleted_stock_in_data']=$this->stock_model->delete_all_product_by_id($data);
		$data['alert_flag'] = 1;
		$data['alert_message'] = "Data has been Deleted";
		$data['key_id'] = $data['order_id'];
		$data['activity_id'] = 3;
		$data['page_id'] = 4;
		$data['module_id'] = 4;
		$this->load->model('Admin_model');
		$this->Admin_model->bye_user_log($data);
		$data['stock_master_list']=$this->stock_model->bye_stock_list($data);
		$this->load->view('stock_master',$data);
	}
	
	public function show_sales_by_id()
	{
		$data['email_id']=$this->access;
		$data['role_id'] = $this->session->userdata('role_id');
		$data['user_id'] = $this->session->userdata('user_id');
	    $this->load->model('stock_model');
	    $data['sale_id'] = $_POST['sale_id6'];
		$data['key_id'] = $data['sale_id'];
		$data['activity_id'] = 4;
		$data['page_id'] = 5;
		$data['module_id'] = 5;
		$this->load->model('Admin_model');
		$this->Admin_model->bye_user_log($data);
	    $data['sale_products_data']=$this->stock_model->sale_product_by_id($data);
	    $data['sale_product_show']=$this->stock_model->show_sale_product($data);
	    $this->load->view('stock_out_view',$data);
	}
	
	public function delete_sale_data_by_id()
	{
		$data['email_id']=$this->access;
		$data['role_id'] = $this->session->userdata('role_id');
		$data['user_id'] = $this->session->userdata('user_id');
	    $this->load->model('stock_model');
	    $data['sale_id'] = $_POST['sale_id3'];
		$data['key_id'] = $data['sale_id'];
		$data['activity_id'] = 3;
		$data['page_id'] = 5;
		$data['module_id'] = 5;
		$this->load->model('Admin_model');
		$this->Admin_model->bye_user_log($data);
	    $this->stock_model->sale_product_delete_by_id($data);
	    $this->product_sale();
	}
	
	public function sale_data_edit()
	{
		$data['email_id']=$this->access;
		//echo"".$data['email_id'];
	    $this->load->model('stock_model');
	    $data['sale_id'] = $_POST['sale_id'];
	    $data['user_id'] = $this->session->userdata('user_id');	
	    $data['sale_products_data']=$this->stock_model->sale_product_by_id($data);
	    $data['customer_list']=$this->stock_model->all_customers_list($data);
	    $data['product_list'] = $this->stock_model->all_products_list();
	    $this->load->view('product_sale_edit',$data);
	}
	
	public function updated_sale_information()
	{
		if($this->input->post('TS') != $this->session->userdata('form_ts'))
		{
			$data['email_id']=$this->access;
			$this->session->set_userdata('form_ts',$this->input->post('TS'));	
			$data['role_id'] = $this->session->userdata('role_id');
			$data['user_id'] = $this->session->userdata('user_id');	
			$this->load->model('stock_model');
			$data['sale_id'] = $_POST['sale_id'];
			$data['select_date'] = $_POST['select_date'];
			$data['cus_email_id'] = $_POST['cus_email_id'];
			$data['product_id'] = $_POST['product_id'];
			$data['serial_no'] = $_POST['serial_no'];
			$data['sap_no'] = $_POST['sap_no'];
			$data['quantity'] = $_POST['quantity'];
			$data['res_valid'] = $_POST['res_valid'];
			$data['registation_date'] = $_POST['registation_date'];
			$data['pe1_date'] = $_POST['pe1_date'];
			$data['pe2_date'] = $_POST['pe2_date'];
			$data['pe1_status'] = $_POST['pe1_status'];
			$data['pe2_status'] = $_POST['pe2_status'];
			$data['total_quanti'] = $_POST['quanti'];
			//$data['user_id']=1;
			$data['pe3_date'] = $_POST['pe3_date'];
			$data['pe3_status'] = $_POST['pe3_status'];
			$data['update_success']=$this->stock_model->updated_sale_data($data);
			if($data['update_success']){
			   $data['alert_flag'] = 1;
			$data['alert_message'] = "Product details for Id has been updated successfully";
			$data['activity_id'] = 2;
			$data['key_id'] = $data['sale_id'];
			$data['page_id'] = 5;
			$data['module_id'] = 5;
			$this->load->model('Admin_model');
			$this->Admin_model->bye_user_log($data);
			$data['product_sale_details']=$this->stock_model->all_products_details($data);
		  $this->load->view('product_sale_master',$data);
			}
		}
	else
		{
		$data['role_id'] = $this->session->userdata('role_id');
		$data['user_id'] = $this->session->userdata('user_id');
		$this->load->model('stock_model');
		 $data['product_sale_details']=$this->stock_model->all_products_details($data);
		$this->load->view('product_sale_master',$data);
		}
	
	}
	
	public function check_carton(){
		$data['email_id']=$this->access;
	    $this->load->model('stock_model');
	    $data['carton_id'] = $_POST['id'];
	    $data['user_id']=1;
	    $data['car_id']=$this->stock_model->check_carton($data);
	    echo json_encode($data['car_id']);
	}
	
	 public function product_replace(){
		 $data['email_id']=$this->access;
		 $data['role_id'] = $this->session->userdata('role_id');
		$data['user_id'] = $this->session->userdata('user_id');
       $this->load->model('stock_model');
	   $data['product_sale_details']=$this->stock_model->all_products_details($data);
       $this->load->view('product_swap_master',$data);
   }
   
   	public function swap_view(){
		$data['email_id']=$this->access;
	    $this->load->model('stock_model');
	    $data['sale_id'] = $_POST['sale_id6'];
	    $data['user_id'] = $this->session->userdata('user_id');
	    $data['sale_products_data']=$this->stock_model->sale_product_by_id($data);
	    $data['swap_list']=$this->stock_model->view_prd_swap_list($data);
	    $this->load->view('product_swap_view',$data);
	}
	
		public function replace_new_product(){
			$data['email_id']=$this->access;
	    $this->load->model('stock_model');
	    $data['sale_id'] = $_POST['sale_id3'];
	    $data['registation_date'] = $_POST['registation_date'];
	    $data['product_id'] = $_POST['product_id'];
	    $data['serial_num'] = $_POST['serial_num'];
	    $data['glove'] = $_POST['glove'];
	    $data['prd_qty'] = $_POST['product_quantity'];
	    $data['user_id']=$this->session->userdata('user_id');
	    $data['swap_date'] = $_POST['swap_date'];
	    $data['res_valid'] = $_POST['res_valid'];
	    $data['prod_bar'] = 0;
	    $this->stock_model->replace_new_device($data);
	   	$data['sale_products_data']=$this->stock_model->sale_product_by_id($data);
	   	$data['product_sale_details']=$this->stock_model->all_products_details($data);
	   	$data['alert_flag'] = 1;
		$data['alert_message'] = "Product Swap to another Product successfully";
	   	$this->load->view('product_swap_master',$data);
	}
	
	public function swap_data_edit(){
		$data['email_id']=$this->access;
	    $this->load->model('stock_model');
	    $data['sale_id'] = $_POST['sale_id'];
	    $data['user_id']=$this->session->userdata('user_id');
	    $data['swap_list']=$this->stock_model->view_prd_swap_list($data);
	    $data['product_list'] = $this->stock_model->all_products_list();
	    $data['sale_products_data']=$this->stock_model->sale_product_by_id($data);
	    $this->load->view('product_swap_edit',$data);
	}
	
	public function swap_update(){
		$data['email_id']=$this->access;
	    $this->load->model('stock_model');
	    $data['swap_id'] = $_POST['swap_id'];
	    $data['user_id']=$this->session->userdata('user_id');
	    $data['registation_date'] = $_POST['registation_date'];
	    $data['product_id'] = $_POST['product_id'];
	    $data['serial_num'] = $_POST['serial_num'];
	    $data['glove'] = $_POST['glove'];
	    $data['prd_qty'] = $_POST['product_quantity'];
	    $data['swap_date'] = $_POST['swap_date'];
	    $data['res_valid'] = $_POST['res_valid'];
	    $data['prod_bar'] = 0;
	    $data['update_result'] = $this->stock_model->swap_update_data($data);
	    $data['product_sale_details']=$this->stock_model->all_products_details($data);
	    $data['alert_flag'] = 1;
		$data['alert_message'] = "Swap Product is Update successfully";
	    $this->load->view('product_swap_master',$data);
	}
	
	public function delete_swap_data_by_id(){
		$data['email_id']=$this->access;
	    $this->load->model('stock_model');
	    $data['sale_id'] = $_POST['p_sale_id'];
	    $data['user_id']=$this->session->userdata('user_id');
	    $data['delete_status']=$this->stock_model->delete_swap_data($data);
	    $data['sale_products_data']=$this->stock_model->sale_product_by_id($data);
	    $data['product_sale_details']=$this->stock_model->all_products_details($data);
	    $data['alert_flag'] = 1;
		$data['alert_message'] = "Swap Product is Delete successfully";
	    $this->load->view('product_swap_master',$data);
	}
	
}







