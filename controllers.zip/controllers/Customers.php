<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Customers extends CI_Controller {
	
    	public function __construct()
    {
        parent::__construct();
		$this->load->model('user');
        $this->load->library('session');
        $this->load->helper('url');
    }

	
	public function god_son_master()
	{
	    if($this->session->userdata('email_id') == TRUE)
		{	
			 $data['email_id'] = $this->session->userdata('email_id');
			// $this->load->model('user');
			$data['role_id'] = $this->session->userdata('role_id');
			$data['user_id'] = $this->session->userdata('user_id');
			// $arrc =  $_POST['basic'];
			//  $arrlength = count($arrc);
			$this->load->model('Customer_model');
			$data['customer_master_list']=$this->Customer_model->bye_god_son_list($data);

			$data['god_father_list']=$this->Customer_model->bye_god_father_list($data);

			//  $data['arrlength'] = $arrc;
			// $data['delete_flag'] = 0; 

			$this->load->view('god_son_list',$data);
       
		}
		 else
        {
            $data['s_out'] = 'Session Expired..';
            $this->load->view('login',$data);
        }
	}
	
	
	
	public function god_father_master()
	{
	  if($this->session->userdata('email_id') == TRUE)
		{
		 $data['email_id'] = $this->session->userdata('email_id');
		// $this->load->model('user');
		$data['role_id'] = $this->session->userdata('role_id');
		$data['user_id'] = $this->session->userdata('user_id');
		// $arrc =  $_POST['basic'];
		//  $arrlength = count($arrc);
		$this->load->model('Customer_model');
		$data['customer_master_list']=$this->Customer_model->bye_god_father_list($data);
		//  $data['arrlength'] = $arrc;
		// $data['delete_flag'] = 0; 

		$this->load->view('god_father_list',$data);
		}
	 else
		{
		$data['s_out'] = 'Session Expired..';
		$this->load->view('login',$data);
		}

	}
	
	
	
		
	public function customers_module()
	{
		if($this->session->userdata('email_id') == TRUE)
		{
		$data['email_id'] = $this->session->userdata('email_id');
		$data['role_id'] = $this->session->userdata('role_id');
		$data['user_id'] = $this->session->userdata('user_id');	
	    $this->load->view('customers_module');
		}
	    else
        {
            $data['s_out'] = 'Session Expired..';
            $this->load->view('login',$data);
        }
	}
	
	

  
  
  public function god_son_add()
  {
      if($this->session->userdata('email_id') == TRUE)
		{
		$data['email_id'] = $this->session->userdata('email_id');
		$data['role_id'] = $this->session->userdata('role_id');
		$data['user_id'] = $this->session->userdata('user_id');
		$this->session->set_userdata('form_ts',$this->input->post('TS'));
		$this->load->model('Customer_model');
		//$this->load->model('Rate_model');
		//$data['rate_master_list']=$this->Rate_model->bye_hub_list();
		//$data['agent_master_list']=$this->admin_model->agent_list();
		$data['customer_type']=$this->Customer_model->bye_customer_type();
		$data['customer_master_list']=$this->Customer_model->customer_god_father_list($data);
		//print_r($data['product_master_list']);
		$this->load->view('god_son_add',$data);

		}
	    else
        {
            $data['s_out'] = 'Session Expired..';
            $this->load->view('login',$data);
        }

	}
       
       
       	
	public function god_father_list(){
	   $data['cus_id'] = $_POST['cus_id'];
        $this->load->model('Customer_model');
  		
      
	    $data['product_data']=$this->Customer_model->customer_by_id($data);
	    echo json_encode($data['product_data']);
	}
  
  
  public function god_father_add()
  {
       if($this->session->userdata('email_id') == TRUE) 
	   {
         $data['email_id'] = $this->session->userdata('email_id');
        $data['role_id'] = $this->session->userdata('role_id');
        $data['user_id'] = $this->session->userdata('user_id');
		$this->session->set_userdata('form_ts',$this->input->post('TS'));

		$this->load->model('Customer_model');
		 //$this->load->model('Rate_model');
		 //$data['rate_master_list']=$this->Rate_model->bye_hub_list();
	    //$data['agent_master_list']=$this->admin_model->agent_list();
	    $data['customer_type']=$this->Customer_model->bye_customer_type();
		$data['customer_master_list']=$this->Customer_model->customer_god_father_list($data);

		//print_r($data['product_master_list']);
		$this->load->view('god_father_add',$data);
	   }
	   else
        {
            $data['s_out'] = 'Session Expired..';
            $this->load->view('login',$data);
        }
      
      
 }
  
  
  
  
   public function Customers_registration()
   {
	   if($this->input->post('TS') != $this->session->userdata('form_ts'))
		{
			if($this->session->userdata('email_id') == TRUE) 
				{
				$data['email_id'] = $this->session->userdata('email_id');
				$this->session->set_userdata('form_ts',$this->input->post('TS'));	
				$data['role_id'] = $this->session->userdata('role_id');
				$data['user_id'] = $this->session->userdata('user_id');

				//echo"agent".$data['user_id'];
				//$data['role_id'] = $this->session->userdata('role_id');
				$data['name']=$_POST['name'];

				$data['father']=$_POST['father'];

				//	$data['father']=$_POST['father'];
				//	echo $data['father'];
				$data['fid']=$_POST['fid'];
				if($_POST['father']!='')
				{
				$data['father']=$_POST['father'];

				}
				else
				{
				$data['father']=0;

				}
				$data['product_type']=$_POST['product_type'];
				//echo $data['product_id'];
				$data['product_code']=$_POST['product_code'];
				$data['email']=$_POST['email'];
				$data['phone']=$_POST['phone'];
				$data['dob']=$_POST['dob'];
				$data['pcode']=$_POST['pcode'];
				$data['date']=$_POST['date'];
				$data['alert_flag'] = 0;
				$data['alert_message'] = "";
				$this->load->model('Customer_model');
				$this->Customer_model->cust_reg($data);
				$data['alert_flag'] = 1;
				$data['alert_message'] = "New customer has been added successfully";
				$data['customer_master_list']=$this->Customer_model->bye_god_son_list($data);
				$this->load->view('god_son_list',$data);
				}
				else
				{
					$data['s_out'] = 'Session Expired..';
					$this->load->view('login',$data);
				}
		}
		else
			{
				$data['role_id'] = $this->session->userdata('role_id');
				$data['user_id'] = $this->session->userdata('user_id');
				$this->load->model('Customer_model');
				$data['customer_master_list']=$this->Customer_model->bye_god_son_list($data);
				$this->load->view('god_son_list',$data);
			}
			
		
	  }
   
    public function god_father_registration()
   {
	   if($this->input->post('TS') != $this->session->userdata('form_ts'))
		{
			if($this->session->userdata('email_id') == TRUE) 
				{
				$data['email_id'] = $this->session->userdata('email_id');
				$this->session->set_userdata('form_ts',$this->input->post('TS'));	
				$data['role_id'] = $this->session->userdata('role_id');
				$data['user_id'] = $this->session->userdata('user_id');
				//echo"agent".$data['user_id'];
				//$data['role_id'] = $this->session->userdata('role_id');
				$data['fname']=$_POST['fname'];
				$data['lname']=$_POST['lname'];
				//	$data['father']=$_POST['father'];
				//	echo $data['father'];
				$data['email']=$_POST['email'];

				$data['phone']=$_POST['phone'];
				//echo $data['product_id'];
				$data['dob']=$_POST['dob'];
				$data['pcode']=$_POST['pcode'];
				// $data['log_id']=$_POST['login_id'];
				$data['alert_flag'] = 0;
				$data['alert_message'] = "";
				$this->load->model('Customer_model');
				$this->Customer_model->god_father_reg($data);
				$data['alert_flag'] = 1;
				$data['alert_message'] = "New god-father has been added successfully";
				$data['customer_master_list']=$this->Customer_model->bye_god_father_list($data);
				$this->load->view('god_father_list',$data);
				}
			else
				{
					$data['s_out'] = 'Session Expired..';
					$this->load->view('login',$data);
				}
		}
		else
			{
				$data['role_id'] = $this->session->userdata('role_id');
				$data['user_id'] = $this->session->userdata('user_id');
				$this->load->model('Customer_model');
				$data['customer_master_list']=$this->Customer_model->bye_god_father_list($data);
				$this->load->view('god_father_list',$data);
			}
    }	
   
   
   
   
   
    public function customers_edit()
	{
	    if($this->session->userdata('email_id') == TRUE) 
        {
			 $data['email_id'] = $this->session->userdata('email_id');
			$data['role_id'] = $this->session->userdata('role_id');
			$data['user_id'] = $this->session->userdata('user_id');	
			//echo "sougata";
			$data['sl_no'] = $_POST['sl_no'];
			$this->load->model('Customer_model');
			$data['customer_list']=$this->Customer_model->customer_edit($data);
			//$data['customer_master_list']=$this->Customer_model->bye_customer_list($data);
			$data['customer_type']=$this->Customer_model->bye_customer_type();
			$data['customer_master_list']=$this->Customer_model->customer_god_father_list($data);

			$data['god_father_edit']=$this->Customer_model->customer_god_father_edit_mail($data);
			$this->load->view('customer_edit',$data);
		}
		else
        {
            $data['s_out'] = 'Session Expired..';
            $this->load->view('login',$data);
        }
	}
	 


	public function god_father_edit()
	{
	    if($this->session->userdata('email_id') == TRUE) 
        { 
		$data['email_id'] = $this->session->userdata('email_id');
		$data['role_id'] = $this->session->userdata('role_id');
		$data['user_id'] = $this->session->userdata('user_id');
		//echo "sougata";
		$data['sl_no'] = $_POST['sl_no'];
		$data['customer_id6'] = $_POST['sl_no'];
		
		$this->load->model('Customer_model');
		$data['customer_list']=$this->Customer_model->god_father_edit($data);
		
		$data['father_count']=$this->Customer_model->father_count($data);
		$data['customer_type']=$this->Customer_model->bye_customer_type();
		$this->load->view('god_father_edit',$data);
		}
		 else
        {
            $data['s_out'] = 'Session Expired..';
            $this->load->view('login',$data);
        }
		 
		
	 }
	 
	 
	 


	 	public function customer_update()
		{   
			if($this->input->post('TS') != $this->session->userdata('form_ts'))
				{
					if($this->session->userdata('email_id') == TRUE) 
					{
					$data['email_id'] = $this->session->userdata('email_id');
					$this->session->set_userdata('form_ts',$this->input->post('TS'));	
					$data['role_id'] = $this->session->userdata('role_id');
					$data['user_id'] = $this->session->userdata('user_id');
					$data['sl_no'] = $_POST['sl_no'];
					//$data['custtype']=$_POST['custtype'];
					$data['father'] = $_POST['father'];

					$data['fname']=$_POST['fname'];
					$data['lname']=$_POST['lname'];
					$data['email']=$_POST['email'];
					$data['phonenumber']=$_POST['phonenumber'];
					$data['dob']=$_POST['dob'];
					$data['pcode']=$_POST['pcode'];
					// $data['carton']=$_POST['carton'];
					// $data['rdate']=$_POST['rdate'];

					// $data['log_id']=$_POST['login_id'];
					$data['alert_flag'] = 0;
					$data['alert_message'] = "";

					$this->load->model('Customer_model');
					$data['customer_master_list']= $this->Customer_model->bye_customer_update($data);
					$data['alert_flag'] = 1;
					$data['alert_message'] = "customer details for Id ".$data['sl_no']." has been updated successfully";
					$data['customer_master_list']=$this->Customer_model->bye_god_son_list($data);
					$data['activity_id'] = 2;
					$data['key_id'] = $data['sl_no'];
					$data['page_id'] = 3;
					$data['module_id'] = 3;
					$this->load->model('Admin_model');
					$this->Admin_model->bye_user_log($data);
					$this->load->view('god_son_list',$data);
					}
					else
					{
					$data['s_out'] = 'Session Expired..';
					$this->load->view('login',$data);
					}
				}
			else
				{
				$data['role_id'] = $this->session->userdata('role_id');
				$data['user_id'] = $this->session->userdata('user_id');
				$this->load->model('Customer_model');
				$data['customer_master_list']=$this->Customer_model->bye_god_son_list($data);
				$this->load->view('god_son_list',$data);
				}

		}
	
	



	public function god_father_update()
  	{   
	   if($this->input->post('TS') != $this->session->userdata('form_ts'))
		{   
			if($this->session->userdata('email_id') == TRUE) 
				{
					 $data['email_id'] = $this->session->userdata('email_id');
				$this->session->set_userdata('form_ts',$this->input->post('TS'));	
				$data['role_id'] = $this->session->userdata('role_id');
				$data['user_id'] = $this->session->userdata('user_id');	
				$data['sl_no'] = $_POST['sl_no'];
				$data['fname']=$_POST['fname'];
				$data['lname']=$_POST['lname'];
				$data['email']=$_POST['email'];
				$data['phonenumber']=$_POST['phonenumber'];
				$data['dob']=$_POST['dob'];
				$data['pcode']=$_POST['pcode'];
				$data['valid_count']=$_POST['valid_count'];
			
				$data['alert_flag'] = 0;
				$data['alert_message'] = "";

				$this->load->model('Customer_model');
				$this->load->model('Admin_model');
				$data['customer_master_list']= $this->Customer_model->bye_father_update($data);
				$data['alert_flag'] = 1;
				$data['alert_message'] = "customer details for Id ".$data['sl_no']." has been updated successfully";
				$data['activity_id'] = 2;
				$data['key_id'] = $data['sl_no'];
				$data['page_id'] = 2;
				$data['module_id'] = 2;
				$this->load->model('Admin_model');
				$this->Admin_model->bye_user_log($data);
				$data['customer_master_list']=$this->Customer_model->bye_god_father_list($data);
				$this->load->view('god_father_list',$data);
				}
				else
				{
					$data['s_out'] = 'Session Expired..';
					$this->load->view('login',$data);
				}
		}
		else
			{
				$data['role_id'] = $this->session->userdata('role_id');
				$data['user_id'] = $this->session->userdata('user_id');
				$this->load->model('Customer_model');
				$data['customer_master_list']=$this->Customer_model->bye_god_father_list($data);
				$this->load->view('god_father_list',$data);
			}
        
		}
	
	
	
	
	public function customer_view()
	{
		if($this->session->userdata('email_id') == TRUE)
		{
		$data['email_id'] = $this->session->userdata('email_id');			
		$data['role_id'] = $this->session->userdata('role_id');
		$data['user_id'] = $this->session->userdata('user_id');
		$data['customer_id6'] = $_POST['customer_id6'];
		$this->load->model('Customer_model');

		$data['customer_list']=$this->Customer_model->customer_view($data);
		$data['god_father_details']=$this->Customer_model->god_father_view($data);
		$data['activity_id'] = 4;
		$data['key_id'] = $data['customer_id6'];
		$data['page_id'] = 3;
		$data['module_id'] = 3;
		$this->load->model('Admin_model');
		$this->Admin_model->bye_user_log($data);
		$this->load->view('customer_view',$data);
		}
		 else
        {
            $data['s_out'] = 'Session Expired..';
            $this->load->view('login',$data);
        }
		 
        
    }
    
   
   
    public function god_father_view()
	{
		if($this->session->userdata('email_id') == TRUE)
		{
		$data['email_id'] = $this->session->userdata('email_id');			
		$data['role_id'] = $this->session->userdata('role_id');
		$data['user_id'] = $this->session->userdata('user_id');
		$data['customer_id6'] = $_POST['customer_id6'];
		$this->load->model('Customer_model');
		$this->load->model('Admin_model');
		$data['key_id'] = $data['customer_id6'];
		$data['activity_id'] = 4;
		$data['page_id'] = 2;
		$data['module_id'] = 2;
		$this->load->model('Admin_model');
		$this->Admin_model->bye_user_log($data);
		$data['customer_list']=$this->Customer_model->father_view($data);
		$data['father_count']=$this->Customer_model->father_count($data);
		$this->load->view('father_view',$data);
		}
		 else
        {
            $data['s_out'] = 'Session Expired..';
            $this->load->view('login',$data);
        }
		 
        
    }
    
    
    
    
	public function customer_delete()
	{
	   if($this->session->userdata('email_id') == TRUE) 
        {
			 $data['email_id'] = $this->session->userdata('email_id');
			$data['role_id'] = $this->session->userdata('role_id');
			$data['user_id'] = $this->session->userdata('user_id');
			$data['sl_no'] = $_POST['sl_no'];
			$this->load->model('Customer_model');
			$this->Customer_model->customer_delete($data);
			$data['alert_flag'] = 0;
			$data['alert_message'] = "";
			$data['customer_master_list']=$this->Customer_model->bye_god_father_list($data);
			$data['alert_flag'] = 1;
			$data['alert_message'] = "God Father details for Id ".$data['sl_no']." has been deleted";
			$data['key_id'] = $data['sl_no'];
			$data['activity_id'] = 3;
			$data['page_id'] = 2;
			$data['module_id'] = 2;
			$this->load->model('Admin_model');
			$this->Admin_model->bye_user_log($data);
			$this->load->view('god_father_list',$data);
		}
		 else
        {
            $data['s_out'] = 'Session Expired..';
            $this->load->view('login',$data);
        }
	  
	}
	
	  
	public function god_son_delete()
	{
	    if($this->session->userdata('email_id') == TRUE) 
        {
			 $data['email_id'] = $this->session->userdata('email_id');
			$data['role_id'] = $this->session->userdata('role_id');
			$data['user_id'] = $this->session->userdata('user_id');
			$data['sl_no'] = $_POST['sl_no'];
			$this->load->model('Customer_model');
			$this->Customer_model->customer_delete($data);
			$data['alert_flag'] = 0;
			$data['alert_message'] = "";
			$data['customer_master_list']=$this->Customer_model->bye_god_son_list($data);
			$data['alert_flag'] = 1;
			$data['alert_message'] = "God Son details for Id ".$data['sl_no']." has been deleted";
			$data['key_id'] = $data['sl_no'];
			$data['activity_id'] = 3;
			$data['page_id'] = 3;
			$data['module_id'] = 3;
			$this->load->model('Admin_model');
			$this->Admin_model->bye_user_log($data);
			$this->load->view('god_son_list',$data);
		}
		else
        {
            $data['s_out'] = 'Session Expired..';
            $this->load->view('login',$data);
        }
	  
	}
	
	public function email_exist(){
	    $this->load->model('Customer_model');
	    $data['email_id'] = $_POST['alldata'];
	    $data['user_id']=1;
		$rs = $this->Customer_model->email_check($data);
		echo json_encode($rs);
	}

	public function phone_exist(){
	    $this->load->model('Customer_model');
	    $data['ph_no'] = $_POST['alldata'];
		$data['user_id']=1;
		$rs= $this->Customer_model->phone_no_check($data);
		echo json_encode($rs);
	}
	
   
  
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}