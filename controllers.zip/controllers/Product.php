<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Product extends CI_Controller {
	
    public function __construct()
    {
        parent::__construct();
        $this->load->model('user');
        $this->load->library('session');
        $this->load->helper('url');
    }
	
	public function product_master()
	{
        if($this->session->userdata('email_id') == TRUE) 
        { 
			 $data['email_id'] = $this->session->userdata('email_id');
            $data['role_id'] = $this->session->userdata('role_id');
            $data['user_id'] = $this->session->userdata('user_id');
            $this->load->model('Product_model');
            $data['product_master_list']=$this->Product_model->bye_product_list2();
            $this->load->view('product_master',$data);
        }
        else
        {
            $data['s_out'] = 'Session Expired..';
            $this->load->view('login',$data);
        }
	}
	
	public function product_master2()
	{
        if($this->session->userdata('email_id') == TRUE) 
        { 
			 $data['email_id'] = $this->session->userdata('email_id');
            $data['role_id'] = $this->session->userdata('role_id');
            $data['user_id'] = $this->session->userdata('user_id');
            $this->load->model('Product_model');
            $data['product_master_list']=$this->Product_model->bye_product_list2();
            $this->load->view('product_master2',$data);
        }
        else
        {
            $data['s_out'] = 'Session Expired..';
            $this->load->view('login',$data);
        }
	}
	
    public function product_add()
    {
        if($this->session->userdata('email_id') == TRUE) 
        {
			 $data['email_id'] = $this->session->userdata('email_id');
            $data['role_id'] = $this->session->userdata('role_id');
            $data['user_id'] = $this->session->userdata('user_id');
            $this->session->set_userdata('form_ts',$this->input->post('TS'));
            $this->load->view('product_add',$data);
        }
        else
        {
            $data['s_out'] = 'Session Expired..';
            $this->load->view('login',$data);
        }
    }
  
    public function product_registration()
    {
		if($this->input->post('TS') != $this->session->userdata('form_ts'))
		{
				if($this->session->userdata('email_id') == TRUE) 
				{
					 $data['email_id'] = $this->session->userdata('email_id');
					$this->session->set_userdata('form_ts',$this->input->post('TS'));	
					$data['role_id'] = $this->session->userdata('role_id');
					$data['user_id'] = $this->session->userdata('user_id');	
					$data['product_name']=$_POST['product_name'];
					$data['product_type']=$_POST['product_type'];
					$data['product_code']=$_POST['product_code'];
					$data['product_col']=$_POST['product_col'];
					$this->load->model('Product_model');
					$this->Product_model->product_reg($data);
					$data['product_master_list']=$this->Product_model->bye_product_list2();
					$this->load->view('product_master',$data);
				}
				else
				{
					$data['s_out'] = 'Session Expired..';
					$this->load->view('login',$data);
				}
		}
		else
			{
				$data['role_id'] = $this->session->userdata('role_id');
				$data['user_id'] = $this->session->userdata('user_id');
				$this->load->model('Product_model');
				$data['product_master_list']=$this->Product_model->bye_product_list2();
				$this->load->view('product_master',$data);
			}
    }	
   
    public function product_edit()
	{
        if($this->session->userdata('email_id') == TRUE) 
        {
			 $data['email_id'] = $this->session->userdata('email_id');
            $data['product_id'] = $_POST['product_id'];
            $this->load->model('Product_model');
            $data['product_list']=$this->Product_model->product_edit($data);
            $this->load->view('product_edit',$data);
        }
        else
        {
            $data['s_out'] = 'Session Expired..';
            $this->load->view('login',$data);
        }
    }

    public function productdetails_update()
  	{   
		if($this->input->post('TS') != $this->session->userdata('form_ts'))
		{
	  
				if($this->session->userdata('email_id') == TRUE) 
				{
					 $data['email_id'] = $this->session->userdata('email_id');
					$this->session->set_userdata('form_ts',$this->input->post('TS'));	
					$data['role_id'] = $this->session->userdata('role_id');
					$data['user_id'] = $this->session->userdata('user_id');	
					$data['product_name']=$_POST['product_name'];
					$data['product_type']=$_POST['product_type'];
					$data['product_code']=$_POST['product_code'];
					$data['product_col']=$_POST['product_col'];
					$data['product_id'] = $_POST['product_id'];
					$this->load->model('Product_model');
					$data['driver_master_list']= $this->Product_model->bye_product_update($data);
					$data['alert_flag'] = 1;
					$data['alert_message'] = "Product details for Id ".$data['product_id']." has been updated successfully";
					$data['activity_id'] = 2;
					$data['key_id'] = $data['product_id'];
					$data['page_id'] = 1;
					$data['module_id'] = 1;
					$this->load->model('Admin_model');
					$this->Admin_model->bye_user_log($data);
					$data['product_master_list']=$this->Product_model->bye_product_list2($data);
					$this->load->view('product_master',$data);
				}
				else
				{
					$data['s_out'] = 'Session Expired..';
					$this->load->view('login',$data);
				}
		}
		else
			{
				$data['role_id'] = $this->session->userdata('role_id');
				$data['user_id'] = $this->session->userdata('user_id');
				$this->load->model('Product_model');
				$data['product_master_list']=$this->Product_model->bye_product_list2();
				$this->load->view('product_master',$data);
			}
  	}
	
	
	
	public function product_view()
	{
        if($this->session->userdata('email_id') == TRUE) 
        {
			 $data['email_id'] = $this->session->userdata('email_id');
			$data['role_id'] = $this->session->userdata('role_id');
			$data['user_id'] = $this->session->userdata('user_id');
            $data['product_id'] = $_POST['product_id6'];
            $this->load->model('Product_model');
			$data['key_id'] = $data['product_id'];
			$data['activity_id'] = 4;
			$data['page_id'] = 1;
			$data['module_id'] = 1;
			$this->load->model('Admin_model');
			$this->Admin_model->bye_user_log($data);
            $data['product_list']=$this->Product_model->product_edit($data);
            $this->load->view('product_view',$data);
			
        }
        else
        {
            $data['s_out'] = 'Session Expired..';
            $this->load->view('login',$data);
        }
    }

    public function product_delete()
    {
        if($this->session->userdata('email_id') == TRUE) 
        {
			 $data['email_id'] = $this->session->userdata('email_id');
			$data['role_id'] = $this->session->userdata('role_id');
			$data['user_id'] = $this->session->userdata('user_id');
            $data['product_id3'] = $_POST['product_id3'];
            $this->load->model('Product_model');
            $this->Product_model->product_delete($data);
            $data['alert_flag'] = 0;
            $data['alert_message'] = "";
            $data['product_master_list']=$this->Product_model->bye_product_list2($data);
            $data['alert_flag'] = 1;
            $data['alert_message'] = "Product details for Id ".$data['product_id3']." has been deleted";
			$data['key_id'] = $data['product_id3'];
			$data['activity_id'] = 3;
			$data['page_id'] = 1;
			$data['module_id'] = 1;
			$this->load->model('Admin_model');
			$this->Admin_model->bye_user_log($data);
            $this->load->view('product_master',$data);
        }
        else
        {
            $data['s_out'] = 'Session Expired..';
            $this->load->view('login',$data);
        }
        
    }
	
    public function barcode_exist()
    {
        if($this->session->userdata('email_id') == TRUE) 
        {
            $this->load->model('Product_model');
            $data['code'] = $_POST['code'];
            $data['barcode']=$this->Product_model->exist_barcode($data);
            echo json_encode($data['barcode']);
        }
        else
        {
            $data['s_out'] = 'Session Expired..';
            $this->load->view('login',$data);
        }
    }
			
  
}

	
	
	
	
	
	
	
	
	
	
	





























