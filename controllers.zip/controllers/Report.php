<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Report extends CI_Controller {
    
	public $access;
	
    public function __construct()
    {
        parent::__construct();
		$this->load->model('user');
        $this->load->library('session');
        $this->load->helper('url');
		
    	if($this->session->userdata('email_id') == TRUE)
		{
			
			$data['email_id'] = $this->session->userdata('email_id');
			$this->access=$data['email_id'];
		}
		else
        {
            $data['s_out'] = 'Session Expired..';
            $this->load->view('login',$data);
        }
    }
    
    public function report_module(){
		$data['email_id']=$this->access;
        $this->load->view('report_master',$data);
    }
    
    public function product_stock_report(){
		$data['email_id']=$this->access;
		$data['user_id'] = $this->session->userdata('user_id');
        $this->load->model('Report_model');
		$data['report_data'] = $this->Report_model->product_stock_report_data($data);
		$this->load->view('product_stock_report_view',$data);
    }
    public function pe_reports()
    {   
        $data['user_id'] = $this->session->userdata('user_id');
        $data['email_id']=$this->access;
        $this->load->model('Report_model');
		$data['product_data'] = $this->Report_model->product_stock_movement_data();
		
        $this->load->view('pe_reports',$data);
    }

    public function pe_reports_gen(){
		$data['email_id']=$this->access;
		$data['user_id'] = $this->session->userdata('user_id');
        $this->load->model('Report_model');
        // $data['items']=$_POST['items'];
        //$data['all_data']=array();
        $data['form_date']=$_POST['from_date'];
		$data['status']=$_POST['status'];
        $data['to_date']=$_POST['to_date'];
        $data['cust_details']= $this->Report_model->rpt_pe_report($data);
		//echo"".$data['cust_details'];
       // $pe2_details = $this->Report_model->rpt_pe2_report($data);
        //$pe3_details = $this->Report_model->rpt_pe3_report($data);
        
        //print_r
       /*  if($pe_details)
        {
            foreach($pe_details as $pe1)
            {
                $data['prd_name']= $pe1['product_name'];
                $data['pe_details'] = $pe1['emails'];
            }
        }
        
        if($pe2_details)
        {
            foreach($pe2_details as $pe2)
            {
                $data['prd2_name']= $pe2['product_name'];
                $data['pe2_details'] = $pe2['emails2'];
            }
        }
        if($pe3_details)
        {
            foreach($pe3_details as $pe3)
            {
                $data['prd3_name']= $pe3['product_name'];
                $data['pe3_details'] = $pe3['emails3'];
            }
        } */
        $data['product_data'] = $this->Report_model->product_stock_movement_data();
        $this->load->view('pe_reports',$data);
    }
    public function customer_reports()
    {
		$data['user_id'] = $this->session->userdata('user_id');
		$data['email_id']=$this->access;
        $this->load->view('customer_reports',$data);
    }
	 public function customer_reports_gen()
    {	
		$data['email_id']=$this->access;
		$data['user_id'] = $this->session->userdata('user_id');
		$data['items']=$_POST['items'];
		$this->load->model('Report_model');
		$data['cust_details']=$this->Report_model->rpt_customer_report($data);
        $this->load->view('customer_reports',$data);
    }
    
    public function product_stock_movement(){
		$data['email_id']=$this->access;
		$data['user_id'] = $this->session->userdata('user_id');
        $this->load->model('Report_model');
		$this->load->model('Note_model');
		$data['product_data'] = $this->Report_model->product_stock_movement_data();
		$data['customer_list']=$this->Note_model->customer_list();
        $this->load->view('product_stock_movements_view',$data);
    }
    
    public function product_stock_movement_ajx(){
		$data['email_id']=$this->access;
		$data['user_id'] = $_POST['g_s_email'];
        $this->load->model('Report_model');
		$this->load->model('Note_model');
        $data['items']=$_POST['items'];
        $data['form_date']=$_POST['from_date'];
        $data['to_date']=$_POST['to_date'];
		//$data['g_s_email']=$_POST['g_s_email'];
		$data['stock_data'] = $this->Report_model->product_stock_movement_data_ajx($data);
		$data['product_data'] = $this->Report_model->product_stock_movement_data();
		$data['customer_list']=$this->Note_model->customer_list();
        $this->load->view('product_stock_movements_view',$data);
    }
    
    public function prd_details_by_id(){
		$data['email_id']=$this->access;
        $this->load->model('Report_model');
        $data['stock_details_id']=$_POST['alldata'];
        $data['user_id']=1;
        $data['prd_data'] = $this->Report_model->product_report_by_id($data);
        echo json_encode($data['prd_data']);
    }
    
    public function dealer_module(){
        $this->load->view('dealer_module',$data);
    }
    
    public function pe_dealer_module(){
        
    }
    
}
