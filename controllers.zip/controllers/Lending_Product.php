<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Lending_Product extends CI_Controller {
    
    protected $access;
    protected $access2;
    public function __construct()
    {
        parent::__construct();
		$this->load->model('user');
        $this->load->library('session');
        $this->load->helper('url');
        
        $data['secure_id']=$_GET['a'];
        $this->access=$data['secure_id'];
        $data['check_valid']=$this->token_valid($data['secure_id']);
	    if($data['check_valid'][0]['id']!=1){
	        $this->load->view('product_module');
	    }
		
		if($this->session->userdata('email_id') == TRUE)
		{
			
			$data['email_id'] = $this->session->userdata('email_id');
			$this->access2=$data['email_id'];
		}
		else
        {
            $data['s_out'] = 'Session Expired..';
            $this->load->view('login',$data);
        }
	    
    }
    
    public function token_valid($b){
	    $this->load->model('Menu2_model');
		$data['role_id'] = $this->session->userdata('role_id');
		$data['user_id'] = $this->session->userdata('user_id');
	    $data['enter_code']=$b-128;
	    //$data['user_id']=1;
	    $data['valid_token']=$this->Menu2_model->token_valid_data($data);
	        return $data['valid_token'];
	}
    
    public function lend_view(){
		$data['email_id']=$this->access2;
        $this->load->model('Lending_model');
        $data['secure_code']=$this->access;
        $data['lend_details']=$this->Lending_model->all_lend_data();
        $this->load->view('lend_data_view',$data);
    }
    
    public function product_lend(){
		$data['email_id']=$this->access2;
        $this->load->model('stock_model');
        $data['secure_code']=$this->access;
	    $data['product_list'] = $this->stock_model->all_products_list();
        $this->load->view('product_lend',$data);
   }
    
    public function lending_add(){
		$data['email_id']=$this->access2;
		$data['role_id'] = $this->session->userdata('role_id');
		$data['user_id'] = $this->session->userdata('user_id');
        $this->load->model('Lending_model');
        $data['lenddate']=$_POST['lenddate'];
        $data['coach_email']=$_POST['coach_email'];
        $data['coach_name']=$_POST['coach_name'];
        $data['phone_no']=$_POST['phone_no'];
        $data['al-products']=$_POST['al-products'];
        $data['al-quantities']=$_POST['al-quantities'];
        $data['al-return_date']=$_POST['al-return_date'];
        //$data['user_id']=1;
        $data['secure_code']=$this->access;
        $data['lend_submit']=$this->Lending_model->lend_add_data($data);
        if($data['lend_submit']>=1){
            $data['alert_flag']=1;
            $data['alert_message']="Lend data has been Inserted";
            $data['lend_details']=$this->Lending_model->all_lend_data();
            $this->load->view('lend_data_view',$data);
        }
    }
    
    public function view_product_lend_details(){
		$data['email_id']=$this->access2;
        $this->load->model('Lending_model');
		$data['role_id'] = $this->session->userdata('role_id');
		$data['user_id'] = $this->session->userdata('user_id');
        $data['coach_id']=$_POST['coach_id6'];
        //$data['user_id']=1;
        $data['prd_lend_details']=$this->Lending_model->lend_details_data($data);
        $data['secure_code']=$this->access;
		$data['key_id'] = $data['coach_id'];
		$data['activity_id'] = 4;
		$data['page_id'] = 12;
		$data['module_id'] = 12;
		$this->load->model('Admin_model');
		$this->Admin_model->bye_user_log($data);
        $this->load->view('product_lend_view',$data);
    }
    
    public function coach_delete()
	{
		$data['email_id']=$this->access2;
		$data['role_id'] = $this->session->userdata('role_id');
		$data['user_id'] = $this->session->userdata('user_id');
        $this->load->model('Lending_model');
        $data['coach_id']=$_POST['coach_id3'];
        //$data['user_id']=1;
        $data['coach_deleted']=$this->Lending_model->coach_details_delete($data);
        $data['secure_code']=$this->access;
        if($data['coach_deleted']>=1){
            $data['alert_flag']=1;
            $data['alert_message']="Coach data has been Deleted";
            $data['lend_details']=$this->Lending_model->all_lend_data();
			$data['key_id'] = $data['coach_id'];
			$data['activity_id'] = 3;
			$data['page_id'] = 12;
			$data['module_id'] = 12;
			$this->load->model('Admin_model');
			$this->Admin_model->bye_user_log($data);
            $this->load->view('lend_data_view',$data);
        }
    }
    
    public function lend_edit(){
		$data['email_id']=$this->access2;
		$data['role_id'] = $this->session->userdata('role_id');
		$data['user_id'] = $this->session->userdata('user_id');
        $this->load->model('stock_model');
        $this->load->model('Lending_model');
        $data['coach_id']=$_POST['coach_id'];
        //$data['user_id']=1;
        $data['secure_code']=$this->access;
	    $data['product_list'] = $this->stock_model->all_products_list();
	    $data['all_lend_details']=$this->Lending_model->all_lend_details($data);
	    print_r($data['all_lend_details']);
        $this->load->view('product_lend_update',$data);
    }
    
    public function delete_lending_product(){
		$data['role_id'] = $this->session->userdata('role_id');
		$data['user_id'] = $this->session->userdata('user_id');
		$data['email_id']=$this->access2;
        $this->load->model('Lending_model');
        //$data['user_id']=1;
        $data['prd_id']=$_POST['prd_id'];
        $data['coach_id']=$_POST['coach_id'];
        $data['all_lend_details']=$this->Lending_model->delete_lend_product($data);
        echo json_encode($data['all_lend_details']);
    }
    
    public function product_lend_update()
	{
		$data['email_id']=$this->access2;
        $this->load->model('Lending_model');
		$data['role_id'] = $this->session->userdata('role_id');
		$data['user_id'] = $this->session->userdata('user_id');
        //$data['user_id']=1;
        $data['lenddate']=$_POST['lenddate'];
        $data['coach_email']=$_POST['coach_email'];
        $data['coach_name']=$_POST['coach_name'];
        $data['phone_no']=$_POST['phone_no'];
        $data['al-products']=$_POST['al-products'];
        $data['al-quantities']=$_POST['al-quantities'];
        $data['al-return_date']=$_POST['al-return_date'];
        $data['coach_id']=$_POST['coach_id'];
        $data['secure_code']=$this->access;
        $data['lend_submit']=$this->Lending_model->lend_data_update($data);
        if($data['lend_submit']>=1){
            $data['alert_flag']=1;
            $data['alert_message']="Lend data has been Updated";
			$data['key_id'] = $data['coach_id'];
			$data['activity_id'] = 2;
			$data['page_id'] = 12;
			$data['module_id'] = 12;
			$this->load->model('Admin_model');
			$this->Admin_model->bye_user_log($data);
			
            $data['lend_details']=$this->Lending_model->all_lend_data();
            $this->load->view('lend_data_view',$data);
        }
    }
    
    public function check_mail(){
		$data['role_id'] = $this->session->userdata('role_id');
		$data['user_id'] = $this->session->userdata('user_id');
        $this->load->model('Lending_model');
        $data['coach_email']=$_POST['email_id'];
        //$data['user_id']=1;
        $data['secure_code']=$this->access;
        $data['email_count']=$this->Lending_model->check_coach_email($data);
        echo json_encode($data['email_count']);
    }
    
}
?>