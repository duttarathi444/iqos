<?php
class Product_model extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
    }
	public function bye_product_list()
    {
       $sql="CALL bye_product_master_list()";
	   
		
        $rs=$this->db->query($sql);
		//print_r($rs);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
           $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
    
    public function bye_product_list2()
    {
       $sql="CALL bye_product_master_list2()";
	   
		
        $rs=$this->db->query($sql);
		//print_r($rs);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
           $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
    
	
	
	 public function product_reg($data)
	 {
		$sql="CALL bye_product_reg('".$data['product_name']."','".$data['product_type' ]."','".$data['product_code']."','".$data['product_col']."')";
		 $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
           // $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
          //  $rs->next_result();
            $rs->free_result();

            return 0;
        }
	 }
		
		
		
    public function product_edit($data)
   
       {
		
        $sql="CALL bye_product_edit(".$data['product_id'].")";
        //echo $sql;
		
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
	
	
	
	
		public function bye_product_update($data)
    {

          $sql="CALL bye_product_update('".$data['product_name']."','".$data['product_type' ]."','".$data['product_code']."','".$data['product_col']."',".$data['product_id'].")";
         //echo $sql;
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
           // $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
           //$rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
	
	 public function product_delete($data)
    {
        $sql="CALL bye_product_delete(".$data['product_id3'].")";
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
		
	public function exist_barcode($data){
	    $sql="CALL check_barcode('".$data['code']."')";
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
	}
		
		
		
}		

	
	
