<?php
class Customer_model extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
    }
	public function bye_god_son_list($data)
    {
       $sql="CALL bye_customer_master_list(".$data['user_id'].")";
	   
		
        $rs=$this->db->query($sql);
		//print_r($rs);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
    
    
    
    	public function bye_god_father_list($data)
    {
       $sql="CALL bye_father_master_list(".$data['user_id'].")";
	   
		
        $rs=$this->db->query($sql);
		//print_r($rs);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
    
    
    
    
	
	
		public function bye_customer_type()
    {
       $sql="CALL bye_customer_type()";
	   
		
        $rs=$this->db->query($sql);
		//print_r($rs);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
	
	 public function cust_reg($data)
    {
        $sql="CALL bye_cust_reg('".$data['father']."','".$data['product_code' ]."','".$data['product_type']."','".$data['email']."','".$data['phone']."','".$data['dob']."','".$data['pcode']."',".$data['fid'].",".$data['user_id'].")";
        
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
          //  $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
          // $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
    
  
  
  
    	 public function god_father_reg($data)
    {
        $sql="CALL bye_father_reg('".$data['fname']."','".$data['lname']."','".$data['email']."','".$data['phone']."','".$data['dob']."','".$data['pcode']."',".$data['user_id'].")";
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
          //  $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
          // $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
    
    
    	 public function customer_edit($data)
     {
   	
        $sql="CALL bye_customer_edit(".$data['sl_no'].")";
		 $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
           $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }


	 public function god_father_edit($data)
     {
   	
        $sql="CALL bye_father_edit(".$data['sl_no'].")";
		 $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
           $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
		
	
	
	 public function bye_customer_update($data)
	 {
		 
          $sql="CALL bye_customer_update( '".$data['fname' ]."','".$data['lname']."','".$data['email']."','".$data['phonenumber']."','".$data['dob']."','".$data['pcode']."',".$data['sl_no'].",".$data['father' ].",".$data['user_id'].")";
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
           $rs->next_result();
            $rs->free_result();

            return 0;
        }
	 }


	
	 public function bye_father_update($data)
	 {
		 
          $sql="CALL bye_father_update('".$data['fname' ]."','".$data['lname']."','".$data['email']."','".$data['phonenumber']."','".$data['dob']."','".$data['pcode']."',".$data['sl_no'].",".$data['user_id'].",".$data['valid_count'].")";
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
           $rs->next_result();
            $rs->free_result();

            return 0;
        }
	 }

		
   
	 
	 
	 	    
	 public function customer_view($data)
     {
   	
        $sql="CALL bye_customer_view(".$data['customer_id6'].")";
		 $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
           $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
    
    	 	    
	 public function god_father_view($data)
     {
   	
        $sql="CALL god_father_details_view(".$data['customer_id6'].")";
		 $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
           $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }

	 	    
	 public function father_view($data)
     {
   	
        $sql="CALL bye_father_view(".$data['customer_id6'].")";
		 $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
           $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }




		 public function customer_delete($data)
     {
   	
        $sql="CALL bye_customer_delete(".$data['sl_no'].")";
		 $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
           $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
           $rs->next_result();
            $rs->free_result();

            return 0;
        }
	 }
	 
	 
	public function customer_god_father_list($data){
        $sql="CALL bye_customer_god_father(".$data['user_id'].")";
		 $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
           $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
           $rs->next_result();
            $rs->free_result();

            return 0;
        }
	 }
	 
	 	public function customer_god_father_edit_mail($data){
        $sql="CALL god_father_email_edit(".$data['sl_no'].")";
		 $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
           $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
           $rs->next_result();
            $rs->free_result();

            return 0;
        }
	 }
	 
	 
	 
	 
	 
	 
	 	
	public function customer_by_id($data){
	    $sql = "CALL god_father_by_id(".$data['cus_id'].")";
	    $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
           $rs->next_result();
            $rs->free_result();

            return 0;
        }
	}
	
	
	public function email_check($data){
	    $sql = "CALL check_email('".$data['email_id']."',".$data['user_id'].")";
	    $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
           $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
           $rs->next_result();
            $rs->free_result();

            return 0;
        }
	}
	
	public function phone_no_check($data){
	    $sql = "CALL check_phone_no('".$data['ph_no']."',".$data['user_id'].")";
	    $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
           $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
           $rs->next_result();
            $rs->free_result();

            return 0;
        }
	}
	
	public function father_count($data){
	    $sql="CALL total_father_count(".$data['customer_id6'].")";
		 $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
           $rs->next_result();
            $rs->free_result();

            return 0;
        }
	}
	
	
	
	
	
}
	