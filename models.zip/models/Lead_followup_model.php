<?php
class Lead_followup_model extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
    }
    public function all_lead_show($data){
    $sql="CALL show_all_lead(".$data['user_id'].")";
    $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
    
    public function add_lead_followup($data){
        $sql="CALL lead_follow_data_add('".$data['lead_month']."','".$data['lead_year']."','".$data['lead_date']."','".$data['lead_name']."',
        '".$data['lead_mail']."','".$data['lead_phone']."','".$data['status1']."','".$data['status2']."','".$data['status3']."','".$data['source']."',
        '".$data['met_note']."','".$data['remin_date']."',".$data['user_id'].")";
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
    
    public function show_lead_by_id($data){
        $sql="CALL lead_details_by_id(".$data['lead_id'].",".$data['user_id'].")";
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
    
    public function edit_lead_data($data){
        $sql="CALL lead_follow_edit('".$data['lead_month']."','".$data['lead_year']."','".$data['lead_date']."','".$data['lead_name']."',
        '".$data['lead_mail']."','".$data['lead_phone']."','".$data['status1']."','".$data['status2']."','".$data['status3']."','".$data['source']."',
        '".$data['met_note']."','".$data['remin_date']."',".$data['user_id'].",".$data['lead_id'].")";
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
    
}