<?php
class Lending_model extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
    }
    
    public function lend_add_data($data){
        $sql="CALL lend_data_add('".$data['lenddate']."','".$data['coach_email']."','".$data['coach_name']."','".$data['phone_no']."','".$data['al-products']."','".$data['al-quantities']."','".$data['al-return_date']."',".$data['user_id'].")";
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
    
    public function all_lend_data(){
        $sql="CALL lend_data_view()";
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
    
    public function lend_details_data($data){
        $sql="CALL prd_lend_data_by_id(".$data['coach_id'].",".$data['user_id'].")";
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
    
    public function coach_details_delete($data){
        $sql="CALL coach_data_delete_by_id(".$data['coach_id'].",".$data['user_id'].")";
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
    
    public function all_lend_details($data){
        $sql="CALL lend_details(".$data['coach_id'].",".$data['user_id'].")";
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
    
    public function delete_lend_product($data){
        $sql="CALL delete_lend_product(".$data['coach_id'].",".$data['prd_id'].",".$data['user_id'].")";
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
    
    public function lend_data_update($data){
        $sql="CALL lend_product_update('".$data['lenddate']."','".$data['coach_email']."','".$data['coach_name']."','".$data['phone_no']."','".$data['al-products']."','".$data['al-quantities']."','".$data['al-return_date']."',".$data['user_id'].",".$data['coach_id'].")";
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
    
    public function check_coach_email($data){
        $sql="CALL check_email_id('".$data['coach_email']."',".$data['user_id'].")";
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
    
}