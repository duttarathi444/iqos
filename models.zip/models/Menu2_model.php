<?php
class Menu2_model extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
    }
    
    public function add_token_data($data){
        $sql="CALL add_token('".$data['secure_code']."',".$data['user_id'].")";
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
    
    public function token_valid_data($data){
        $sql="CALL check_token_number('".$data['enter_code']."',".$data['user_id'].")";
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
    
}