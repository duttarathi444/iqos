<?php
class Report_model extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
    }
    public function product_stock_report_data($data){
        $sql="CALL retrieve_product_report(".$data['user_id'].")";
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
    
    public function product_stock_movement_data(){
        $sql = "CALL retrieve_products()";
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
    
    public function product_stock_movement_data_ajx($data){
        $sql = "CALL retrieve_products_by_ajx(".$data['items'].",'".$data['form_date']."','".$data['to_date']."',".$data['user_id'].")";
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
    
    public function product_report_by_id($data){
        $sql = "CALL report_product_by_id(".$data['stock_details_id'].")";
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }

    public function rpt_pe_report($data){
        $sql = "CALL rpt_pe_report_gen('".$data['form_date']."','".$data['to_date']."',".$data['user_id'].",".$data['status'].")";
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
    
    public function rpt_pe2_report($data){
        $sql = "CALL rpt_pe2_report(".$data['items'].",'".$data['form_date']."','".$data['to_date']."',".$data['user_id'].")";
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
    
    public function rpt_pe3_report($data){
        $sql = "CALL rpt_pe3_report(".$data['items'].",'".$data['form_date']."','".$data['to_date']."',".$data['user_id'].")";
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
    
	 public function rpt_customer_report($data){
        $sql = "CALL rpt_cust_list(".$data['items'].",".$data['user_id'].")";
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }


    
    
}