<?php
class stock_model extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
    }
	public function bye_stock_list($data)
    {
       $sql="CALL bye_stock_master_list(".$data['user_id'].")";
	   
		
        $rs=$this->db->query($sql);
		//print_r($rs);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
	
	
	 public function stock_reg($data)
    {
        $sql="CALL bye_stock_reg('".$data['receivded_from']."','".$data['shipment_name']."','".$data['carton_no']."','".$data['receive_date']."',
        '".$data['products_id']."','".$data['quantities']."',".$data['user_id'].",'".$data['ext']."')";
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
             $rs->next_result();
             $rs->free_result();
            return 0;
        }
    }
	
	public function product_by_orid($data){
	    $sql = "CALL products_by_order_id(".$data['order_id'].")";
	    $rs=$this->db->query($sql);
	    if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
          // $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
          // $rs->next_result();
            $rs->free_result();

            return 0;
        }
	}
	
       
	  public function stock_edit($data)
   
       {
		
        $sql="CALL bye_stock_edit(".$data['order_no'].")";
        //echo $sql;
		 $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
           $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
           $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
	
	
	 public function bye_stock_update($data)
	 {
		 
          $sql="CALL bye_stock_update('".$data['name']."','".$data['region' ]."','".$data['postal_code']."','".$data['barcode']."','".$data['recevided_from']."','".$data['shipment']."','".$data['carton']."',".$data['order_no'].")";
         //echo $sql;
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
           $rs->next_result();
            $rs->free_result();

            return 0;
        }
		
   
	 }
	
	public function all_customers_list($data){
	    $sql = "CALL retrieve_customers(".$data['user_id'].")";
	    $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
           $rs->next_result();
            $rs->free_result();

            return 0;
        }
	}
	
	public function all_products_list(){
	    $sql = "CALL retrieve_products()";
	    $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
           $rs->next_result();
            $rs->free_result();

            return 0;
        }
	}
	
	public function customer_data($data){
	    $sql = "CALL customer_by_id(".$data['cus_id'].")";
	    $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
           $rs->next_result();
            $rs->free_result();

            return 0;
        }
	}
	
	public function product_by_id($data){
	    $sql = "CALL product_by_id(".$data['cus_id'].",".$data['user_id'].")";
	    $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
           $rs->next_result();
            $rs->free_result();

            return 0;
        }
	}
	
	public function sale_submited_data($data){
	    $sql = "CALL product_sale_data('".$data['select_date']."',".$data['cus_email_id'].",".$data['product_id'].",'".$data['serial_no']."','".$data['sap_no']."',
	    ".$data['quantity'].",".$data['res_valid'].",'".$data['registation_date']."','".$data['pe1_date']."','".$data['pe2_date']."','".$data['pe3_date']."',".$data['user_id'].",
	    '".$data['product_ids']."','".$data['product_quantity']."')";
	    $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
           $rs->next_result();
            $rs->free_result();

            return 0;
        }
	}
	
	public function all_products_details($data){
	    $sql = "CALL sale_products(".$data['user_id'].")";
	    $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
           $rs->next_result();
            $rs->free_result();

            return 0;
        }
	}
	
 	public function product_by_sale_id($data){
 	    $sql = "CALL retrieve_product_by_sale_id(".$data['sale_id6'].")";
 	    $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
           $rs->next_result();
            $rs->free_result();

            return 0;
        }
 	}
 	
 	public function stock_in_details_view($data){
 	    $sql = "CALL product_stock_in_details_show(".$data['order_id'].")";
 	    $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
           $rs->next_result();
            $rs->free_result();
            return 0;
        }
 	}
 	
 	public function delete_stock_in_product($data){
 	    $sql = "CALL stock_in_product_delete(".$data['prd_stock_id'].")";
 	    $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
           $rs->next_result();
            $rs->free_result();
            return 0;
        }
 	}
 	
 	public function product_details_by_id($data){
 	    $sql = "CALL all_product_retrive(".$data['cus_id'].")";
 	    $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
           $rs->next_result();
            $rs->free_result();
            return 0;
        }
 	}
 	
 	public function stock_in_data_edit($data){
 	    $sql = "CALL stock_in_products_edit('".$data['carton_no']."','".$data['receive_date']."','".$data['receivded_from']."','".$data['shipment_name']."',".$data['order_id'].",'".$data['all_stock_id']."','".$data['all_product_id']."','".$data['all_product_quantity']."','".$data['al-products']."','".$data['al-quantities']."',".$data['user_id'].",'".$data['ext']."')";
 	    $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
           $rs->next_result();
            $rs->free_result();
            return 0;
        }
 	}
 	 
 	public function delete_all_product_by_id($data){
 	    $sql = "CALL delete_all_product_by_id(".$data['order_id'].")";
 	    $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
           $rs->next_result();
            $rs->free_result();
            return 0;
        }
 	}
 	
 	public function sale_product_by_id($data){
 	    $sql = "CALL product_by_sale_id(".$data['sale_id'].",".$data['user_id'].")";
 	    $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
           $rs->next_result();
            $rs->free_result();
            return 0;
        }
 	}
 	
 	public function sale_product_delete_by_id($data){
 	    $sql = "CALL delete_product_by_sale_id(".$data['sale_id'].")";
 	    $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
           $rs->next_result();
            $rs->free_result();
            return 0;
        }
 	}
 	
 	public function updated_sale_data($data){
 	    $sql = "CALL update_stock_out_data(".$data['sale_id'].",'".$data['select_date']."','".$data['cus_email_id']."',".$data['product_id'].",
 	    '".$data['serial_no']."','".$data['sap_no']."',".$data['quantity'].",'".$data['res_valid']."','".$data['registation_date']."','".$data['pe1_date']."',
 	    '".$data['pe2_date']."','".$data['pe1_status']."','".$data['pe2_status']."',".$data['user_id'].",'".$data['pe3_date']."',
 	    '".$data['pe3_status']."')";
 	    $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
           $rs->next_result();
            $rs->free_result();
            return 0;
        }
 	}
 	
 	public function check_carton($data){
 	    $sql = "CALL check_carton_id('".$data['carton_id']."',".$data['user_id'].")";
 	    $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
           $rs->next_result();
            $rs->free_result();
            return 0;
        }
 	}
 	
 	
 		public function replace_new_device($data){
	    $sql = "CALL product_swap('".$data['registation_date']."',".$data['product_id'].",'".$data['serial_num']."',".$data['sale_id'].",".$data['prd_qty'].",
	    ".$data['user_id'].",'".$data['glove']."','".$data['swap_date']."','".$data['res_valid']."','".$data['prod_bar']."')";
	    $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
           $rs->next_result();
            $rs->free_result();

            return 0;
        }
	}
 	
 	public function view_prd_swap_list($data){
 	    $sql = "CALL prd_swap_list(".$data['sale_id'].",".$data['user_id'].")";
 	    $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
           $rs->next_result();
            $rs->free_result();
            return 0;
        }
 	}
 	
 	public function swap_update_data($data){
 	    $sql = "CALL prd_update_data(".$data['swap_id'].",".$data['user_id'].",'".$data['registation_date']."',".$data['product_id'].",'".$data['serial_num']."',".$data['res_valid'].",
	    '".$data['glove']."','".$data['swap_date']."','".$data['prod_bar']."')";
	    $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
           $rs->next_result();
            $rs->free_result();

            return 0;
        }
 	}
 	
 	public function delete_swap_data($data){
 	     $sql = "CALL delete_prd_swap_data(".$data['sale_id'].",".$data['user_id'].")";
 	    $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
           $rs->next_result();
            $rs->free_result();

            return 0;
        }
 	}
 	
 	public function device_list(){
 	    $sql = "CALL device_list()";
 	    $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
           $rs->next_result();
            $rs->free_result();

            return 0;
        }
 	}
 	
 	public function heets_list(){
 	    $sql = "CALL heets_list()";
 	    $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
           $rs->next_result();
            $rs->free_result();

            return 0;
        }
 	}
 	
 	public function show_sale_product($data){
 	    $sql = "CALL show_sale_product(".$data['sale_id'].",".$data['user_id'].")";
 	    $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
           $rs->next_result();
            $rs->free_result();

            return 0;
        }
 	}
	
}