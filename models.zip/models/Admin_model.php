<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Admin_model extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
    }
    
    public function client_registration($data)
    {
        $sql="CALL bye_client_reg('".$data['company_name']."','".$data['c_telephone']."','".$data['c_fax']."','".$data['c_address']."','NA','".$data['client_name1']."','".$data['client_telephone1']."','".$data['client_email1']."','".$data['client_name2']."','".$data['client_email2']."','".$data['client_telephone2']."','".$data['shiptrack_id']."','".$data['gst_no']."',".$data['city'].",".$data['province'].",'".$data['postal_code']."','".$data['hst']."','".$data['pst']."','".$data['qst']."')";
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
	
	public function client_list()
    {
        $sql="CALL bya_client_master_list()";
		
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
    
    
    public function agent_registration($data)
    {
        $sql="CALL bye_agent_reg('".$data['company_name']."','".$data['c_telephone']."','".$data['c_fax']."','".$data['c_address']."','NA','".$data['agent_name1']."','".$data['agent_telephone1']."','".$data['agent_email1']."','".$data['agent_name2']."','".$data['agent_telephone2']."','".$data['agent_email2']."','".$data['shiptrack_id']."','".$data['gst_no']."',".$data['city'].",".$data['province'].",'".$data['postal_code']."','".$data['hst']."','".$data['pst']."','".$data['qst']."')";
        //echo"hi".$sql;
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
    
    public function agent_list()
    {
        $sql="CALL bye_agent_master_list()";
		
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
	
	
  public function edit_agent($data)
    {
        $sql="CALL bye_agent_edit(".$data['agent_id'].")";
		
    	 $rs=$this->db->query($sql);
            if ($rs->num_rows() > 0)
            {
                $results=$rs->result_array();
                $rs->next_result();
                $rs->free_result();
                return $results;
            }
            else
            {
                $rs->next_result();
                $rs->free_result();
    
                return 0;
            }
    }
    
   public function edit_client($data)
    {
        $sql="CALL bye_client_edit(".$data['client_id'].")";
    	 $rs=$this->db->query($sql);
            if ($rs->num_rows() > 0)
            {
                $results=$rs->result_array();
                $rs->next_result();
                $rs->free_result();
                return $results;
            }
            else
            {
                $rs->next_result();
                $rs->free_result();
    
                return 0;
            }
    }
	
	public function edit_viewlist($data)
    {
        $sql="CALL bye_client_view_list(".$data['client_id'].")";
    	 $rs=$this->db->query($sql);
            if ($rs->num_rows() > 0)
            {
                $results=$rs->result_array();
                $rs->next_result();
                $rs->free_result();
                return $results;
            }
            else
            {
                $rs->next_result();
                $rs->free_result();
    
                return 0;
            }
    }
	
	
	
	public function agent_update($data)
    {
        $sql="CALL bye_agent_update('".$data['company_name']."','".$data['c_telephone']."','".$data['c_fax']."','".$data['c_address']."','NA','".$data['agent_name1']."','".$data['agent_telephone1']."','".$data['agent_email1']."','".$data['agent_name2']."','".$data['agent_email2']."','".$data['agent_telephone2']."','".$data['agent_id']."','".$data['shiptrack_id']."','".$data['gst_no']."',".$data['city'].",".$data['province'].",'".$data['postal_code']."','".$data['hst']."','".$data['pst']."','".$data['qst']."')";
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
	
	public function client_update($data)
	{
        $sql="CALL bye_client_update('".$data['company_name']."','".$data['c_telephone']."','".$data['c_fax']."','".$data['c_address']."','NA','".$data['client_name1']."','".$data['client_email1']."','".$data['client_telephone1']."','".$data['client_name2']."','".$data['client_email2']."','".$data['client_telephone2']."',".$data['clnt_idd'].",'".$data['shiptrack_id']."','".$data['gst_no']."',0,".$data['province'].",'".$data['postal_code']."','".$data['hst']."','".$data['pst']."','".$data['qst']."')";
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
	
	
	public function unit_list()
    {
        $sql="CALL bye_unit_master_list()";
		
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
	
	public function service_code_list()
    {
        $sql="CALL bye_service_code_master_list()";
		
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
    
    
    
    public function scan_code_list()
    {
        $sql="CALL bye_scan_code_master_list()";
		
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
	
    public function agent_delete($data)
    {
        $sql="CALL agent_delete(".$data['agent_id'].")";
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
    
    public function client_delete($data)
    {
        $sql="CALL client_delete(".$data['client_id'].")";
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
    
    
    
    public function hub_master_list($data)
    {
        $sql="CALL bye_hub_master_list()";
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
    public function hub_reg($data)
    {
        $sql="CALL bye_hub_creation('".$data['hub_code']."','".$data['hub_name']."','".$data['client']."',".$data['taxcode'].",'".$data['address1']."','".$data['address2']."',".$data['province'].",".$data['city'].",'".$data['postal_code']."','".$data['contact']."','".$data['phone_no1']."','".$data['scac']."',0,0,0,0,0,".$data['hstcode'].",".$data['pstcode'].",".$data['qstcode'].")";
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
    public function province_master_list($data)
    {
        $sql="CALL bye_province_master_list()";
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
    
     /*public function bye_region_master_list($provin_id)
    {
        $sql="CALL bye_region_master_list('$provin_id')";
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }*/
     function bye_region_master_list($provin_id){
        $query = $this->db->get_where('bye_region_master', array('province_id' => $provin_id));
        return $query;
    }
    
    public function ftp_path_update($data)
    {
        $sql="CALL bye_ftp_path_update('".$data['ftp_path']."',".$data['new_client_id'].")";
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
	
	public function bye_type_list_by_product($data)
    {
        $sql="CALL bye_type_list_by_product('".$data['product_id']."')";
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
	
	public function bye_fsa_by_zone($data)
    {
        $sql="CALL bye_fsa_by_zone(".$data['province_id'].")";
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
	
	public function bye_hub_client_list($data)
    {
        $sql="CALL bye_hub_client_list(".$data['hub_id'].")";
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
	
	
		public function bye_user_log($data)
            {
                $sql="CALL bye_user_log(".$data['user_id'].",".$data['activity_id'].",".$data['module_id'].",".$data['page_id'].",".$data['key_id'].")";
            	 $rs=$this->db->query($sql);
                    if ($rs->num_rows() > 0)
                    {
                        $results=$rs->result_array();
                        $rs->next_result();
                        $rs->free_result();
                        return $results;
                    }
                    else
                    {
                        $rs->next_result();
                        $rs->free_result();
            
                        return 0;
                    }
            }
            
            
             public function bye_hub_view($data)
    {
        $sql="CALL bye_hub_view(".$data['hub_id'].")";
		
    	 $rs=$this->db->query($sql);
            if ($rs->num_rows() > 0)
            {
                $results=$rs->result_array();
                $rs->next_result();
                $rs->free_result();
                return $results;
            }
            else
            {
                $rs->next_result();
                $rs->free_result();
    
                return 0;
            }
    }
    
    
     public function hub_delete($data)
    {
        $sql="CALL bye_hub_delete(".$data['hub_id'].")";
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
    
    public function hub_updates($data)
    {
        $sql="CALL bye_hub_update(".$data['hub_id'].",'".$data['hub_code']."','".$data['hub_name']."',".$data['taxcode'].",".$data['hst'].",".$data['pst'].",".$data['qst'].",'".$data['address1']."','".$data['address2']."',".$data['region'].",".$data['province'].",'".$data['postal_code']."','".$data['phone_no1']."','".$data['scac']."','".$data['contact']."')";
      echo $sql;
         $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
        
        
    }
    
    

	
 }







?>
