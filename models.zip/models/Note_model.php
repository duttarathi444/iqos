<?php
class Note_model extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
    }
	public function bye_product_list($data)
    {
       $sql="CALL bye_product_master_list(".$data['user_id'].")";
	   
		
        $rs=$this->db->query($sql);
		//print_r($rs);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
           $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
    
    public function note_master_list($data)
    {
       $sql="CALL note_master_list(".$data['user_id'].")";
	   
		
        $rs=$this->db->query($sql);
		//print_r($rs);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
           $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
    
	
	
	 public function note_reg($data)
	 {
		$sql="CALL note_reg('".$data['reg_date']."','".$data['g_s_nm' ]."',".$data['g_s_email'].",".$data['p_bougt_1'].",
		".$data['p_bougt_2'].",".$data['p_bougt_3' ].",".$data['p_bougt_4'].",".$data['p_bougt_5'].",
		'".$data['p_s_pasw_email']."','".$data['f_whome' ]."','".$data['g_f_75_rec']."','".$data['g_s_25_rec']."',
		'".$data['g_s_100_rec']."','".$data['tr_date' ]."','".$data['u_g_f_email']."','".$data['g_f_nm']."',
		'".$data['p_serial1']."','".$data['p_serial2' ]."','".$data['p_serial3']."','".$data['p_serial4']."',
		'".$data['p_serial5']."','".$data['g_f_pasw_email' ]."','".$data['p_by_whom']."','".$data['p_75rec_date']."',
		'".$data['p_25rec_date']."','".$data['p_100rec_date' ]."','".$data['deposit1']."','".$data['deposit2']."',
		'".$data['deposit3']."','".$data['oder_id' ]."','".$data['g_s_ph_no']."','".$data['g_f_ph_no']."',
		'".$data['g_s_postal_code']."','".$data['p_type1' ]."','".$data['p_type2']."','".$data['p_type3']."',
		'".$data['p_type4']."','".$data['p_type5' ]."','".$data['p_remark']."','".$data['p_note']."',".$data['user_id'].",'".$data['g_son_dob']."')";
		 $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
           // $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
          //  $rs->next_result();
            $rs->free_result();

            return 0;
        }
	 }
		
		
		
    public function special_note_edit($data)
   
       {
		
        $sql="CALL note_edit(".$data['note_id'].")";
        //echo $sql;
		
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
	
	
	
	
		public function special_note_update($data)
    {
        $sql="CALL note_update('".$data['reg_date']."','".$data['g_s_nm' ]."',".$data['g_s_email'].",".$data['p_bougt_1'].",
		".$data['p_bougt_2'].",".$data['p_bougt_3' ].",".$data['p_bougt_4'].",".$data['p_bougt_5'].",
		'".$data['p_s_pasw_email']."','".$data['f_whome' ]."','".$data['g_f_75_rec']."','".$data['g_s_25_rec']."',
		'".$data['g_s_100_rec']."','".$data['tr_date' ]."','".$data['u_g_f_email']."','".$data['g_f_nm']."',
		'".$data['p_serial1']."','".$data['p_serial2' ]."','".$data['p_serial3']."','".$data['p_serial4']."',
		'".$data['p_serial5']."','".$data['g_f_pasw_email' ]."','".$data['p_by_whom']."','".$data['p_75rec_date']."',
		'".$data['p_25rec_date']."','".$data['p_100rec_date' ]."','".$data['deposit1']."','".$data['deposit2']."',
		'".$data['deposit3']."','".$data['oder_id' ]."','".$data['g_s_ph_no']."','".$data['g_f_ph_no']."',
		'".$data['g_s_postal_code']."','".$data['p_type1' ]."','".$data['p_type2']."','".$data['p_type3']."',
		'".$data['p_type4']."','".$data['p_type5' ]."','".$data['p_remark']."','".$data['p_note']."',".$data['note_id'].",".$data['user_id'].",'".$data['g_son_dob']."')";
         //echo $sql;
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
           // $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
           //$rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
	
	 public function special_note_delete($data)
    {
        $sql="CALL note_delete(".$data['note_id3'].")";
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
		
	public function exist_barcode($data){
	    $sql="CALL check_barcode('".$data['code']."')";
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
	}
	
	public function customer_list(){
	    $sql="CALL customer_list()";
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
	}
		
		
		
}		

	
	
