<?php
class Lending_back_model extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
    }
    
    public function all_lend_back_data($data){
        $sql="CALL prod_lending_search(".$data['user_id'].")";
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
    
    public function product_lend_back_by_id($data){
        $sql="CALL lend_back_by_head_id(".$data['head_id'].",".$data['user_id'].")";
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
    
    public function lend_back_data_submit($data){
        $sql="CALL lend_back_data_add(".$data['header_id'].",'".$data['products_id']."','".$data['quantities']."','".$data['return_dates']."','".$data['ex-return_dates']."',
        ".$data['user_id'].")";
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
    
    public function land_back_view_by_id($data){
        $sql="CALL lend_back_data_view(".$data['head_id'].",".$data['user_id'].")";
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
    
    public function lend_back_edit_data($data){
        $sql="CALL lend_back_product_data(".$data['head_id'].",".$data['user_id'].")";
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
    
    public function lend_back_data_total($data){
        $sql="CALL total_lend_back_data(".$data['head_id'].",".$data['user_id'].")";
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
    
    public function Lend_back_delete_by_id($data){
        $sql="CALL delete_lend_back_data(".$data['head_id'].",".$data['user_id'].")";
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
    
    public function lending_report_data($data){
        $sql="CALL lending_report(".$data['lend_item'].",".$data['items'].",'".$data['from_date']."','".$data['to_date']."',".$data['user_id'].")";
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
    
}