<html>
    <head>
        <style>
    table{
        /*border: 1px solid black;*/
        width: 100%;
        margin-bottom: 20px;
		border-collapse: separate;
        /*border-spacing: 20 0px;*/
    }
    table td{
        padding: 2px;
        text-align: left;
    }
    </style>
    </head>
    
<?php include_once('header.php'); ?>
<body>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>

<script>
$(document).ready(function(){
  $('#CompanyPhone').mask('000-000-0000');
  $('#CompanyFax').mask('000-000-0000');
  $('#client_telephone1').mask('000-000-0000');
  $('#client_telephone2').mask('000-000-0000');
});
</script>

<script  type="text/javascript" language="javascript" >
function addAll(){
        var products=document.getElementsByName("product");
        var barcodes=document.getElementsByName("barcode_no");
        var quantitys=document.getElementsByName("quantity");


var b=[];
var c=[];
var d=[];
var j=0;
for(var i=0;i<products.length;i++){
	
	var b1=products[i].value;
	var c1=barcodes[i].value;
	var d1=quantitys[i].value;
	b[j]=b1;
	c[j]=c1;
	d[j]=d1;
	j++;
}
document.getElementById("all-product").value=b;
document.getElementById("all-barcode").value=c;
document.getElementById("all-quantity").value=d;
}
</script>

<div class="content">
  <div class="container">
      <a id="back2Top" title="Back to top" href="#">&#10148;</a>
    <h2 class="gold-underline">Product Lend</h2>
        
        <!--action="stock_in" method="post"-->

          <form name="driver_add" action="stock_in" method="post" enctype="multipart/form-data">	
	    <!--<input type="hidden" id="product_id"value="<?php echo $p_list['product_id']; ?>" name="product_id" />-->
	     <div class="form-row">
              <div class="col-md-6 mb-3">
               <label for="validationPrimaryEmail">Select lend Date</label>
                <div class="input-group">
                  <input type="date" class="form-control" id="validationDefault01" placeholder="Carton Number" name="carton_no" required style="">
               </div>
			   <!--<span id="email_status"></span>-->
             </div>
             <div class="col-md-6 mb-3">
               <label for="validationPrimaryEmail">Enter coach's email</label>
                <div class="input-group">
                  <input type="email" class="form-control" id="validationDefault01"  name="receive_date" required style="">
               </div>
			   <!--<span id="email_status"></span>-->
             </div>
           </div>
           	     <div class="form-row">
              <div class="col-md-6 mb-3">
               <label for="validationPrimaryEmail">coach name</label>
                <div class="input-group">
                <input type="text" class="form-control" name="receivded_from" id="validationPrimaryEmail" placeholder="coach name" aria-describedby="inputGroupPrepend2" required="" style="" onkeyup="checkemail();">
               </div>
			   <!--<span id="email_status"></span>-->
             </div>
             <div class="col-md-6 mb-3">
               <label for="validationPrimaryEmail">coach Phone number</label>
                <div class="input-group">
                <input type="text" class="form-control" name="coach phone number" id="validationPrimaryEmail" placeholder="coach phone number" aria-describedby="inputGroupPrepend2" required="" style="" onkeyup="checkemail();">
               </div>
			   <!--<span id="email_status"></span>-->
             </div>
           </div>
              <div class="form-row">
             <div class="col-md-6 mb-3">
              <h3 class="gold-underline">ENTER ITEM DETAILS BELOW </h3>
             </div>
             
           </div>
           
            <div class="form-row">
                
                
                  <div class="col-md-6 mb-3">
               <label for="validationPrimaryEmail">Serial Number</label>
                <div class="input-group">
                  <input type="text" value="1" class="form-control" id="res_date"  name="registation_date" required>
               </div>
            </div>
			   
             <div class="col-md-6 mb-3">
               <label for="validationPrimaryEmail">Product Name</label>
                <select name="product_id" id="prod_name" class="form-control" onchange=select_prod(2)>
                    <option selected="">Select Product Name</option>
                    <?php if($product_list){foreach($product_list as $p_list){ ?>
                    <option value="<?php echo $p_list['product_id']; ?>"><?php echo  $p_list['product_name'];?></option>
                    <?php }}?>
                  </select>
             </div>
             
             <div class="col-md-6 mb-3">
               <label for="validationPrimaryEmail">Product Color</label>
                <div class="input-group">
                  <input type="type" class="form-control" id="prod_color" placeholder="Product Color" value="red"  name="product_color">
               </div>
            </div><br>
            
            
               <div class="col-md-6 mb-3">
               <label for="validationPrimaryEmail">Product Serial</label>
                <div class="input-group">
                  <input type="text"  class="form-control" id="res_date"  name="registation_date" required>
               </div>
            </div>
            
            
              <div class="col-md-6 mb-3">
               <label for="validationPrimaryEmail">quantity</label>
                <div class="input-group">
                  <input type="text"  class="form-control" id="prod_color" placeholder="Product Color">
               </div>
            </div>
            
             <div class="col-md-6 mb-3">
               <label for="validationPrimaryEmail">expected  return date</label>
                <div class="input-group">
                  <input type="date"  class="form-control" id="res_date"  required>
               </div>
               </div>
               </div>
           
           
           

            			
           <!--<div class="form-row">-->
           <!--     <div class="col col-md-4">-->
           <!--       <label for="inputState">Product Name</label>-->
           <!--       <select name="province" id="province" class="form-control">-->
           <!--           <?php if($product_master_list){foreach($product_master_list as $p_list){ ?>-->
	
           <!--         <option selected="" value="<?php echo $p_list['product_name']; ?>"><?php echo  $p_list['product_name'];?></option>-->
           <!--         <?php }}?>-->
           <!--       </select>-->
				  
           <!--     </div>-->
           <!--     <div class="col col-md-4">-->
           <!--       <label for="inputState">Product Type</label>-->
           <!--       <select name="region" id="region" class="form-control">-->
           <!--       <option value="">No Selected</option>-->
           <!--       </select>-->
           <!--     </div>-->
           <!--     <div class="col col-md-4">-->
           <!--       <label for="validationDefault03">Product Code</label>-->
           <!--       <input type="text" class="form-control" name="postal_code" id="postal_code" maxlength="6" required="">-->
           <!--     </div>-->
           <!--   </div>-->
			    <!--<div class="form-row">-->
       <!--       <div class="col-md-12 mb-3">-->
                
       <!--         <label for="validationDefault01"> Product Barcode</label>-->
       <!--         <div class="input-group">-->

       <!--           <input type="text" class="form-control" id="validationDefault01" placeholder="Barcode" name="barcode" required style="">-->
       <!--        </div>-->
       <!--       </div>-->
       <!--     </div>-->
          
      

   <!--     <table>-->
   <!--         <tbody>-->
			<!--</tbody>-->
   <!--     </table>  -->
           
           
           

 
           
           
          <!-- <div class="form-row">
                <div class="col col-md-4">
                  <input type="file" name="userFile"/>
	              
                </div>
                
              </div> //-->
           
          
            
            <div class="btn-group" role="group" aria-label="Basic example">
		    <input type="button" class="btn btn-secondary btn-lg my-2 pull-left" id="backk" value="Back" onclick="location.href='<?php echo base_url();?>index.php/Stock/stock_module'"/>
		
		<!--<input type="button" class="btn btn-success  btn-lg my-2 pull-left" id="add-row" value="Add Row">-->
		
		<!--<button type="button" class="btn btn-success  btn-lg my-2 pull-left" id="delete-row">Delete Row</button>-->
		
		<input type="submit" class="btn btn-success  btn-lg my-2 pull-left" id="auto_click" value="Submit"/>
		
		</div>

          
          
          
          
    
        </form>
        
        
</div>
</div>


<script type="text/javascript">
    $(document).ready(function(){
        $("#add-row").click(function(){
            var markup = `<tr>
                <td style="text-align: center;padding-bottom: 40px;"><input type="checkbox" name="record"></td>
                <td>
                <div class="form-row">
                <div class="col col-md-6">
                  <select name="product" id="product" class="form-control">
                       <?php if($product_master_list){foreach($product_master_list as $p_list){ ?> 
    
                    <option selected="" value="<?php echo $p_list['product_id']; ?>"> <?php echo  $p_list['product_name'];?> </option>
                     <?php }}?> 
                  </select>
                </div>
                
                <div class="col col-md-3">
                  <input type="text" class="form-control" name="barcode_no" id="barcode_no" placeholder="" required="">
                </div>
                
                <div class="col col-md-3">
                  <input type="text" class="form-control" name="quantity" id="quantity" placeholder="" required="">
                </div>
                </div>
                </td>
            </tr>`;
            $("table tbody").append(markup);
        });
        
        // Find and remove selected table rows
        $("#delete-row").click(function(){
            $("table tbody").find('input[name="record"]').each(function(){
            	if($(this).is(":checked")){
                    $(this).parents("tr").remove();
                }
            });
        });
    });    

// function checkemail()
// {
//   var user_email=document.getElementById("validationPrimaryEmail").value;
//   var flg='3';
  
//  if(user_email)
//  {
//   $.ajax({
//   method: 'post',
//   url: 'http://purpuligo.com/booya/index.php/User_auth/mail_validation_client_agent',
//   data: {
//   user_email:user_email,flg:flg
//   },
//   success: function (response) {
//   $( '#email_status' ).html(response);
//   if(response=="OK")	
//   {
//      return true;	
//   }
//   else
//   {
//      return false;	
//   }
//   }
//   });
//  }
//  else
//  {
//   $( '#email_status' ).html("");
//   return false;
//  }
// }
</script>
<!--<script>-->
<!--        $(document).ready(function(){-->
            
<!--            $('#province').change(function(){ -->
<!--                var id=$(this).val();-->
<!--                $.ajax({-->
                    <!--url : "<?php echo site_url('Admin/get_region_category_by_province');?>",-->
<!--                    method : "POST",-->
<!--                    data : {id: id},-->
<!--                    async : true,-->
<!--                    dataType : 'json',-->
<!--					url: "<?php echo site_url('Admin/get_region_category_by_province');?>",-->
<!--                    success: function(data){-->
<!--						console.log(data[0].product_id);-->
<!--                        var html = '';-->
<!--                        var i;-->
<!--                        for(i=0; i<data.length; i++){-->
<!--                            html += '<option value='+data[i].product_type+'>'+data[i].product_type+'</option>';-->
<!--                            $('#postal_code').val(data[i].product_code);-->
<!--                        }-->
<!--                        $('#region').html(html);-->
<!--                        document.getElementById('product_id').value = data[0].product_id;-->
<!--                    }-->
<!--                });-->
<!--            }); -->
            <!--$.ajax({-->
            <!--url : "<?php echo site_url('Admin/client_list_ajx');?>",-->
            <!--        method : "POST",-->
            <!--        async : true,-->
            <!--        dataType : 'json',-->
            <!--        success: function(data){-->
            <!--            var html = '';-->
            <!--            var i;-->
            <!--            for(i=0; i<data.length; i++){-->
            <!--                $("#client").append('<option value='+data[i].client_id+'>'+data[i].client_name+'</option>');-->
            <!--                //html += '<option value='+data[i].client_id+'>'+data[i].client_name+'</option>';-->
            <!--            }-->
            <!--            $('#client').multiselect({-->
            <!--            includeSelectAllOption: true,-->
            <!--            buttonWidth: 500,-->
            <!--            enableFiltering: true,-->
            <!--            selectAll: true-->
            <!--        });-->
                    
            <!--        }-->
            <!--});-->
			
<!--			$('#region').change(function(){ -->
<!--                var id=$(this).val();-->
<!--                $.ajax({-->
<!--                    url : "<?php echo site_url('Admin/get_fsa_by_zone');?>",-->
<!--                    method : "POST",-->
<!--                    data : {id: id},-->
<!--                    async : true,-->
<!--                    dataType : 'json',-->
<!--                    success: function(data){-->
<!--                        for(i=0; i<data.length; i++){-->
<!--                            $('#postal_code').val(data[i].product_code);-->
<!--                        }-->
<!--                    }-->
<!--                });-->
<!--            }); -->
<!--			$('#phone_no1').mask('000-000-0000');-->
			
			
<!--        });-->
<!--    </script>-->
    
 <?php include_once('footer.php'); ?>         

              