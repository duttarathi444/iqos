<html>
    
<?php include_once('header.php'); ?>
<body>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>

<script>

$(document).ready(function(){
  $('#CompanyPhone').mask('000-000-0000');
  $('#CompanyFax').mask('000-000-0000');
  $('#client_telephone1').mask('000-000-0000');
  $('#client_telephone2').mask('000-000-0000');
});
</script>
    
<div class="content">

	
  <div class="container">
  <a id="back2Top" title="Back to top" href="#">&#10148;</a>
    <h2 class="gold-underline">Special Note Details</h2>
    
    
     <?php 
		   if(!empty($specl_note_list))
							
							{
								foreach($specl_note_list as $driver){
						?>
        

          <form name="driver_add" action="driverdetails_update" method="post">
             <div class="gold-underline">
<table width="100%" cellspacing="5" cellpadding="5" border="0" bgcolor="E6B958" align="center">
   <tr bgcolor="#FFFFFF">
      <td>
         <table width="100%" cellspacing="0" cellpadding="0" border="0">
            <tr bgcolor="#FFFFFF">
               <td width="33%" height="40"><b>REGISTRATION DATE</b></td>
               <td width="34%"><?php echo $driver['reg_date'];?></td>
               <td></td>
            </tr>
            <tr bgcolor="#FFFFFF">
               <td height="40"><b> GOD SON EMAIL</b></td>
               <td><?php echo $driver['mail_id'];?></td>
               <td></td>
            </tr>
            <tr bgcolor="#FFFFFF">
               <td height="40"><b>GOD SON NAME</b></td>
               <td><?php echo $driver['g_son_name'];?></td>
               <td></td>
            </tr>
			<tr bgcolor="#FFFFFF">
               <td height="40"><b>GOD SON DOB</b></td>
               <td><?php echo $driver['g_son_dob'];?></td>
               <td></td>
            </tr>
             <tr bgcolor="#FFFFFF">
               <td height="40"><b>PRODUCT BOUGHT 1</b></td>
               <td><?php echo $driver['p_bought_1'];?></td>
               <td></td>
            </tr>
			
			 <tr bgcolor="#FFFFFF">
               <td width="33%" height="40"><b>PRODUCT BOUGHT 2</b></td>
               <td width="34%"><?php echo $driver['p_bought_2'];?></td>
               <td></td>
            </tr>
            <tr bgcolor="#FFFFFF">
               <td height="40"><b> PRODUCT BOUGHT 3</b></td>
               <td><?php echo $driver['p_bought_3'];?></td>
               <td></td>
            </tr>
            <tr bgcolor="#FFFFFF">
               <td height="40"><b>PRODUCT BOUGHT 4</b></td>
               <td><?php echo $driver['p_bought_4'];?></td>
               <td></td>
            </tr>
             <tr bgcolor="#FFFFFF">
               <td height="40"><b>PRODUCT BOUGHT 5</b></td>
               <td><?php echo $driver['p_bought_5'];?></td>
               <td></td>
            </tr>
			
			<!-- <tr bgcolor="#FFFFFF">
               <td width="33%" height="40"><b>GOD SON PASSWORD FOR EMAIL</b></td>
               <td width="34%"><?php echo $driver['g_son_passw_email'];?></td>
               <td></td>
            </tr>//-->
            <tr bgcolor="#FFFFFF">
               <td height="40"><b> FOR WHOM</b></td>
               <td><?php echo $driver['for_whom'];?></td>
               <td></td>
            </tr>
            <tr bgcolor="#FFFFFF">
               <td height="40"><b>GOD FATHER 75$ RECEIVED</b></td>
               <td><?php echo $driver['g_father_75_received'];?></td>
               <td></td>
            </tr>
             <tr bgcolor="#FFFFFF">
               <td height="40"><b>GOD SON 25$ RECEIVED</b></td>
               <td><?php echo $driver['g_son_25_received'];?></td>
               <td></td>
            </tr>
			
			 <tr bgcolor="#FFFFFF">
               <td width="33%" height="40"><b>GOD SON 100$ RECEIVED</b></td>
               <td width="34%"><?php echo $driver['g_son_100_received'];?></td>
               <td></td>
            </tr>
            <tr bgcolor="#FFFFFF">
               <td height="40"><b>TRANSACTION DATE</b></td>
               <td><?php echo $driver['transaction_date'];?></td>
               <td></td>
            </tr>
            <tr bgcolor="#FFFFFF">
               <td height="40"><b>UNDER GOD FATHER EMAIL</b></td>
               <td><?php echo $driver['u_g_father_email'];?></td>
               <td></td>
            </tr>
             <tr bgcolor="#FFFFFF">
               <td height="40"><b>GOD FATHER NAME</b></td>
               <td><?php echo $driver['g_father_name'];?></td>
               <td></td>
            </tr>
			
			 <tr bgcolor="#FFFFFF">
               <td width="33%" height="40"><b>PRODUCT SERIAL1</b></td>
               <td width="34%"><?php echo $driver['p_serial_1'];?></td>
               <td></td>
            </tr>
            <tr bgcolor="#FFFFFF">
               <td height="40"><b> PRODUCT SERIAL2</b></td>
               <td><?php echo $driver['p_serial_2'];?></td>
               <td></td>
            </tr>
            <tr bgcolor="#FFFFFF">
               <td height="40"><b>PRODUCT SERIAL3</b></td>
               <td><?php echo $driver['p_serial_3'];?></td>
               <td></td>
            </tr>
             <tr bgcolor="#FFFFFF">
               <td height="40"><b>PRODUCT SERIAL4</b></td>
               <td><?php echo $driver['p_serial_4'];?></td>
               <td></td>
            </tr>
			
			 <tr bgcolor="#FFFFFF">
               <td width="33%" height="40"><b>PRODUCT SERIAL5</b></td>
               <td width="34%"><?php echo $driver['p_serial_5'];?></td>
               <td></td>
            </tr>
           <!-- <tr bgcolor="#FFFFFF">
               <td height="40"><b>GOD FATHER PASSWORD FOR EMAIL</b></td>
               <td><?php echo $driver['g_father_passw_email'];?></td>
               <td></td>
            </tr>//-->
            <tr bgcolor="#FFFFFF">
               <td height="40"><b>PAID BY WHOM</b></td>
               <td><?php echo $driver['paid_by_whom'];?></td>
               <td></td>
            </tr>
             <tr bgcolor="#FFFFFF">
               <td height="40"><b>75$ RECEIVED DATE</b></td>
               <td><?php echo $driver['75_received_date'];?></td>
               <td></td>
            </tr>
			
			 <tr bgcolor="#FFFFFF">
               <td width="33%" height="40"><b>25$ RECEIVED DATE</b></td>
               <td width="34%"><?php echo $driver['25_received_date'];?></td>
               <td></td>
            </tr>
            <tr bgcolor="#FFFFFF">
               <td height="40"><b>100$ RECEIVED DATE</b></td>
               <td><?php echo $driver['100_received_date'];?></td>
               <td></td>
            </tr>
            <tr bgcolor="#FFFFFF">
               <td height="40"><b>ORDER ID (SAP)</b></td>
               <td><?php echo $driver['order_id_swp'];?></td>
               <td></td>
            </tr>
             <tr bgcolor="#FFFFFF">
               <td height="40"><b>GOD SON PHONE</b></td>
               <td><?php echo $driver['g_son_ph_no'];?></td>
               <td></td>
            </tr>
			
			 <tr bgcolor="#FFFFFF">
               <td width="33%" height="40"><b>GOD FATHER PHONE</b></td>
               <td width="34%"><?php echo $driver['g_father_ph_no'];?></td>
               <td></td>
            </tr>
            <tr bgcolor="#FFFFFF">
               <td height="40"><b>GOD SON POSTAL CODE</b></td>
               <td><?php echo $driver['g_son_postal_code'];?></td>
               <td></td>
            </tr>
            <tr bgcolor="#FFFFFF">
               <td height="40"><b>PRODUCT TYPE1</b></td>
               <td><?php echo $driver['p_type_1'];?></td>
               <td></td>
            </tr>
             <tr bgcolor="#FFFFFF">
               <td height="40"><b>PRODUCT TYPE2</b></td>
               <td><?php echo $driver['p_type_2'];?></td>
               <td></td>
            </tr>
			
			 <tr bgcolor="#FFFFFF">
               <td width="33%" height="40"><b>PRODUCT TYPE3</b></td>
               <td width="34%"><?php echo $driver['p_type_3'];?></td>
               <td></td>
            </tr>
            <tr bgcolor="#FFFFFF">
               <td height="40"><b> PRODUCT TYPE4</b></td>
               <td><?php echo $driver['p_type_4'];?></td>
               <td></td>
            </tr>
            <tr bgcolor="#FFFFFF">
               <td height="40"><b>PRODUCT TYPE5</b></td>
               <td><?php echo $driver['p_type_5'];?></td>
               <td></td>
            </tr>
             <tr bgcolor="#FFFFFF">
               <td height="40"><b>DEPOSITED TO</b></td>
               <td><?php echo $driver['deposited_1'];?></td>
               <td></td>
            </tr>
			
			 <tr bgcolor="#FFFFFF">
               <td width="33%" height="40"><b>DEPOSITED TO</b></td>
               <td width="34%"><?php echo $driver['deposited_2'];?></td>
               <td></td>
            </tr>
            <tr bgcolor="#FFFFFF">
               <td height="40"><b> DEPOSITED TO</b></td>
               <td><?php echo $driver['deposited_3'];?></td>
               <td></td>
            </tr>
            <tr bgcolor="#FFFFFF">
               <td height="40"><b>REMARKS</b></td>
               <td><?php echo $driver['remarks'];?></td>
               <td></td>
            </tr>
             <tr bgcolor="#FFFFFF">
               <td height="40"><b>SPECIAL NOTE</b></td>
               <td><?php echo $driver['special_note'];?></td>
               <td></td>
            </tr>
			
			
            
            
         </table>
      </td>
   </tr>
</table>
</div>  


               <input type="button" class="btn btn-secondary  btn-lg my-2 " id="agback" value="Back"  onclick="location.href='<?php echo base_url();?>index.php/Special_note/note_master?a=<?php echo $secure_code; ?>'" />
               
                <input type="hidden" name="driver_id" value="<?php echo $driver_id;?>" />

        </form><?php }} ?>
                
    </div>
</div>
 <?php include_once('footer.php'); ?>         

              