<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta content="width=device-width, initial-scale=1" name="viewport"/>
<link rel="stylesheet" href="<?php echo base_url();?>/assets/css/bootstrap.min.css">

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>


<!--<div id="header" class="site-header">-->
<!--    <nav class="navbar navbar-expand-lg my-2 my-md-0 mr-md-3">-->
<!--      <a class="navbar-brand"</a>-->
<!--    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">-->
<!--    <span class="navbar-toggler-icon"></span>-->
<!--    </button>-->
    
<!--      <div class="collapse navbar-collapse" id="navbarNav">-->
<!--        <ul class="navbar-nav navbar-right">-->
<!--          <li class="nav-item active"><a class="nav-link" href="" data-toggle="modal" data-target="#myModal">Lost Password <span class="sr-only">(current)</span></a></li>-->
<!--        </ul>-->
<!--      </div>-->
<!--    </nav>-->
<!--</div>-->

<div id="content" class="login-background" >

<!--<img src="<?php echo base_url();?>/assets/img/82GQEX.jpg" class="img-fluid" alt="Responsive image" />-->
<div id="login" class="login-form">
 	<h2 class="gold-underline">Login</h2>
	
	
<form role="form" method="post" action="index.php/welcome/user_auth">
  <div class="form-group">
    <label for="exampleInputEmail1">User Name</label>
    <input type="email" class="form-control" id="UserEmail" name="email" required aria-describedby="emailHelp" placeholder="Enter your user name"  onkeyup="checkemail();">
	
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Password</label>
    <input type="password" class="form-control" name="password" required placeholder="Enter your Password">
  </div>
  
  <button type="submit" class="btn btn-primary">Submit</button> <button type="submit" class="btn btn-warning">Cancel</button><br>
  <?php 
        if($this->session->flashdata('error') !=" ")
        {
          $error_msg = $this->session->flashdata('error');
          echo $error_msg;
        }?>	
</form>

 <a href="" data-toggle="modal" data-target="#myModal">Lost Password</a>
</div>	

<div class="modal fade" id="myModal">
    <div class="modal-dialog">
      <div class="modal-content">
      
        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title">Forget Password</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        
        <!-- Modal body -->
 <div class="modal-body">
<form action="index.php/User_auth/forget_password" method="post">
 <div class="form-group">
    <label for="email">Enter Email address/Login ID:</label>
    <input type="email" class="form-control"  name="u_email" required aria-describedby="emailHelp" placeholder="Enter your user name">
	
  </div>
  
<button type="submit" class="btn btn-primary">Submit</button>
</form>
        </div>
        
       
      </div>
    </div>
  </div>
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript"> 

function checkemail()
{
  var user_email=document.getElementById("UserEmail").value;
	
 if(user_email)
 {
  $.ajax({
  method: 'post',
  url: 'http://purpuligo.com/booya/index.php/User_auth/mail_validation',
  data: {
   user_email:user_email,
  },
  success: function (response) {
   $( '#email_status' ).html(response);
   if(response=="OK")	
   {
     return true;	
   }
   else
   {
     return false;	
   }
  }
  });
 }
 else
 {
  $( '#email_status' ).html("");
  return false;
 }
}
</script>

	
</div> 	

