<?php include_once('header.php'); ?>

<!DOCTYPE html>
<html lang="en" >
<head>
<meta charset="utf-8">


<link rel="stylesheet" href="../../assets/css/bootstrap.min.css">
<link rel="stylesheet" href="../../assets/css/bootstrap.min2.css">

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>

<link href="//maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">

<link rel="stylesheet" href="file:///Users/Chung/Desktop/Metro%20SCG/Admin%20Module/hub-m_files/css">

<link  href="../../assets/css/top.css" rel="stylesheet" />
<script src="../../assets/js/top.js"></script>
    </head>
    
   <!-- <script>
            $(this_id).tooltip({
                classes: {
                    "ui-tooltip":"highlight"
                },
                position:{ my:'left center', at:'right+50 center'},
                content:function(prd_details){
                    prd_details();
                }
            });
            
            function prd_details(this_id){
        var id=document.getElementById('prd_id').value;
            $.ajax({
                method: 'post',
                url: "http://purpuligo.com/iqos/index.php/Report/prd_details_by_id", 
                data: {alldata : id},
                async : 'true',
                dataType : 'json',
                success: function (response) {
                    alert(`${response[0].name} ${response[0].sap_order_no} ${response[0].serial_no} ${response[0].prd_quantity}`);
                }
            });
        }

        $('#datfrom_date').datetimepicker({
    defaultDate: new Date()
}); 

function dateput(){
    var datenow=new Date(Date.now());
    var month=+datenow.getMonth()+1;
    if((month+"").length<2){
        month='0'+month;
    }
    var date='';
    if((datenow.getDate()+"").length<2){
        date= '0'+datenow.getDate();
    }
    var newdate = datenow.getFullYear()+'-'+month+'-'+datenow.getDate();
    document.getElementById('from_date').value=newdate;
    document.getElementById('to_date').value=newdate;
}
</script>//-->
    
<body>
    
<div id="header" class="site-header">
</div>
<body onload="dateput();">
<div class="content">
  <div class="container">
    <h3 class="gold-underline">Customer Report</h3>
       
          <form method ="post" action="customer_reports_gen">
           

            <div class="row">
              <div class="col-3">
                  <label for="validationPrimaryEmail">Customer Type</label>
                   <div id="drop">
                    <select class="form-control" name="items"  id="a2" maxlength=200; placeholder="Select " required>
                        <option value="0"> select</option>
						<option value="1">God Son</option>
						<option value="2"> God Father</option>
                    </select>
			    </div>
			 </div>
			 
			 <!--- <div class="col-3">
			     <label for="validationPrimaryEmail">From Date</label>
                   <div id="drop">
                    <input type="date" class="form-control" id="from_date" name="from_date">
			    </div>
			 </div>
			 
			 <div class="col-3">
			     <label for="validationPrimaryEmail">To Date</label>
                   <div id="drop">
                    <input type="date" class="form-control" id="to_date" name="to_date">
			    </div>
			 </div> //-->
			 
			 
        <div class="col-2">
		<div id="drop">
		<label for="validationDefault01"> </label>
            <button class="btn btn-primary" type="submit">Submit</button>
        </div>
		  </div>
     </div>
		 
 
			 
<table class="table table-hover table-striped">
  <thead class="thead-dark">
    <tr>
      <th scope="col">Customer Type</th>
      <th scope="col"> Name</th>
      
      <th scope="col">Email</th>
      <th scope="col">Postal Code</th>
      
       </tr>
  </thead>
  <tbody>
    <?php if($cust_details){foreach($cust_details as $p_list){ ?>
                <tr>
                    <td><?php echo  $p_list['cust_type'];?></td>
                    <td><?php echo  $p_list['f_name'].' '.$p_list['l_name'];?></td>
                    
                    <td><?php echo  $p_list['mail_id'];?></td>
                    <td><?php echo  $p_list['postal_code'];?></td>
                    
                </tr>
                    <?php }}?>
            
  </tbody>
  
  </table>
  <input type="hidden" id="prd_id" value="<?php echo  $p_list['sl_no'];?>">
  <div class="btn-group" role="group" aria-label="Basic example">             
<input type="button" class="btn btn-secondary btn-lg my-2 pull-left" id="backk" value="Back" onclick="location.href='<?php echo base_url();?>index.php/Report/report_module'" />
</div>
			 
    </div>
  </div>
        
   
		 
  </form>

    <script>
        function myfun(){
            var e = document.getElementById('a2');
            var val = e.options[e.selectedIndex].value;
            var fr_date=document.getElementById('from_date').value;
            var t_date=document.getElementById('to_date').value;
            console.log(val);
            console.log(fr_date);
            console.log(t_date);
            $.ajax({
                    url : "http://purpuligo.com/iqos/index.php/Report/product_stock_movement_ajx",
                    method : "POST",
                    data : {pud_id: val,form_date: fr_date,to_date: t_date},
                    async : true,
                    dataType : 'json',
                    success: function(data){
                        console.log(data);
                    }
                    });
        }
    </script>

</body>
</body>
</html>
<?php include_once('footer.php'); ?>