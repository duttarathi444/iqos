<html>
    
<?php include_once('header.php'); ?>
<body>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>

<script>

$(document).ready(function(){
  $('#CompanyPhone').mask('000-000-0000');
  $('#CompanyFax').mask('000-000-0000');
  $('#client_telephone1').mask('000-000-0000');
  $('#client_telephone2').mask('000-000-0000');
});
</script>
    
<div class="content">

	
  <div class="container">
    <h3 class="gold-underline">God Son Details</h3>
    
    
     <?php 
		   if(!empty($customer_list))
							
							{
								foreach($customer_list as $driver){
						?>
        

          <form name="driver_add" action="driverdetails_update" method="post">
             <div class="gold-underline">
<table width="100%" cellspacing="5" cellpadding="5" border="0" bgcolor="E6B958" align="center">
   <tr bgcolor="#FFFFFF">
      <td>
         <table width="100%" cellspacing="0" cellpadding="0" border="0">
             
             
              
          
            
           
            <tr bgcolor="#FFFFFF">
               <td height="40"><b>First Name</b></td>
               <td><?php echo $driver['f_name'];?></td>
               <td></td>
            </tr>
            <tr bgcolor="#FFFFFF">
               <td height="40"><b>Last Name</b></td>
               <td><?php echo $driver['l_name'];?></td>
               <td></td>
            </tr>
			 <tr bgcolor="#FFFFFF">
               <td width="33%" height="40"><b>Email Id</b></td>
               <td width="34%"><?php echo $driver['mail_id'];?></td>
               <td></td>
            </tr>
            <tr bgcolor="#FFFFFF">
               <td height="40"><b>Phone Number</b></td>
               <td><?php echo $driver['ph_no'];?></td>
               <td></td>
            </tr>
            <tr bgcolor="#FFFFFF">
               <td height="40"><b>Date Of Birth</b></td>
               <td><?php echo $driver['dob'];?></td>
               <td></td>
            </tr>
             <tr bgcolor="#FFFFFF">
               <td height="40"><b>Postal Code</b></td>
               <td><?php echo $driver['postal_code'];?></td>
               <td></td>
            </tr>
            
            
         </table>
      </td>
   </tr>
</table>
</div>  


             
               
                <input type="hidden" name="driver_id" value="<?php echo $driver_id;?>" />

        </form><?php }} ?>
        
              
                
    </div>
    
    
     <div class="container">
    <h3 class="gold-underline">God Father Details</h3>
    
    
     <?php 
		   if(!empty($god_father_details))
							
							{
								foreach($god_father_details as $driver){
						?>
        

          <form name="driver_add" action="driverdetails_update" method="post">
             <div class="gold-underline">
<table width="100%" cellspacing="5" cellpadding="5" border="0" bgcolor="E6B958" align="center">
   <tr bgcolor="#FFFFFF">
      <td>
         <table width="100%" cellspacing="0" cellpadding="0" border="0">
             
             
              
          
            
           
            <tr bgcolor="#FFFFFF">
               <td height="40"><b>First Name</b></td>
               <td><?php echo $driver['f_name'];?></td>
               <td></td>
            </tr>
            <tr bgcolor="#FFFFFF">
               <td height="40"><b>Last Name</b></td>
               <td><?php echo $driver['l_name'];?></td>
               <td></td>
            </tr>
			 <tr bgcolor="#FFFFFF">
               <td width="33%" height="40"><b>Email Id</b></td>
               <td width="34%"><?php echo $driver['mail_id'];?></td>
               <td></td>
            </tr>
            <tr bgcolor="#FFFFFF">
               <td height="40"><b>Phone Number</b></td>
               <td><?php echo $driver['ph_no'];?></td>
               <td></td>
            </tr>
            <tr bgcolor="#FFFFFF">
               <td height="40"><b>Date Of Birth</b></td>
               <td><?php echo $driver['dob'];?></td>
               <td></td>
            </tr>
             <tr bgcolor="#FFFFFF">
               <td height="40"><b>Postal Code</b></td>
               <td><?php echo $driver['postal_code'];?></td>
               <td></td>
            </tr>
            
            
         </table>
      </td>
   </tr>
</table>
</div>  


             
               
                <input type="hidden" name="driver_id" value="<?php echo $driver_id;?>" />

        </form><?php }} ?>
        
          <input type="button" class="btn btn-secondary  btn-lg my-2 " id="agback" value="Back"  onclick="location.href='<?php echo base_url();?>index.php/Customers/god_son_master'" />
                   
                
    </div>
    
    
    
    
    
    
    
</div>
 <?php include_once('footer.php'); ?>         

              