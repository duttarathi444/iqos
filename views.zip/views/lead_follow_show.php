<html>
    
<?php include_once('header.php'); ?>
<body>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>

<script>

$(document).ready(function(){
  $('#CompanyPhone').mask('000-000-0000');
  $('#CompanyFax').mask('000-000-0000');
  $('#client_telephone1').mask('000-000-0000');
  $('#client_telephone2').mask('000-000-0000');
});
</script>
    
<div class="content">

	
  <div class="container">
    <h3 class="gold-underline">Lead Details</h3>
    
    
     <?php 
		   if(!empty($view_lead))
							
							{
								// foreach($product_list as $driver){
						?>
        

          <form name="driver_add" action="driverdetails_update" method="post">
             <div class="gold-underline">
<table width="100%" cellspacing="5" cellpadding="5" border="0" bgcolor="E6B958" align="center">
   <tr bgcolor="#FFFFFF">
      <td>
         <table width="70%" cellspacing="0" cellpadding="0" border="0">
            <tr bgcolor="#FFFFFF">
               <td width="15%" height="40"><b>Month</b></td>
               <td width="34%"><?php echo strtoupper($view_lead[0]['lead_month']);?></td>
                <td  width="15%"  height="40"><b>Status1</b></td>
               <td><?php echo $view_lead[0]['status1'];?></td>
               <td></td>
               <td></td>
            </tr>
            <tr bgcolor="#FFFFFF">
               <td height="40"><b>Year</b></td>
               <td><?php echo $view_lead[0]['lead_year'];?></td>
                <td height="40"><b>Status2</b></td>
               <td><?php echo $view_lead[0]['status2'];?></td>
               <td></td>
               <td></td>
            </tr>
            <tr bgcolor="#FFFFFF">
               <td height="40"><b>Lend Date</b></td>
               <td><?php echo $view_lead[0]['lead_date'];?></td>
                <td height="40"><b>Status3</b></td>
               <td><?php echo $view_lead[0]['status3'];?></td>
               <td></td>
               <td></td>
            </tr>
           
             <tr bgcolor="#FFFFFF">
               <td height="40"><b>Lead Name</b></td>
               <td><?php echo $view_lead[0]['lead_name'];?></td>
                <td height="40"><b>Lead Source</b></td>
               <td><?php echo $view_lead[0]['lead_source'];?></td>
               <td></td>
               <td></td>
            </tr>
            
            <tr bgcolor="#FFFFFF">
               <td height="40"><b>Lead Email</b></td>
               <td><?php echo $view_lead[0]['lead_mail'];?></td>
                <td height="40"><b>Metting Note</b></td>
               <td><?php echo $view_lead[0]['met_note'];?></td>
               <td></td>
               <td></td>
            </tr>
            
            <tr bgcolor="#FFFFFF">
               <td height="40"><b>Lead Phone No</b></td>
               <td><?php echo $view_lead[0]['lead_phone'];?></td>
               <td height="40"><b>Reminder Date</b></td>
               <td><?php echo $view_lead[0]['remin_date'];?></td>
               <td></td>
               <td></td>
            </tr>
            
          
            
         </table>
      </td>
   </tr>
</table>
</div>  

        </form><?php } ?>
        
              
              <input type="button" class="btn btn-secondary  btn-lg my-2 " id="agback" value="Back"  onclick="location.href='<?php echo base_url();?>index.php/Lead_followup/lead_followup_master'" />
               
                <input type="hidden" name="driver_id" value="<?php echo $driver_id;?>" />
                
    </div>
</div>
 <?php include_once('footer.php'); ?> 