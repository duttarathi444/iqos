<!DOCTYPE html>
<html lang="en" >
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta content="width=device-width, initial-scale=1" name="viewport"/>


<link rel="stylesheet" href="<?php echo base_url();?>/assets/css/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>/assets/css/bootstrap.min2.css">

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>

<link href="//maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">

<link rel="stylesheet" href="file:///Users/Chung/Desktop/Metro%20SCG/Admin%20Module/hub-m_files/css">

<link  href="<?php echo base_url();?>/assets/css/top.css" rel="stylesheet" />
<script src="<?php echo base_url();?>/assets/js/top.js"></script>
<link rel="icon" href="../../assets/img/logo-white.svg" type="png/icon type">
<script src="https://unpkg.com/hotkeys-js/dist/hotkeys.min.js"></script>
<style>
@font-face {
   font-family: myFirstFont;
   src: url(sansation_light.woff);
}

* {
   font-family: myFirstFont;
}
    .modal {
      display: none; /* Hidden by default */
      position: fixed; /* Stay in place */
      z-index: 1; /* Sit on top */
      padding-top: 100px; /* Location of the box */
      left: 0;
      top: 0;
      width: 100%; /* Full width */
      height: 100%; /* Full height */
      overflow: auto; /* Enable scroll if needed */
      background-color: rgb(0,0,0); /* Fallback color */
      background-color: rgba(0, 0, 0, 0.31); /* Black w/ opacity */
    }
    .modal-content {
      margin: auto;
      display: block;
      width: 80%;
      max-width: 700px;
    }
    
    /* Caption of Modal Image */
    #caption {
      margin: auto;
      display: block;
      width: 80%;
      max-width: 700px;
      text-align: center;
      color: #ccc;
      padding: 10px 0;
      height: 150px;
    }
    
    /* Add Animation */
    .modal-content, #caption {  
      -webkit-animation-name: zoom;
      -webkit-animation-duration: 0.6s;
      animation-name: zoom;
      animation-duration: 0.6s;
    }
    
    @-webkit-keyframes zoom {
      from {-webkit-transform:scale(0)} 
      to {-webkit-transform:scale(1)}
    }
    
    @keyframes zoom {
      from {transform:scale(0)} 
      to {transform:scale(1)}
    }
    
    /* The Close Button */
    .close {
      position: absolute;
      top: 15px;
      right: 35px;
      color: #f1f1f1;
      font-size: 40px;
      font-weight: bold;
      transition: 0.3s;
    }
    
    .close:hover,
    .close:focus {
      color: #bbb;
      text-decoration: none;
      cursor: pointer;
    }
    
    /* 100% Image Width on Smaller Screens */
    @media only screen and (max-width: 700px){
      .modal-content {
        width: 100%;
      }
    }
    #tri{
       position: absolute;
  right: 60px; 
    }
   
</style>
    </head>
    <script>
    
    async function securecode(){
        var result=await $.ajax({
            method: "POST",
            url: "http://purpuligo.com/iqos/index.php/Menu2/secure_code_check",
            async: 'true',
            dataType: 'json'
        })
        return result;
    }
    
  	hotkeys('ctrl+1', function(event, handler){
        event.preventDefault();
        var res=securecode();
        res
        .then(p=>{
            document.getElementById('secured').value=p;
            if(p>1){
        var modal = document.getElementById("myModal");
        modal.style.display = "block";
        }
        })
});

    function close1(){
        var modal = document.getElementById("myModal");
        modal.style.display="none";
    }
    
    function code_check(){
        var code = document.getElementById("secure").value;
        var secure=document.getElementById("secured").value;
        $.ajax({
                    url : "http://purpuligo.com/iqos/index.php/Menu2/token_validation",
                    method : "POST",
                    data : {secure_code: secure,enter_code: code},
                    async : true,
                    dataType : 'json',
                    success: function(data){
                        if(data[0].id > 0){
                            window.location.href=`http://purpuligo.com/iqos/index.php/Menu2/lend_module_view?a=${secure}`;
                        }else{
                            document.getElementById('code_message').innerHTML="Enter Valid Code";
                        }
                    }
    });
    }

  </script>
<body>
    
    <div id="myModal" class="modal">
        <span class="close" onclick="close1()">&times;</span>
        <center><input type="text" id="secure" placeholder="Enter Code" required></input></center>
        <center><span style="color:red" id="code_message"></span></center><br>
        <input type="hidden" id="secured">
        <center><input type="button" onclick="code_check()" value="Submit" class="btn btn-success"></center>
    </div>
    
<div id="header" class="site-header">
    <nav class="navbar navbar-dark bg-dark">
      <a href="<?php if($role_id == 1){echo site_url('Admin/product_module');}else{echo site_url('Admin/product_module2');} ?>" class="navbar-brand"><img src="../../assets/img/logo-white.svg"></a> <p id="tri" style="color:white;"><?php echo $email_id;?></p>
    <div class="navbar-toggler"  data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <!--<span class="navbar-toggler-icon"></span>-->  
    
    <button class="material-tooltip-smaller" data-toggle="tooltip"
  data-placement="top" title="Log out"><a href="<?php echo site_url('Welcome/logout'); ?>"><img src="../../assets/img/forget.svg" alt="Smiley face" height="12" width="12"></a></button>
    </div>
    
      <!--<div class="collapse navbar-collapse" id="navbarNav">-->
      <!--  <ul class="navbar-nav navbar-right">-->
      <!--    <?php global $roll_id; if($roll_id== 1){?><li class="nav-item active"><a class="nav-link"  <?php if($admin_settings == 1){ ?>href="<?php echo site_url('Admin/admin_tools'); ?>" <?php } ?>>Master Entry <span class="sr-only">(current)</span></a></li><?php }?>-->
      <!--    <li class="nav-item"><a class="nav-link" href="<?php echo site_url('Admin/admin_compliance');  ?>"></a></li>-->
      <!--    <li class="nav-item"><a class="nav-link" href="<?php echo site_url('Admin/invoicing'); ?>"></a></li>-->
      <!--    <li class="nav-item"><a class="nav-link" href="<?php echo site_url('Admin/admin_reports'); ?>"></a></li>-->
      <!--    <li class="nav-item"><a class="nav-link logout" href="<?php echo site_url('Welcome/logout'); ?>">Logout</a></li>         -->
      <!--  </ul>-->
      <!--</div>-->
    </nav>
</div>
