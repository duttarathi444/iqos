<html>
    
<?php include_once('header.php'); ?>
<body>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>

<script>

$(document).ready(function(){
  $('#CompanyPhone').mask('000-000-0000');
  $('#CompanyFax').mask('000-000-0000');
  $('#client_telephone1').mask('000-000-0000');
  $('#client_telephone2').mask('000-000-0000');
});
</script>
    
<div class="content">

	
  <div class="container">
    <h3 class="gold-underline">Product Lend Details</h3>
    
    
     <?php 
		   if(!empty($prd_lend_details))
							
							{
								// foreach($product_list as $driver){
						?>
        

          <form name="driver_add" action="driverdetails_update" method="post">
             <div class="gold-underline">
<table width="100%" cellspacing="5" cellpadding="5" border="0" bgcolor="E6B958" align="center">
   <tr bgcolor="#FFFFFF">
      <td>
         <table width="100%" cellspacing="0" cellpadding="0" border="0">
            <tr bgcolor="#FFFFFF">
               <td width="33%" height="40"><b>Lend Date</b></td>
               <td width="34%"><?php echo $prd_lend_details[0]['lending_date'];?></td>
               <td></td>
            </tr>
            <tr bgcolor="#FFFFFF">
               <td height="40"><b>Coach Name</b></td>
               <td><?php echo $prd_lend_details[0]['coach_name'];?></td>
               <td></td>
            </tr>
            <tr bgcolor="#FFFFFF">
               <td height="40"><b>Coach Email</b></td>
               <td><?php echo $prd_lend_details[0]['coach_email'];?></td>
               <td></td>
            </tr>
             <tr bgcolor="#FFFFFF">
               <td height="40"><b>Phone No</b></td>
               <td><?php echo $prd_lend_details[0]['phone_no'];?></td>
               <td></td>
            </tr>
            
            
         </table>
      </td>
   </tr>
</table>
</div>  

        </form><?php } ?>
        
        
           <h3 class="gold-underline">Lend Product Details</h3>
             <div class="gold-underline">

         <table width="100%" cellspacing="0" cellpadding="10" border="0">
             <thead>
                 
                <td><b>Received Date</b></td>
                 
                <td><b>Product Name</b></td>
            
                <td><b>Barcode</b></td>
                
                <td><b>Product Color</b></td>
            
                <td><b>Product Quantity</b></td>

                <td><b>Expected Return Date</b></td>
            
            </thead>
            <tbody>
                <?php 
		   if(!empty($prd_lend_details))
							
							{
								foreach($prd_lend_details as $product_list){
						?>
                <tr style="color:#bfaa6e">
                    <td><?php echo $product_list['received_date'];?></td>
                    <td><?php echo $product_list['product_name'];?></td>
                    <td><?php echo $product_list['product_code'];?></td>
                    <td><?php echo $product_list['product_colr'];?></td>
                    <td><?php echo $product_list['quantity'];?></td>
                    <td><?php echo $product_list['expected_return_date'];?></td>
                </tr>
                <?php }} ?>
            </tbody>
            
         </table>
         </div>
        

              
              <input type="button" class="btn btn-secondary  btn-lg my-2 " id="agback" value="Back"  onclick="location.href='<?php echo base_url();?>index.php/Lending_Product/lend_view?a=<?php echo $secure_code; ?>'" />
               
                <input type="hidden" name="driver_id" value="<?php echo $driver_id;?>" />
                
    </div>
</div>
 <?php include_once('footer.php'); ?> 