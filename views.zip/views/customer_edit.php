<html>
    
<?php include_once('header.php'); ?>
<body>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>

<script>

 
   $(document).ready(function(){
  $('#telephone_num').mask('000-000-0000');
   });

function select_prod(num){
    if(num == 1){
        var e = document.getElementById('cus_email');
        var val = e.options[e.selectedIndex].value;
        var url = "http://purpuligo.com/iqos/index.php/Stock/all_customer";
    }else if(num == 2){
        var e = document.getElementById('cust_email');
        var val = e.options[e.selectedIndex].value;
        

        var url = "http://purpuligo.com/iqos/index.php/Customers/god_father_list";
    }
    $.ajax({
                    url : url,
                    method : "POST",
                    data : {cus_id: val},
                    async : true,
                    dataType : 'json',
                    success: function(data){
                        if(num == 1){
                        document.getElementById('cus_name').value = data[0].f_name+' '+data[0].l_name;
                        document.getElementById('cus_phone').value = data[0].ph_no;
                        document.getElementById('postal').value = data[0].postal_code;
                        if(Object.keys(data[0]).length > 4){
                            document.getElementById('god_father_name').value = data[0].p_f_name+' '+data[0].p_l_name;
                            document.getElementById('god_father_email').value = data[0].p_mail;
                            document.getElementById('god_father_phone').value = data[0].p_ph;
                        }else{
                            document.getElementById('god_father_name').value = '';
                            document.getElementById('god_father_email').value = '';
                            document.getElementById('god_father_phone').value = '';
                        }
                        }else if(num == 2){
                           
                            document.getElementById('phonenumber').value = data[0].ph_no;
                            document.getElementById('dateofbirth').value= data[0].dob;
                            
                            document.getElementById('postalcode').value= data[0].postal_code;
                            document.getElementById('cus_name').value = data[0].f_name+' '+data[0].l_name;
                        }
                    }
                    });
}


function check_date(){
    var dob_date = document.getElementById('dob').value;
    var pre_date = new Date(dob_date);
    var previ_date = pre_date.getFullYear();
    var current_date =new Date(Date.now());
    var current_year = current_date.getFullYear();
    if((current_year-previ_date)>=18){
        document.getElementById('auto_click').disabled= false;
        document.getElementById('dob_message').innerHTML="";
    }else{
       document.getElementById('dob_message').innerHTML="You Are Not +18";
    }
}







</script>
    
<div class="content">

	
  <div class="container">
    <h3 class="gold-underline">God Son Edit</h3>
    
    
     <?php 
		   if(!empty($customer_list))
							
							{
								foreach($customer_list as $driver){
						?>
        

          <form name="driver_add" action="customer_update" method="post">	 
           
             <div class="form-row">
                 
                   <div class="col-md-3 mb-3">
                
                <label for="validationDefault01">God Father Email</label>
                 <select name="father" id="cust_email" class="form-control" onchange=select_prod(2)>
                    
                    <option selected value="<?php echo  $god_father_edit[0]['sl_no'];?>"><?php echo  $god_father_edit[0]['mail_id'];?></option>
                    <?php if($customer_master_list){foreach($customer_master_list as $c_list){ ?>
                    <option value="<?php echo $c_list['sl_no']; ?>"><?php echo  $c_list['mail_id'];?></option>
                    <?php }}?>
                  </select>
				
               
			   
              </div>
              
              
                   
                         <div class="col-md-3 mb-3">
                
                <label for="validationDefault01">God Father Name</label>
                <div class="input-group">
				

                  <input type="text" class="form-control" id="cus_name" placeholder="Postal Code" readonly name="gname" required style="" value="<?php echo $god_father_edit[0]['f_name'].' '.$god_father_edit[0]['l_name']; ?>" aria-describedby="inputGroupPrepend2">
				  
               </div>
			   
              </div>
                 
                                    <div class="col-md-2 mb-2">
                
                <label for="validationDefault01">God Father Postal Code</label>
                <div class="input-group">
				

                  <input type="text" class="form-control" id="postalcode" placeholder="Postal Code" readonly name="gfpcode" required style="" value="<?php echo $god_father_edit[0]['postal_code']; ?>">
				  
               </div>
			   
              </div>
              
              
                                     <div class="col-md-2 mb-2">
                
                <label for="validationDefault01">God Father Phone Number</label>
                <div class="input-group">
				

                  <input type="text" class="form-control" id="phonenumber" placeholder="Postal Code" readonly name="gfphone" required style=""   value="<?php echo $god_father_edit[0]['ph_no']; ?>"> 
				  
               </div>
			   
              </div>
             
                                  <div class="col-md-2 mb-2">
                
                <label for="validationDefault01">God Father Date Of Birth</label>
                <div class="input-group">
				

                  <input type="date" class="form-control" id="dateofbirth" placeholder="Postal Code"  readonly name="gdob" required style=""  value="<?php echo $god_father_edit[0]['dob']; ?>"> 
				  
               </div>
			   
              </div>
              
              
              
               
              <div class="col-md-3 mb-3">
                  <label for="validationDefault03">First Name</label>
                  <input type="text" class="form-control" name="fname" id="postal_code" maxlength="6"value="<?php echo $driver['f_name'];?>" placeholder="First Name">
                </div>
                
                
                 <div class="col-md-3 mb-3">
                
                <label for="validationDefault01">Last Name</label>
                <div class="input-group">

                  <input type="text" class="form-control" id="validationDefault01" placeholder="Barcode" name="lname" value="<?php echo $driver['l_name'];?>" required style="">
               </div>
              </div>
              
               <div class="col-md-3 mb-3">
               <label for="validationPrimaryEmail">Email Id</label>
                <div class="input-group">
                <input type="text" class="form-control" value="<?php echo $driver['mail_id'];?>" name="email" id="validationPrimaryEmail" placeholder="Shipment Name" aria-describedby="inputGroupPrepend2" required="" style="" onkeyup="checkemail();">
               </div>
			   
             </div>
             
             
               <div class="col-md-3 mb-3">
               <label for="validationPrimaryEmail">Phone Number</label>
                <div class="input-group">
                <input type="text" class="form-control" name="phonenumber"  value="<?php echo $driver['ph_no'];?>"id="telephone_num" placeholder="Shipment Name" aria-describedby="inputGroupPrepend2" required="" style="" onkeyup="checkemail();">
               </div>
			   
             </div>
             
                
          
              <div class="col-md-3 mb-3">
                
                <label for="validationDefault01">Date Of Birth</label>
                <div class="input-group">

                  <input type="date" class="form-control" id="validationDefault01" placeholder="Carton Number"  value="<?php echo $driver['dob'];?>" name="dob" required style="">
               </div>
              </div>
              
                  <div class="col-md-3 mb-3">
                
                <label for="validationDefault01">Postal Code</label>
                <div class="input-group">

                  <input type="text" class="form-control" id="validationDefault01" placeholder="Carton Number"  value="<?php echo $driver['postal_code'];?>" name="pcode" required style="" maxlength="6">
               </div>
              </div>
              
            </div>
			 
			  
           
           
           
           
           
           
           
           
           
 
          
   <div class="btn-group" role="group" aria-label="Basic example">
		<input type="button" class="btn btn-secondary btn-lg my-2 pull-left" id="backk" value="Back" onclick="location.href='<?php echo base_url();?>index.php/Customers/god_son_master'"/>
		
		<input type="submit" class="btn btn-success  btn-lg my-2 pull-left" id="auto_click" value="Submit" onclick="form_submit()"/>
		
		</div>
               
                <input type="hidden" name="sl_no" value="<?php echo $sl_no;?>" >
                <input type="hidden" id="TS" name="TS" value="<?php echo time();?>" />

        </form><?php }} ?>
                
    </div>
</div>
<script type="text/javascript"> 

function checkemail()
{
  var user_email=document.getElementById("validationPrimaryEmail").value;
  var flg='3';
  
 if(user_email)
 {
  $.ajax({
  method: 'post',
  url: 'http://purpuligo.com/booya/index.php/User_auth/mail_validation_client_agent',
  data: {
   user_email:user_email,flg:flg
  },
  success: function (response) {
   $( '#email_status' ).html(response);
   if(response=="OK")	
   {
     return true;	
   }
   else
   {
     return false;	
   }
  }
  });
 }
 else
 {
  $( '#email_status' ).html("");
  return false;
 }
}
</script>
<script>
        $(document).ready(function(){
			
			
            
            $('#province').change(function(){ 
                var id=$(this).val();
				
                $.ajax({
                    url : "<?php echo site_url('Admin/get_region_category_by_province');?>",
                    method : "POST",
                    data : {id: id},
                    async : true,
                    dataType : 'json',
                    success: function(data){
                        var html = '';
                        var i;
                        for(i=0; i<data.length; i++){
                            html += '<option value='+data[i].product_type+'>'+data[i].product_type+'</option>';
                            $('#postal_code').val(data[i].product_code);
                        }
                        $('#region').html(html);
                        
                    }
                });
            }); 

            $.ajax({
                url : "<?php echo site_url('Admin/get_region_category_by_province');?>",
                method : "POST",
                data : {id: <?php echo $p_id;?>},
                async : true,
                dataType : 'json',
                success: function(data){
                    var html = '';
                    var i;
                    for(i=0; i<data.length; i++){
                    html += '<option value='+data[i].product_type+'>'+data[i].product_type+'</option>';
					console.log(html);
                    $('#postal_code').val(data[i].postal_code);
                }
                $('#region').html(html);
                $('#region').val(<?php echo $c_id; ?>);

                }
				
            });
           
            
            
			
			
          /*   $.ajax({
            url : "<?php echo site_url('Admin/client_list_ajx');?>",
                    method : "POST",
                    async : true,
                    dataType : 'json',
                    success: function(data){
                        var html = '';
                        var i;
                        for(i=0; i<data.length; i++){
							
							 if($data[i].client_id == $hubb_list[$client_id])
    {

							
                            $("#client").append('<option value='+data[i].client_id+' selected="selected">'+data[i].client_name+'</option>');
	}
                            //html += '<option value='+data[i].client_id+'>'+data[i].client_name+'</option>';
                        }
                        $('#client').multiselect({
                        includeSelectAllOption: true,
                        buttonWidth: 500,
                        enableFiltering: true,
                        selectAll: true
						
                    });
                    
                    }
            }); */
			
			$('#region').change(function(){ 
			console.log("clicked");
                var id=$(this).val();
                $.ajax({
                    url : "<?php echo site_url('Admin/get_fsa_by_zone');?>",
                    method : "POST",
                    data : {id: id},
                    async : true,
                    dataType : 'json',
                    success: function(data){
                        for(i=0; i<data.length; i++){
                            $('#postal_code').val(data[i].product_code);
                        }
                    }
                });
            }); 
			$('#phone_no1').mask('000-000-0000');
			
			
        });
		
		
		
    </script>

 <?php include_once('footer.php'); ?>         

              