<html>
    
<?php include_once('header.php'); ?>
<body>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.10/jquery.mask.js"></script>

<script>
$(document).ready(function(){
 // $('#CompanyPhone').mask('000-000-0000');
  $('#posta').mask('000000');
  //$('#client_telephone2').mask('000-000-0000');
});
</script>

<script>
function check_date(){
    var dob_date = document.getElementById('dob').value;
    var pre_date = new Date(dob_date);
    var previ_date = pre_date.getFullYear();
    var current_date =new Date(Date.now());
    var current_year = current_date.getFullYear();
    if((current_year-previ_date)>=18){
        document.getElementById('auto_click').disabled= false;
        document.getElementById('dob_message').innerHTML="";
    }else{
       document.getElementById('dob_message').innerHTML="You Are Not +18";
    }
}

function validate(){
    console.log('hello');
    var posta= document.getElementById('posta').value;
    console.log(posta);
}

</script>
    
<div class="content">

	
  <div class="container">
      <a id="back2Top" title="Back to top" href="#">&#10148;</a>
    <h2 class="gold-underline">Add new Customers</h2>
        

          <form name="driver_add" ID = "frmMain" action="Customers_registration" method="post" enctype="multipart/form-data">	
             	  
            <div class="form-row">
              <div class="col-md-3 mb-3">
                
                <label for="validationDefault01">Customer Type</label>
				
                <select name="name" id="province" class="form-control" onchange = "disableDrop();">>
                      <?php if($customer_type){foreach($customer_type as $p_list){ ?>
	
                    <option selected="" value="<?php echo $p_list['cust_type']; ?>"><?php echo  $p_list['cust_type'];?></option>
                    <?php }}?>
                  </select>
				  
			   
              </div>
			   <div class="col-md-3 mb-3">
                
                <label for="validationDefault01">God Father Name</label>
				
                <select name="father" ID = "sltSecondary" class="form-control">
                    <?php if($customer_master_list){foreach($customer_master_list as $p_list){ ?>
	
                    <option selected="" value="<?php echo $p_list['sl_no']; ?>"><?php echo  $p_list['f_name'].' '.$p_list['l_name'];?></option>
                    <?php }}?> 
                  </select>
				  
			   
              </div>

			  <div class="col-md-3 mb-3">
                
                <label for="validationDefault01">First Name</label>
                <div class="input-group">
				

                  <input type="text" class="form-control" id="validationDefault01" placeholder="First Name" name="product_type" required style="">
				  
               </div>
			    
			  
            </div>
			 <div class="col-md-3 mb-3">
                
                <label for="validationDefault01">Last Name</label>
                <div class="input-group">
                  <input type="text" class="form-control" id="validationDefault01" placeholder="Last Name" name="product_code" required style="">
               </div>
			   
              </div>
              
			  <div class="col-md-3 mb-3">
                
                <label for="validationDefault01">Email Address</label>
                <div class="input-group">
                  <input type="email" class="form-control" id="client_email" placeholder="Email Address" onchange="check(1)" name="email" required>
               </div>
			   <div style="color:red" id="email_message"></div>
              </div>
              
			  <div class="col-md-3 mb-3">
                
                <label for="validationDefault01">Phone Number</label>
                <div class="input-group">
                  <input type="text" class="form-control" id="client_telephone" placeholder="Phone Number" onchange="check(2)" name="phone" required>
               </div>
			   <span style="color:red" id="phone_message"></span>
              </div>
              
			  <div class="col-md-3 mb-3">
                
                <label for="validationDefault01">Date Of Birth</label>
                <div class="input-group">
				

                  <input type="date" class="form-control" id="dob" placeholder="DOB" name="dob" required onchange="check_date()">
               </div>
			   <span style="color:red" id="dob_message"></span>
              </div>
              
			  <div class="col-md-3 mb-3">
                <label for="validationDefault01">Postal Code</label>
                <div class="input-group">
                  <input type="text" class="form-control" id="posta" placeholder="Postal Code" name="pcode" required>
               </div>
              </div>
			  
            </div>
           
          
		<?php
		   if($customer_type)
                                {
                                    foreach($customer_type as $p_list)
                                     {
                                                    
								    if($p_list['cust_type'] =="God Father")  
                                
                                { 
                            ?>
			   <input type="hidden" id="TS" name="fid" value="1" />
                    <?php 
                        }
                        else
                        {
                        ?>
			   <input type="hidden" id="TS" name="fid" value="2" />
                          <?php 
                                 }
                                }
                               }                                           
                               ?>

		  

        </form>
        
        <div class="btn-group" role="group" aria-label="Basic example">
		<input type="button" class="btn btn-secondary btn-lg my-2 pull-left" id="backk" value="Back" onclick="location.href='<?php echo base_url();?>index.php/Customers/customer_master'"/>
		
		
		
		<input type="submit" class="btn btn-success  btn-lg my-2 pull-left" id="auto_click" disabled value="Submit" onclick="form_submit()"/>
		
		</div>
                
    </div>
</div>

<script type = "text/javascript">
function disableDrop(){
     if(frmMain.province.options[0].selected){
          frmMain.sltSecondary.disabled = true;
     }
     else{
         frmMain.sltSecondary.disabled = false;
     }
}
</script>
<script type="text/javascript"> 

function check(id)
{
    if(id==1){
        var data=document.getElementById("client_email").value;
        var url="http://purpuligo.com/iqos/index.php/Customers/email_exist";
        if(data == ''){
            document.getElementById("email_message").innerHTML="Enter Email Address";
            return;
        }
    }else if(id==2){
        var url="http://purpuligo.com/iqos/index.php/Customers/phone_exist";
        var data=document.getElementById("client_telephone").value;
        if(data == ''){
            document.getElementById("phone_message").innerHTML="Enter Phone Number";
            return;
        }
    }
  $.ajax({
  method: 'post',
  url: url,
  data: {alldata : data},
  dataType : 'json',
  success: function (response) {
    if(response[0].num > 0){
      if(id == 1)	
      {
        document.getElementById("email_message").innerHTML="Sorry!! email is already exist";
        return;
      }
      else
      {
        document.getElementById("phone_message").innerHTML="Sorry!! phone no is already exist";
        return;	
      }
    }
  }
  });
 
}
function myfun(){
    console.log('hello');
}
</script>
 <?php include_once('footer.php'); ?>         

              