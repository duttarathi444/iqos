<html>
    
<?php include_once('header.php'); ?>
<body>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>

<script>

$(document).ready(function(){
  $('#CompanyPhone').mask('000-000-0000');
  $('#CompanyFax').mask('000-000-0000');
  $('#client_telephone1').mask('000-000-0000');
  $('#client_telephone2').mask('000-000-0000');
});
</script>
    
<div class="content">

	
  <div class="container">
    <h3 class="gold-underline">Product Sale Details</h3>
    
    
     <?php 
		   if(!empty($sale_products_data))
							
							{
						?>
        

          <form name="driver_add" action="driverdetails_update" method="post">
             <div class="gold-underline">
<table width="100%" cellspacing="10" cellpadding="15" border="0" bgcolor="E6B958" align="center">
   <tr bgcolor="#FFFFFF">
      <td>
         <table width="50%" cellspacing="10" cellpadding="10" border="0">
             
             <tr bgcolor="#FFFFFF">
               <td width="15%" height="40"><b>Sale Date</b></td>
               <td width="15%"><?php echo $sale_products_data[0]['prd_sale_date'];?></td>
               <td width="33%" height="40"><b>Quantity</b></td>
             <td width="15%"><?php echo $sale_products_data[0]['prd_quantity'];?></td>
             <td  width ="33%" height="40"><b>PE1 Status</b></td>
               <td width="15%"><?php echo $sale_products_data[0]['pe1_status'];?></td>
            </tr>
            
            <tr bgcolor="#FFFFFF">
               <td width="33%" height="40"><b>Customer Name</b></td>
               <td width="34%"><?php echo $sale_products_data[0]['f_name'].' '.$sale_sdata['l_name'];?></td>
             <td height="40"><b>Product Serial No</b></td>
               <td><?php echo $sale_products_data[0]['serial_no'];?></td>
               <td height="40"><b>PE2 Date</b></td>
               <td><?php echo $sale_products_data[0]['pe2_date'];?></td>
            </tr>
            
            <tr bgcolor="#FFFFFF">
               <td width="33%" height="40"><b>Device Name</b></td>
               <td width="34%"><?php echo $sale_products_data[0]['product_name'];?></td>
               <td height="40"><b>SAP Order No</b></td>
               <td><?php echo $sale_products_data[0]['sap_order_no'];?></td>
                <td height="40"><b>PE2 Status</b></td>
               <td><?php echo $sale_products_data[0]['pe2_status'];?></td>
               <td></td>
            </tr>
            
            <tr bgcolor="#FFFFFF">
               <td width="33%" height="40"><b>Product Type</b></td>
               <td width="34%"><?php echo $sale_products_data[0]['product_type'];?></td>
                <td height="40"><b>Device Registation</b></td>
               <td><?php echo ($sale_products_data[0]['device_reg']==1)? 'Yes':'No';?></td>
                <td height="40"><b>Q+1 Conversion Date</b></td>
               <td><?php echo $sale_products_data[0]['pe3_date'];?></td>
               <td></td>
            </tr>
            
            <tr bgcolor="#FFFFFF">
               <td width="33%" height="40"><b>Product Color</b></td>
               <td width="34%"><?php echo $sale_products_data[0]['product_colr'];?></td>
               <td height="40"><b>Device Registation Date</b></td>
               <td><?php echo $sale_products_data[0]['device_reg_date'];?></td>
               <td height="40"><b>Q+1 Conversion Status</b></td>
               <td><?php echo $sale_products_data[0]['pe3_status'];?></td>
               <td></td>
               <td></td>
            </tr>
            
            <tr bgcolor="#FFFFFF">
               <td width="33%" height="40"><b>Barcode</b></td>
               <td width="34%"><?php echo $sale_products_data[0]['product_code'];?></td>
               <td height="40"><b>PE1 Date</b></td>
               <td><?php echo $sale_products_data[0]['pe1_date'];?></td>
               <td></td>
            </tr>
          
            
           
            
          
            
         </table>
      </td>
   </tr>
</table>

<table width="100%" cellspacing="0" cellpadding="10" border="0">
             <thead>
                 
                <td><b>Heets Name</b></td>
                
                <td><b>Barcode</b></td>
                
                <td><b>Heets Type</b></td>
                
                <!--<td><b>Heets Color</b></td>-->
            
                <!--<td><b>Product Barcode</b></td>-->
            
                <td><b>Sale Quantity</b></td>
            
            </thead>
            <tbody>
                <?php 
		   if(!empty($sale_product_show))
							
							{
								foreach($sale_product_show as $product_list){
						?>
                <tr>
                    <td><?php echo $product_list['product_name'];?></td>
                    <td><?php echo $product_list['product_code'];?></td>
                    <td><?php echo $product_list['product_type'];?></td>
                    <!--<td><?php echo $product_list['product_colr'];?></td>-->
                    <!--<td><?php echo $product_list['product_barcode'];?></td>-->
                    <td><?php echo substr($product_list['product_quantity'],1);?></td>
                </tr>
                <?php }} ?>
            </tbody>
            
         </table>

</div>  


               <input type="button" class="btn btn-secondary  btn-lg my-2 " id="agback" value="Back"  onclick="location.href='<?php echo base_url();?>index.php/Stock/product_sale'" />
               

        </form><?php } ?>
                
    </div>
</div>
 <?php include_once('footer.php'); ?>         

              