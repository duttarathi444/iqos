<html>
    <head>
        <style>
  /*  table{*/
        /*border: 1px solid black;*/
  /*      width: 100%;*/
  /*      margin-bottom: 20px;*/
		/*border-collapse: separate;*/
        /*border-spacing: 20 0px;*/
  /*  }*/
  /*  table td{*/
  /*      padding: 2px;*/
  /*      text-align: left;*/
  /*  }*/
    </style>
    </head>
    
<?php include_once('header.php'); ?>
<body onload="putdate()">
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>

<script>
$(document).ready(function(){
  $('#CompanyPhone').mask('000-000-0000');
  $('#lead_phone').mask('000-000-0000');
  $('#client_telephone1').mask('000-000-0000');
  $('#client_telephone2').mask('000-000-0000');
//   $('#message').hide();
});
</script>

<script  type="text/javascript" language="javascript" >
// function addAll(){
//         var products_id=document.getElementsByName("product_id");
//         var return_date=document.getElementsByName("res_date");
//         var p_quantity=document.getElementsByName("quantity");
        
//         var c_email=document.getElementById("coach_email").value;
//         var c_name=document.getElementById("coach_name").value;
//         var c_phone=document.getElementById("phone_no").value;

// var b=[];
// var e=[];
// var f=[];
// var j=0;
// for(var i=0;i<products_id.length;i++){
	
// 	var b1=products_id[i].value;
// 	var e1=return_date[i].value;
// 	var f1=p_quantity[i].value;
// 	if(b1 != '' && e1 != '' && f1 != ''){
// 	b[j]=b1;
// 	e[j]=e1;
// 	f[j]=f1
// 	j++;
// 	}else{
// 	    alert('Fill Up all the Details');
// 	    return false;
// 	}
// }

// document.getElementById("all-product").value=b;
// document.getElementById("all-quantity").value=f;
// document.getElementById("all-return_date").value=e;
// if(c_email!='' && c_name!='' && c_phone!=''){
//     document.forms['lend_add'].submit();
// }else{
//     alert('Fill Up all the Details');
// 	    return false;
// }
// }
// $('document').ready(function(){
//     $('#message').hide();
// })

// function lead_add(){
//     var month=document.getElementById('lead_month');
//     var lmonth=month.options[month.selectedIndex].value;
//     var year=document.getElementById('lead_year');
//     var lyear=year.options[year.selectedIndex].value;
//     var ldate=document.getElementById('lead_date').value;
//     var lname=document.getElementById('lead_name').value;
//     var lemail=document.getElementById('lead_mail').value;
//     var lphone=document.getElementById('lead_phone').value;
//     var lstatus1=document.getElementById('status1').value;
//     var lstatus2=document.getElementById('status2').value;
//     var lstatus3=document.getElementById('status3').value;
//     var lsource=document.getElementById('source').value;
//     var lmet_note=document.getElementById('met_note').value;
//     var lremin_date=document.getElementById('remin_date').value;
//     $('document').ready(function(){
//     $.ajax({
//     url: "http://purpuligo.com/iqos/index.php/Lead_followup/lead_data_add",
//     method: 'POST',
//     data: {lead_month: lmonth,lead_year: lyear,lead_date: ldate,lead_name: lname,lead_mail: lemail,lead_phone: lphone,status1: lstatus1,status2: lstatus2,status3: lstatus3,source: lsource,met_note: lmet_note,remin_date: lremin_date},
//     dataType : 'json',
//     async: 'true',
//     success: function (response) {
//     if(response[0].id > 0){
//         $('#message').show();
//         return;
//       }
//     }
//   });
//     });
// }

function putdate(){
    var aext=document.getElementById('textar').value;
    document.getElementById('met_note').value=aext;
}

</script>

<div class="content">
  <div class="container">
      <a id="back2Top" title="Back to top" href="#">&#10148;</a>
    <h3 class="gold-underline">Edit Lead</h3>
        
  <!--      <div class="alert alert-success alert-dismissible" id="message">-->
  <!--<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>-->
  <!--<center><p>Fill Up all the Details</p></center>-->
  <!--</div>-->
    <!--<center>-->
    <!--  <div style="color:green;" id="message">-->
    <!--    <h4>Your Data has been Submitted</h4>      -->
    <!--  </div>-->
    <!--</center>-->
    <!--?a=<?php echo $secure_code; ?>-->

          <form name="" action="lead_edit_data" method="post" enctype="multipart/form-data">	

            <input type="hidden" name="lead_id" value="<?php echo $edit_lead[0]['lead_id']?>">
            <input type="hidden" id="textar" value="<?php echo $edit_lead[0]['met_note']?>">

              <div class="form-row">
                    <div class="col-md-3 mb-3">
                        <label for="lead_month">Select Month</label>
                        <div class="input-group">
                <select type="text" class="form-control" id="lead_month" name="lead_month" required>
                    <option value="<?php echo $edit_lead[0]['lead_month']?>" selected readonly><?php echo strtoupper($edit_lead[0]['lead_month'])?></option>
                    <option value="jan">JAN</option>
                    <option value="feb">FEB</option>
                    <option value="mar">MAR</option>
                    <option value="apr">APR</opti2020
                    <option value="may">MAY</option>
                    <option value="jun">JUN</option>
                    <option value="jul">JUL</option>
                    <option value="aug">AUG</option>
                    <option value="sep">SEP</option>
                    <option value="oct">OCT</option>
                    <option value="nov">NOV</option>
                    <option value="dec">DEC</option>
                    </select>
               </div>
                </div>
                
           
              <div class="col-md-3 mb-3">
               <label for="lead_year">Select Year</label>
                <div class="input-group">
                <select type="text" class="form-control" id="lead_year" name="lead_year" required>
                    <option value="<?php echo $edit_lead[0]['lead_year']?>" selected readonly><?php echo $edit_lead[0]['lead_year']?></option>
                    <option value="2020">2020</option>
                    <option value="2021">2021</option>
                    <option value="2022">2022</option>
                    <option value="2023">2023</option>
                    <option value="2024">2024</option>
                    <option value="2025">2025</option>
                    <option value="2026">2026</option>
                    <option value="2027">2027</option>
                    <option value="2028">2028</option>
                    <option value="2029">2029</option>
                    <option value="2030">2030</option>
                    <option value="2031">2031</option>
                    </select>
               </div>
             </div>
           </div>
           <!--second stage-->
    <!--<div>-->
        <!--<div class="container">-->
              <h4>Enter Lead Details Below </h4>
              
        <!--<table style="width: 100%;">-->
        <!--    <tbody>-->
        <!--    <tr>-->
                
                <!--<td style="text-align: center;padding-bottom: 25px;padding-left: 15px;"><input type="hidden" name="record"></td>-->
                
            <!--<td>-->
            <div class="form-row">
                <div class="col-md-3 mb-3">
                   <label for="validationPrimaryEmail">Lead Date</label>
                   <div class="input-group">
                    <input type="date" value="<?php echo $edit_lead[0]['lead_date']?>" class="form-control" id="lead_date" name="lead_date">
                    </div>
                </div>
             
                <div class="col-md-3 mb-3">
                   <label for="lead_name">Name</label>
                    <div class="input-group">
                      <input type="type" class="form-control" value="<?php echo $edit_lead[0]['lead_name']?>" id="lead_name" placeholder="Lead Name" required="" name="lead_name">
                   </div>
                </div>
            
            
            
            <div class="col-md-3 mb-3">
               <label for="lead_mail">Email</label>
                <div class="input-group">
                  <input type="email" class="form-control" id="lead_mail" value="<?php echo $edit_lead[0]['lead_mail']?>" placeholder="Lead Email" required="" name="lead_mail">
               </div>
            </div>
            
               <div class="col-md-3 mb-3">
               <label for="lead_phone">Phone No</label>
                <div class="input-group">
                  <input type="text"  class="form-control" id="lead_phone" value="<?php echo $edit_lead[0]['lead_phone']?>" name="lead_phone" required="" placeholder="Lead Phone No">
               </div>
            </div>
            </div>
            
            
            <div class="form-row">
              <div class="col-md-3 mb-3">
               <label for="">Status1</label>
                <div class="input-group">
                  <input type="text" name="status1" class="form-control" value="<?php echo $edit_lead[0]['status1']?>" id="status1" required="" placeholder="Status1">
               </div>
            </div>
            
            <!--<input type="hidden" name="" id="totalStock">-->
            
             <div class="col-md-3 mb-3">
               <label for="status2">Status2</label>
                <div class="input-group">
                  <input type="text" class="form-control" value="<?php echo $edit_lead[0]['status2']?>" name="status2" id="status2" placeholder="Status2">
               </div>
               </div>
            
            
            
               <div class="col-md-3 mb-3">
               <label for="status3">Status3</label>
                <div class="input-group">
                  <input type="text" class="form-control" value="<?php echo $edit_lead[0]['status3']?>" name="status3" id="status3" placeholder="Status3">
               </div>
               </div>
               
               <div class="col-md-3 mb-3">
               <label for="source">Source</label>
                <div class="input-group">
                  <input type="text" class="form-control" value="<?php echo $edit_lead[0]['lead_source']?>" name="source" id="source" placeholder="Source">
               </div>
               </div>
               
               </div>
               
            <div class="form-row">
               <div class="col-md-3 mb-3">
               <label for="met_note">Meeting Note</label>
                <div class="input-group">
                  <textarea type="text" class="form-control" name="met_note" id="met_note"></textarea>
               </div>
               </div>
               
               <div class="col-md-3 mb-3">
               <label for="remin_date">Reminder Date</label>
                <div class="input-group">
                  <input type="date" class="form-control" value="<?php echo $edit_lead[0]['remin_date']?>" name="remin_date" id="remin_date" required>
               </div>
               </div>
               
               </div>
            <!--   </td>-->
            <!--  </tr>-->
            <!--  </tbody>-->
            <!--</table>-->
           
           <!--<table style="width: 100%;">-->
           <!--    <tbody id="showTable">-->
   
           <!--     </tbody>-->
           <!--</table>-->
           
     <!--   <input type="hidden" name="al-products" id="all-product" value="">-->
	    <!--<input type="hidden" name="al-quantities" id="all-quantity" value="">-->
	    <!--<input type="hidden" name="al-return_date" id="all-return_date" value="">-->
          
          
          
            
            <div class="btn-group" role="group" aria-label="Basic example">
		    <input type="button" class="btn btn-secondary btn-lg my-2 pull-left" id="backk" value="Back" onclick="location.href='<?php echo base_url();?>index.php/Lead_followup/lead_followup_master'"/>
		
		<!--<input type="button" class="btn btn-success  btn-lg my-2 pull-left" id="add-row" value="Add Row">-->
		
		<!--<button type="button" class="btn btn-success  btn-lg my-2 pull-left" id="delete-row">Delete Row</button>-->
		
		<input type="submit" class="btn btn-success  btn-lg my-2 pull-left" id="auto_click" value="Submit"/>
		
		</div>
		 <input type="hidden" id="TS" name="TS" value="<?php echo time();?>" />
        </form>
        
</div>
</div>
</div>

<script type="text/javascript">
//     $(document).ready(function(){
//         $("#add-row").click(function(){
//             var markup = `<tr>
//                 <td style="text-align: center;padding-bottom: 25px;"><input type="checkbox" name="record"></td>
//                 <td>
//                 <div class="form-row">
//                 <div class="col-md-2 mb-3">
//                   <select name="product_id" onchange="show(this)" id="product" class="form-control">
//                   <option selected="">Select Product Name</option>
//                       <?php if($product_list){foreach($product_list as $p_list){ ?>
//                     <option value="<?php echo $p_list['product_id']; ?>"><?php echo  $p_list['product_name'];?></option>
//                     <?php }}?>
//                   </select>
//                 </div>
                
//                 <div class="col-md-2 mb-3">
//                 <div class="input-group">
//                   <input type="type" class="form-control" id="serial_no" placeholder="Product Barcode" readonly name="serial_no">
//                 </div>
//                 </div>
                
//                 <div class="col-md-2 mb-3">
//                 <div class="input-group">
//                   <input type="type" class="form-control" id="prd_type" placeholder="Product Type" readonly value=""  name="prd_type">
//               </div>
//             </div>
                
//                 <div class="col-md-2 mb-3">
//                 <div class="input-group">
//                   <input type="text"  class="form-control" id="prod_color"  name="prod_color" readonly placeholder="Product Color" required="">
//                 </div>
//                 </div>
                
//                 <div class="col-md-2 mb-3">
//                     <div class="input-group">
//                   <input type="text" class="form-control" required name="quantity" id="quantity" readonly onchange="check(this)" placeholder="Quantity">
//                   </div>
//                 </div>
                
//                 <input type="hidden" name="" id="totalStock">
                
//                 <div class="col-md-2 mb-3">
//                 <div class="input-group">
//                   <input type="date" class="form-control" name="res_date" id="res_date" readonly required="">
//               </div>
//               </div>
//             </div>
//                         </td>
//                     </tr>`;
//             $("#showTable").append(markup);
//         });
        
//         // Find and remove selected table rows
//         $("#delete-row").click(function(){
//             $("table tbody").find('input[name="record"]').each(function(){
//             	if($(this).is(":checked")){
//                     $(this).parents("tr").remove();
//                 }
//             });
//         });
//     });    

// function show(id){
//     var val1=id.options[id.selectedIndex].value;
//     var thisorder = $(id).parents('tr');
//     var tds = thisorder.find("td");
//     var productdata=trdData(val1);
//     var serial_no=tds.find('input[id="serial_no"]');
//     var quan=tds.find('input[id="totalStock"]');
//     var prd_color=tds.find('input[id="prod_color"]');
//     var prd_type=tds.find('input[id="prd_type"]');
//     var receive_date=tds.find('input[id="res_date"]');
//     var quantity=tds.find('input[id="quantity"]');
//     productdata
//     .then(p=>{
//         console.log(p);
//         receive_date[0].readOnly=false;
//         receive_date[0].value='';
//         quantity[0].readOnly=false;
//         quantity[0].value="";
//         quantity[0].placeholder=`Available Amount ${p[0].customer_stock}`;
//         quan[0].value=p[0].customer_stock;
//         serial_no[0].value=p[0].product_code;
//         prd_color[0].value=p[0].product_colr;
//         prd_type[0].value=p[0].product_type;
//         receive_date[0].value=dateput();
//     })
// }

//  async function trdData(val1){
//     const result = await $.ajax({
//                     url : "http://purpuligo.com/iqos/index.php/Stock/all_product_list?a=<?php echo $secure_code; ?>",
//                     method : "POST",
//                     data : {cus_id: val1},
//                     async : true,
//                     dataType : 'json'
//     });
//     return result
// }

// function check(id){
//     var quantity= id.value;
//     var thisorder = $(id).parents('tr');
//     var tds = thisorder.find("td");
//     var qua=tds.find('input[id="totalStock"]')[0].value;
//     if(+quantity > +qua || quantity < 1 || (/[!@#$%^&*(),.?":{}|<>]/g.test(quantity)==true)){
//         id.value="";
//     }
// }

// function dateput(){
//     var datenow=new Date(Date.now());
//     var month=+datenow.getMonth()+1;
//     if((month+"").length<2){
//         month='0'+month;
//     }
//     var date='';
//     if((datenow.getDate()+"").length<2){
//         date= '0'+datenow.getDate();
//     }
//     var newdate = datenow.getFullYear()+'-'+month+'-'+datenow.getDate();
//     return newdate;
// }

// function putdate(){
//     var newdate=dateput();
//     document.getElementById('lead_date').value=newdate;
//     document.getElementById('remin_date').value=newdate;
// }

</script>
    
 <?php include_once('footer.php'); ?>         

              