<!DOCTYPE html>
<html>
    <head>
        <style>
    table{
        /*border: 1px solid black;*/
        width: 100%;
        margin-bottom: 20px;
		border-collapse: separate;
        /*border-spacing: 20 0px;*/
    }
    table td{
        padding: 2px;
        text-align: left;
    }
    </style>
    </head>
    
<?php include_once('header.php'); ?>
<body>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>

<script>
$(document).ready(function(){
  $('#CompanyPhone').mask('000-000-0000');
  $('#CompanyFax').mask('000-000-0000');
  $('#client_telephone1').mask('000-000-0000');
  $('#client_telephone2').mask('000-000-0000');
});
</script>

<script  type="text/javascript" language="javascript" >
function addAll(){
    
    var product_stock_id = document.getElementsByName("product_stock_id");
    var exist_product_id = document.getElementsByName("exist_product_id");
    var exist_product_quantity = document.getElementsByName("exist_product_quantity");
    
    var stock_id=[];
    var product_id=[];
    var product_quantity=[];
    var l=0;
    
    for(var k=0;k<product_stock_id.length;k++){
        stock_id[l] = product_stock_id[k].value;
        product_id[l] = exist_product_id[k].value;
        product_quantity[l] = exist_product_quantity[k].value;
        l++;
    }
    console.log(stock_id);
    console.log(product_id);
    console.log(product_quantity);
    
    document.getElementById("all_stock_id").value = stock_id;
    document.getElementById("all_product_id").value = product_id;
    document.getElementById("all_product_quantity").value = product_quantity;
    
    
        var products=document.getElementsByName("product");
        var quantitys=document.getElementsByName("quantity");


var b=[];
var d=[];
var j=0;
for(var i=0;i<products.length;i++){
	var b1=products[i].value;
	var d1=quantitys[i].value;
	    if(b1!='' && d1!=''){
	b[j]=b1;
	d[j]=d1;
	j++;
	    }else{
	        alert('Fill Up All Details');
	        return false;
	    }
}
if(b.length != 0){
document.getElementById("all-product").value=b;
document.getElementById("all-quantity").value=d;
}else{
    b[0]=0;
    d[0]=0;
    document.getElementById("all-product").value=b;
    document.getElementById("all-quantity").value=d;
}
console.log(b);
console.log(d);
document.getElementById('driver_add').submit();
}

function select_prod(id){
    //var val= id.options[id.selectedIndex].innerHTML;
    var val1= id.options[id.selectedIndex].value;
    var thisorder=$(id).parents('tr');
    var tds=thisorder.find('td');
    //var bar=tds.find('input[id="barcode_no"]')[0];
    var prd_code=tds.find('input[id="prd_code"]')[0];
    var prd_type=tds.find('input[id="prd_type"]')[0];
    var prd_color=tds.find('input[id="prd_color"]')[0];
    var quantity=tds.find('input[id="quantity"]')[0];
    var productdata=trdData(val1);
    quantity.value='';
    
    productdata
    .then(p=>{
        prd_code.value=p[0].product_code;
        prd_type.value=p[0].product_type;
        prd_color.value=p[0].product_colr;
    })
}

async function trdData(val1){
    const result = await $.ajax({
                    url : "http://purpuligo.com/iqos/index.php/Stock/all_product_list",
                    method : "POST",
                    data : {cus_id: val1},
                    async : true,
                    dataType : 'json'
    });
    return result
}

function check(){
    
    var datenow=new Date(Date.now());
    var car_id=datenow.getFullYear()+document.getElementById('carton_num').value;
    $.ajax({
                    url : "http://purpuligo.com/iqos/index.php/Stock/check_carton",
                    method : "POST",
                    data : {id: car_id},
                    async : true,
                    dataType : 'json',
                    success: function(data){
                        if(data[0].num > 0){
                            document.getElementById('cartom_message').innerHTML="This Carton No already Exist";
                        }else{
                            document.getElementById('cartom_message').innerHTML="";
                            document.getElementById('carton_no').value=car_id;
                            document.getElementById('auto_click').disabled=false;
                        }
                    }
    });
}

window.pressed = function(b,a){
  var input = b.target;
  console.log(a);
  var reader = new FileReader();
    var temp = a.name[a.name.length-1];
    var im = document.getElementById('im'+temp);
    var a1 = document.getElementById('fileLabel'+temp);
    if(a.value == "")
    {
        a1.innerHTML = "Choose file";
    }
    else
    {
        var theSplit = a.value.split('\\');
        a1.innerHTML = theSplit[theSplit.length-1];

        reader.onload = function(){
      var dataURL = reader.result;
      im.src = dataURL;
    };
    reader.readAsDataURL(input.files[0]);

    }
};

</script>
<center><h4 id="error_message">Product is Deleted</h4></center>
<div class="content">
  <div class="container">
      <a id="back2Top" title="Back to top" href="#">&#10148;</a>
    <h3 class="gold-underline">Stock Edit</h3>
        
        <!--stock_in_edit_data-->

          <form id="driver_add" action="stock_in_edit_data" method="post" enctype="multipart/form-data">	
	    <?php
	    if($edit == 1){?>
	     <div class="form-row">
              <div class="col-md-3 mb-3">
               <label for="validationPrimaryEmail">Carton Number</label>
                <div class="input-group">
                  <input type="text" class="form-control" id="validationDefault01" onchange="check()" placeholder="Carton Number" name="carton_num" required value="<?php echo  substr($stock_in_data[0]['carton_no'],4);?>">
               </div>
			  <span style="color:red" id="cartom_message"></span>
             </div>
             
             <input type="hidden" name="carton_no" value="<?php echo  $stock_in_data[0]['carton_no'];?>" id="carton_no">
             
             <div class="col-md-3 mb-3">
               <label for="validationPrimaryEmail">Received Date</label>
                <div class="input-group">
                  <input type="date" class="form-control" id="validationDefault01" placeholder="date" name="receive_date" required value="<?php echo  $stock_in_data[0]['received_date'];?>">
               </div>
			   <!--<span id="email_status"></span>-->
             </div>
           <!--</div>-->
           <!--	     <div class="form-row">-->
              <div class="col-md-2 mb-3">
               <label for="validationPrimaryEmail">Received From</label>
                <div class="input-group">
                <input type="text" class="form-control" name="receivded_from" id="validationPrimaryEmail" placeholder="Received Name" aria-describedby="inputGroupPrepend2" required="" value="<?php echo  $stock_in_data[0]['received_from'];?>">
               </div>
			   <!--<span id="email_status"></span>-->
             </div>
             <div class="col-md-2 mb-3">
               <label for="validationPrimaryEmail">Shipment Name</label>
                <div class="input-group">
                <input type="text" class="form-control" name="shipment_name" id="validationPrimaryEmail" placeholder="Shipment Name" aria-describedby="inputGroupPrepend2" required="" value="<?php echo  $stock_in_data[0]['shipment_name'];?>">
               </div>
			   <!--<span id="email_status"></span>-->
             </div>
             
             <div class="col-md-2 mb-3">
              <label for="validationDefault02">Document</label><br>
              <input type='file' onchange="pressed(event,this)" style="color: transparent; width: 100px;" accept=".png, .jpg, .jpeg" name="image1" value="Choose file"><br>

              <span id="fileLabel1">Choose file</span>
            </div>
             
           </div>
           <?php }?>
            
            
            <table>
            <tbody>
                <tr>
                <td>
                <div class="form-row">
                    <div style="padding-top: 10px; padding-left:12px;"><input type="hidden" name="record" id="delete-row2" value="<?php echo  $stock_in_data[$i]['product_stock_details_id'];?>">
                    </div>
                    
                <div class="col col-md-3">
                  <label for="inputState">Product Name</label>
                  
                  <select name="exist_product_id" onchange="select_prod(this)" id="exist_product_id" class="form-control">
                      
                      <option selected value="<?php echo $stock_in_data[0]['product_id']; ?>"><?php echo  $stock_in_data[0]['product_name'];?></option>
                    
                      <?php if($product_master_list){foreach($product_master_list as $p_list){
                      ?>
                    <option value="<?php echo $p_list['product_id']; ?>"><?php echo  $p_list['product_name'];?></option>
                    <?php }}?>
                  </select>
                </div>
                
                <input type="hidden" id="product_stock_id" value="<?php echo  $stock_in_data[0]['product_stock_details_id'];?>" name="product_stock_id">
                
                <div class="col col-md-2">
                      <label for="inputState">Barcode</label>
                      <input type="text" class="form-control" name="prd_code" id="prd_code" value="<?php echo  $stock_in_data[0]['product_code'];?>" readonly placeholder="Product Barcode" required="">
                    </div>
                    
                    <div class="col col-md-2">
                      <label for="inputState">Product Type</label>
                      <input type="text" class="form-control" name="prd_type" id="prd_type" value="<?php echo  $stock_in_data[0]['product_type'];?>" readonly placeholder="Product Type" required="">
                    </div>
                    
                    <div class="col col-md-2">
                      <label for="inputState">Product Color</label>
                      <input type="text" class="form-control" name="prd_color" id="prd_color" value="<?php echo  $stock_in_data[0]['product_colr'];?>" readonly placeholder="Product Color" required="">
                    </div>
                
                <!--<div class="col col-md-2">-->
                <!--  <label for="inputState">Barcode No</label>-->
                <!--  <input type="text" class="form-control" name="exist_product_barcode_no" id="exist_product_barcode_no" required="" value="<?php echo  $stock_in_data[0]['product_barcode'];?>"<?php if(strtolower(substr($stock_in_data[0]['product_name'],0,4))!='iqos') echo "disabled = 'true' ";?>>-->
                <!--</div>-->
                
                <div class="col col-md-2">
                  <label for="validationDefault03">Product Quantity</label>
                  <input type="text" class="form-control" name="exist_product_quantity" id="quantity" required="" value="<?php echo  $stock_in_data[0]['product_quantity'];?>">
                </div>
                </div>
                </td>
            </tr>
            </tbody>
    </table>
            
        <table>
            <tbody>
            <?php if(sizeof($stock_in_data)>1){
                for($i=1;$i<(sizeof($stock_in_data));++$i){
                      ?>
            <tr>
                <td>
                    
                <div class="form-row">
                    <div style="padding-top: 10px;"><input type="checkbox" name="record" onclick="delete_prd(this)" id="delete-row1<?php echo  $stock_in_data[$i]['product_stock_details_id'];?>" value="<?php echo  $stock_in_data[$i]['product_stock_details_id'];?>">
                    </div>
                <div class="col col-md-3">
                  <select name="exist_product_id" onchange="select_prod(this)" id="exist_product_id" class="form-control">
                      <option selected value="<?php echo $stock_in_data[$i]['product_id']; ?>"><?php echo  $stock_in_data[$i]['product_name'];?></option>
                    
                      <?php if($product_master_list){foreach($product_master_list as $p_list){
                      ?>
                    <option value="<?php echo $p_list['product_id']; ?>"><?php echo  $p_list['product_name'];?></option>
                    <?php }}?>
                  </select>
                </div>
                
                <input type="hidden" id="product_stock_id" value="<?php echo  $stock_in_data[$i]['product_stock_details_id'];?>" name="product_stock_id">
                
                <div class="col col-md-2">
                      <input type="text" class="form-control" name="prd_code" id="prd_code" value="<?php echo  $stock_in_data[$i]['product_code'];?>" readonly placeholder="Product Barcode" required="">
                    </div>
                    
                    <div class="col col-md-2">
                      <input type="text" class="form-control" name="prd_type" id="prd_type" value="<?php echo  $stock_in_data[$i]['product_type'];?>" readonly placeholder="Product Type" required="">
                    </div>
                    
                    <div class="col col-md-2">
                      <input type="text" class="form-control" name="prd_color" id="prd_color" value="<?php echo  $stock_in_data[$i]['product_colr'];?>" readonly placeholder="Product Color" required="">
                    </div>
                
                <!--<div class="col col-md-2">-->
                <!--  <input type="text" class="form-control" name="exist_product_barcode_no" id="exist_product_barcode_no" required="" value="<?php echo  $stock_in_data[$i]['product_barcode'];?>" <?php if(strtolower(substr($stock_in_data[$i]['product_name'],0,4))!='iqos') echo "disabled = 'true' ";?>>-->
                <!--</div>-->
                
                <div class="col col-md-2">
                  <input type="text" class="form-control" name="exist_product_quantity" id="quantity" required="" value="<?php echo  $stock_in_data[$i]['product_quantity'];?>">
                </div>
                </div>
                
                </td>
            </tr>
            <?php }}?>
        </tbody>
    </table>

        <table>
            <tbody id="second_table">
			</tbody>
        </table>  
           
            <input type="hidden" name="all_stock_id" id="all_stock_id" value="">
            <input type="hidden" name="all_product_id" id="all_product_id" value="">
            <input type="hidden" name="all_product_quantity" id="all_product_quantity" value="">
		  
		    <input type="hidden" name="al-products" id="all-product" value="">
		    <input type="hidden" name="al-quantities" id="all-quantity" value="">
            <input type="hidden" value="<?php echo $order_id;?>" id="odr_id" name="all_order_id">
            
        
        <div class="btn-group" role="group" aria-label="Basic example">
		<input type="button" class="btn btn-secondary btn-lg my-2 pull-left" id="backk" value="Back" onclick="location.href='<?php echo base_url();?>index.php/Stock/stock_master'"/>
		
		<input type="button" class="btn btn-success  btn-lg my-2 pull-left" id="add-row" value="Add Row">
		
		<!--<button type="button" class="btn btn-success  btn-lg my-2 pull-left" id="delete-row">Delete Row</button>-->
		
		<input type="button" class="btn btn-success  btn-lg my-2 pull-left" id="auto_click" onclick="addAll();" value="Update"/>
		</div>
         <input type="hidden" id="TS" name="TS" value="<?php echo time();?>" />
        </form>
            
    </div>
</div>


<script type="text/javascript">
    $(document).ready(function(){
        $("#add-row").click(function(){
            var markup = `<tr>
                <td>
                <div class="form-row">
                <div style="padding-top: 10px;"><input type="checkbox" name="record" onclick="deletrow()"></div>
                <div class="col col-md-3">
                  <select name="product" id="product" onchange="select_prod(this)" class="form-control">
                  <option selected>Select option</option>
                       <?php if($product_master_list){foreach($product_master_list as $p_list){ ?> 
    
                    <option value="<?php echo $p_list['product_id']; ?>"> <?php echo  $p_list['product_name'];?> </option>
                     <?php }}?> 
                  </select>
                </div>
                
                <div class="col col-md-2">
                      <input type="text" class="form-control" name="prd_code" id="prd_code" readonly placeholder="Product Barcode" required="">
                    </div>
                    
                    <div class="col col-md-2">
                      <input type="text" class="form-control" name="prd_type" id="prd_type" readonly placeholder="Product Type" required="">
                    </div>
                    
                    <div class="col col-md-2">
                      <input type="text" class="form-control" name="prd_color" id="prd_color" readonly placeholder="Product Color" required="">
                    </div>
                
                
                <div class="col col-md-2">
                  <input type="text" class="form-control" name="quantity" id="quantity" placeholder="Quantity" required="">
                </div>
                </div>
                </td>
            </tr>`;
            $("#second_table").append(markup);
        });
        
        
        // $("#delete-row1").on('click',function(){
            console.log(this);
            // $("table tbody").find('input[name="record"]').each(function(){
            //     var product_stock_id=document.getElementById('delete-row1').value;
            //     console.log(product_stock_id);
            //     if(confirm(`Delete the Product ${product_stock_id}`)){
            //     delete_product(product_stock_id);
            // 	if($(this).is(":checked")){
            //         $(this).parents("tr").remove();
            //     }
            //     }else{
            //         document.getElementById('delete-row1').checked=false;
            //     }
            // });
        // });
        
    });
    </script>
<script>
    function deletrow(){
            $("table tbody").find('input[name="record"]').each(function(){
            	if($(this).is(":checked")){
                    $(this).parents("tr").remove();
                }
            });
    }

    function delete_product(prd_id){
        $.ajax({
                    url : "http://purpuligo.com/iqos/index.php/Stock/stock_product_delete",
                    method : "POST",
                    data : {prd_stock_id:prd_id},
                    async : true,
                    dataType : 'json',
                    success: function(data){
                        console.log(data);
                        if(data[0]['result'] == 1){
                            $("#error_message").show();
                        }
                    }
        });
    }
    function delete_prd(id){
        var stock_id= id.value;
        var p_id =id.id;
        if($(id).parents("tr").find('input[name="record"]')[0].checked == true){
                if(confirm(`Delete the Product ${stock_id}`)){
                    delete_product(stock_id);
                    $(id).parents("tr").remove();
                }
                else{
                    document.getElementById(p_id).checked=false;
                }
        }
    }
    $("#error_message").hide();
</script>
    
 <?php include_once('footer.php'); ?>         

              