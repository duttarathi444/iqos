<html>
    <head>
        <style>
  /*  table{*/
        /*border: 1px solid black;*/
  /*      width: 100%;*/
  /*      margin-bottom: 20px;*/
		/*border-collapse: separate;*/
        /*border-spacing: 20 0px;*/
  /*  }*/
  /*  table td{*/
  /*      padding: 2px;*/
  /*      text-align: left;*/
  /*  }*/
    </style>
    </head>
    
<?php include_once('header.php'); ?>
<body onload="putdate()">
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>

<script>
$(document).ready(function(){
  $('#CompanyPhone').mask('000-000-0000');
  $('#phone_no').mask('000-000-0000');
  $('#client_telephone1').mask('000-000-0000');
  $('#client_telephone2').mask('000-000-0000');
//   $('#message').hide();
});
</script>

<script  type="text/javascript" language="javascript" >
function addAll(){
        var products_id=document.getElementsByName("product_id");
        var return_date=document.getElementsByName("res_date");
        var p_quantity=document.getElementsByName("quantity");
        
        var c_email=document.getElementById("coach_email").value;
        var c_name=document.getElementById("coach_name").value;
        var c_phone=document.getElementById("phone_no").value;

var b=[];
var e=[];
var f=[];
var j=0;
for(var i=0;i<products_id.length;i++){
	
	var b1=products_id[i].value;
	var e1=return_date[i].value;
	var f1=p_quantity[i].value;
	if(b1 != '' && e1 != '' && f1 != ''){
	b[j]=b1;
	e[j]=e1;
	f[j]=f1
	j++;
	}else{
	    alert('Fill Up all the Details');
	    return false;
	}
}

document.getElementById("all-product").value=b;
document.getElementById("all-quantity").value=f;
document.getElementById("all-return_date").value=e;
if(c_email!='' && c_name!='' && c_phone!=''){
    document.forms['lend_add'].submit();
}else{
    alert('Fill Up all the Details');
	    return false;
}
}

function check_email(){
    var email=document.getElementById('coach_email').value;
    $.ajax({
  method: 'post',
  url: "http://purpuligo.com/iqos/index.php/Lending_Product/check_mail?a=<?php echo $secure_code; ?>",
  data: {email_id : email},
  dataType : 'json',
  success: function (response) {
    if(response[0].num > 0){
        document.getElementById('email_status').innerHTML="This Email id already Exist";
        return;
      }else{
        document.getElementById('email_status').innerHTML="";
        document.getElementById('auto_click').disabled=false;
      }
    }
  });
}

</script>

<div class="content">
  <div class="container">
      <a id="back2Top" title="Back to top" href="#">&#10148;</a>
    <h3 class="gold-underline">Product Lend</h3>
        
  <!--      <div class="alert alert-success alert-dismissible" id="message">-->
  <!--<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>-->
  <!--<center><p>Fill Up all the Details</p></center>-->
  <!--</div>-->

          <form name="lend_add" action="lending_add?a=<?php echo $secure_code; ?>" method="post" enctype="multipart/form-data">	
	    
	     <div class="form-row">
	         
              <div class="col-md-3 mb-3">
               <label for="validationPrimaryEmail">Select Lend Date</label>
                <div class="input-group">
                  <input type="date" class="form-control" id="lenddate" name="lenddate" required>
               </div>

             </div>
             <div class="col-md-3 mb-3">
               <label for="validationPrimaryEmail">Enter Coach email</label>
                <div class="input-group">
                  <input type="email" class="form-control" id="coach_email" placeholder="Enter Coach Email" name="coach_email" required>
               </div>
			   <span style="color:red" id="email_status"></span>
             </div>
          
              <div class="col-md-3 mb-3">
               <label for="validationPrimaryEmail">Coach Name</label>
                <div class="input-group">
                <input type="text" class="form-control" name="coach_name" id="coach_name" placeholder="Coach Name" aria-describedby="inputGroupPrepend2" required="">
               </div>

             </div>
             <div class="col-md-3 mb-3">
               <label for="validationPrimaryEmail">Coach Phone Number</label>
                <div class="input-group">
                <input type="text" class="form-control" name="phone_no" id="phone_no" placeholder="Coach Phone Number" aria-describedby="inputGroupPrepend2" required>
               </div>
			   <!--<span id="phone_status"></span>-->
             </div>
           </div>
           </div>
           <!--second stage-->
    <div>
        <div class="container">
              <h4>Enter Item Details Below </h4>
              
        <table style="width: 100%;">
            <tbody>
            <tr>
                
                <td style="text-align: center;padding-bottom: 25px;padding-left: 15px;"><input type="hidden" name="record"></td>
                
            <td>
            <div class="form-row">
             <div class="col-md-2 mb-3">
               <label for="validationPrimaryEmail">Product Name</label>
                <select name="product_id" id="prod_name" class="form-control" onchange="show(this)">
                    <option selected="">Select Product Name</option>
                    <?php if($product_list){foreach($product_list as $p_list){ ?>
                    <option value="<?php echo $p_list['product_id']; ?>"><?php echo  $p_list['product_name'];?></option>
                    <?php }}?>
                  </select>
             </div>
             
             <div class="col-md-2 mb-3">
               <label for="validationPrimaryEmail">Barcode</label>
                <div class="input-group">
                  <input type="type" class="form-control" id="serial_no" placeholder="Product Barcode" readonly value=""  name="serial_no">
               </div>
            </div>
            
            <div class="col-md-2 mb-3">
               <label for="validationPrimaryEmail">Product Type</label>
                <div class="input-group">
                  <input type="type" class="form-control" id="prd_type" placeholder="Product Type" readonly value=""  name="prd_type">
               </div>
            </div>
            
               <div class="col-md-2 mb-3">
               <label for="">Product Color</label>
                <div class="input-group">
                  <input type="text"  class="form-control" id="prod_color"  name="prod_color" readonly placeholder="Product Color" required>
               </div>
            </div>
            
            
              <div class="col-md-2 mb-3">
               <label for="">Quantity</label>
                <div class="input-group">
                  <input type="text" name="quantity" readonly class="form-control" onchange="check(this)" id="quantity" placeholder="Quantity" required>
               </div>
            </div>
            
            <input type="hidden" name="" id="totalStock">
            
             <div class="col-md-2 mb-3">
               <label for="">Expected Return Date</label>
                <div class="input-group">
                  <input type="date" readonly class="form-control" name="res_date" id="res_date"  required>
               </div>
               </div>
               </div>
               </td>
              </tr>
              </tbody>
            </table>
           
           <table style="width: 100%;">
               <tbody id="showTable">
   
                </tbody>
           </table>
           
        <input type="hidden" name="al-products" id="all-product" value="">
	    <input type="hidden" name="al-quantities" id="all-quantity" value="">
	    <input type="hidden" name="al-return_date" id="all-return_date" value="">
          
          
          
            
            <div class="btn-group" role="group" aria-label="Basic example">
		    <input type="button" class="btn btn-secondary btn-lg my-2 pull-left" id="backk" value="Back" onclick="location.href='<?php echo base_url();?>index.php/Lending_Product/lend_view?a=<?php echo $secure_code; ?>'"/>
		
		<input type="button" class="btn btn-success  btn-lg my-2 pull-left" id="add-row" value="Add Row">
		
		<button type="button" class="btn btn-success  btn-lg my-2 pull-left" id="delete-row">Delete Row</button>
		
		<input type="button" class="btn btn-success  btn-lg my-2 pull-left" id="auto_click" onclick="addAll()" value="Submit"/>
		
		</div>
		
        </form>
        
</div>
</div>
</div>

<script type="text/javascript">
    $(document).ready(function(){
        $("#add-row").click(function(){
            var markup = `<tr>
                <td style="text-align: center;padding-bottom: 25px;"><input type="checkbox" name="record"></td>
                <td>
                <div class="form-row">
                <div class="col-md-2 mb-3">
                  <select name="product_id" onchange="show(this)" id="product" class="form-control">
                  <option selected="">Select Product Name</option>
                       <?php if($product_list){foreach($product_list as $p_list){ ?>
                    <option value="<?php echo $p_list['product_id']; ?>"><?php echo  $p_list['product_name'];?></option>
                    <?php }}?>
                  </select>
                </div>
                
                <div class="col-md-2 mb-3">
                <div class="input-group">
                  <input type="type" class="form-control" id="serial_no" placeholder="Product Barcode" readonly name="serial_no">
                </div>
                </div>
                
                <div class="col-md-2 mb-3">
                <div class="input-group">
                  <input type="type" class="form-control" id="prd_type" placeholder="Product Type" readonly value=""  name="prd_type">
               </div>
            </div>
                
                <div class="col-md-2 mb-3">
                <div class="input-group">
                  <input type="text"  class="form-control" id="prod_color"  name="prod_color" readonly placeholder="Product Color" required="">
                </div>
                </div>
                
                <div class="col-md-2 mb-3">
                    <div class="input-group">
                  <input type="text" class="form-control" required name="quantity" id="quantity" readonly onchange="check(this)" placeholder="Quantity">
                  </div>
                </div>
                
                <input type="hidden" name="" id="totalStock">
                
                <div class="col-md-2 mb-3">
                <div class="input-group">
                  <input type="date" class="form-control" name="res_date" id="res_date" readonly required="">
               </div>
               </div>
            </div>
                        </td>
                    </tr>`;
            $("#showTable").append(markup);
        });
        
        // Find and remove selected table rows
        $("#delete-row").click(function(){
            $("table tbody").find('input[name="record"]').each(function(){
            	if($(this).is(":checked")){
                    $(this).parents("tr").remove();
                }
            });
        });
    });    

function show(id){
    var val1=id.options[id.selectedIndex].value;
    var thisorder = $(id).parents('tr');
    var tds = thisorder.find("td");
    var productdata=trdData(val1);
    var serial_no=tds.find('input[id="serial_no"]');
    var quan=tds.find('input[id="totalStock"]');
    var prd_color=tds.find('input[id="prod_color"]');
    var prd_type=tds.find('input[id="prd_type"]');
    var receive_date=tds.find('input[id="res_date"]');
    var quantity=tds.find('input[id="quantity"]');
    productdata
    .then(p=>{
        console.log(p);
        receive_date[0].readOnly=false;
        receive_date[0].value='';
        quantity[0].readOnly=false;
        quantity[0].value="";
        quantity[0].placeholder=`Available Amount ${p[0].customer_stock}`;
        quan[0].value=p[0].customer_stock;
        serial_no[0].value=p[0].product_code;
        prd_color[0].value=p[0].product_colr;
        prd_type[0].value=p[0].product_type;
        receive_date[0].value=dateput();
    })
}

 async function trdData(val1){
    const result = await $.ajax({
                    url : "http://purpuligo.com/iqos/index.php/Stock/all_product_list?a=<?php echo $secure_code; ?>",
                    method : "POST",
                    data : {cus_id: val1},
                    async : true,
                    dataType : 'json'
    });
    return result
}

function check(id){
    var quantity= id.value;
    var thisorder = $(id).parents('tr');
    var tds = thisorder.find("td");
    var qua=tds.find('input[id="totalStock"]')[0].value;
    if(+quantity > +qua || quantity < 1 || (/[!@#$%^&*(),.?":{}|<>]/g.test(quantity)==true)){
        id.value="";
    }
}

function dateput(){
    var datenow=new Date(Date.now());
    var month=+datenow.getMonth()+1;
    if((month+"").length<2){
        month='0'+month;
    }
    var date='';
    if((datenow.getDate()+"").length<2){
        date= '0'+datenow.getDate();
    }
    var newdate = datenow.getFullYear()+'-'+month+'-'+datenow.getDate();
    return newdate;
}

function putdate(){
    var newdate=dateput();
    document.getElementById('lenddate').value=newdate;
}

</script>
    
 <?php include_once('footer.php'); ?>         

              