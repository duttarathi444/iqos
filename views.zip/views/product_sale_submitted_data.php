<html>
    
<?php include_once('header.php'); ?>
<body>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>

<script>

$(document).ready(function(){
  $('#CompanyPhone').mask('000-000-0000');
  $('#CompanyFax').mask('000-000-0000');
  $('#client_telephone1').mask('000-000-0000');
  $('#client_telephone2').mask('000-000-0000');
});
</script>
    
<div class="content">

	
  <div class="container">
    <h2 class="gold-underline">Product Sale Data</h2>
    
    
     <?php 
		   if(!empty($product_list_by_id))
							
							{
								// foreach($stock_list as $driver){
						?>
        

          <form name="driver_add" action="driverdetails_update" method="post">
             <div class="gold-underline">
<table width="100%" cellspacing="5" cellpadding="5" border="0" bgcolor="E6B958" align="center">
   <tr bgcolor="#FFFFFF">
      <td>
         <table width="100%" cellspacing="0" cellpadding="0" border="0">
            <tr bgcolor="#FFFFFF">
               <td width="33%" height="40"><b>Sale Date</b></td>
               <td width="34%"><?php echo $product_list_by_id[0]['prd_sale_date'];?></td>
               <td></td>
            </tr>
            <tr bgcolor="#FFFFFF">
               <td height="40"><b>Customer Name</b></td>
               <td><?php echo $product_list_by_id[0]['f_name'].' '.$product_list_by_id[0]['l_name'];?></td>
               <td></td>
            </tr>
            <tr bgcolor="#FFFFFF">
               <td height="40"><b>Product Name</b></td>
               <td><?php echo $product_list_by_id[0]['product_name'];?></td>
               <td></td>
            </tr>
			 <tr bgcolor="#FFFFFF">
               <td width="33%" height="40"><b>Quantity</b></td>
               <td width="34%"><?php echo $product_list_by_id[0]['prd_quantity'];?></td>
               <td></td>
            </tr>
            <tr bgcolor="#FFFFFF">
               <td height="40"><b>Serial No</b></td>
               <td><?php echo $product_list_by_id[0]['serial_no'];?></td>
               <td></td>
            </tr>
            <tr bgcolor="#FFFFFF">
               <td height="40"><b>SAP Order No</b></td>
               <td><?php echo $product_list_by_id[0]['sap_order_no'];?></td>
               <td></td>
            </tr>
            
            <tr bgcolor="#FFFFFF">
               <td height="40"><b>Device Registation</b></td>
               <td><?php echo $product_list_by_id[0]['device_reg'];?></td>
               <td></td>
            </tr>
            
            <tr bgcolor="#FFFFFF">
               <td height="40"><b>Device Registation Date</b></td>
               <td><?php echo $product_list_by_id[0]['device_reg_date'];?></td>
               <td></td>
            </tr>
            
             <tr bgcolor="#FFFFFF">
               <td height="40"><b>PE1 Date</b></td>
               <td><?php echo $product_list_by_id[0]['pe1_date'];?></td>
               <td></td>
            </tr>
            <tr bgcolor="#FFFFFF">
               <td height="40"><b>PE1 Status</b></td>
               <td><?php echo $product_list_by_id[0]['pe1_status'];?></td>
               <td></td>
            </tr>
            
            <tr bgcolor="#FFFFFF">
               <td height="40"><b>PE2 Date</b></td>
               <td><?php echo $product_list_by_id[0]['pe2_date'];?></td>
               <td></td>
            </tr>
            
            <tr bgcolor="#FFFFFF">
               <td height="40"><b>PE2 Status</b></td>
               <td><?php echo $product_list_by_id[0]['pe2_status'];?></td>
               <td></td>
            </tr>
            
         </table>
      </td>
   </tr>
</table>
</div>  


               <input type="button" class="btn btn-secondary  btn-lg my-2 " id="agback" value="Back"  onclick="location.href='<?php echo base_url();?>index.php/Stock/stock_master'" />
               
                <input type="hidden" name="driver_id" value="<?php echo $driver_id;?>" />

        </form><?php } ?>
                
    </div>
</div>
 <?php include_once('footer.php'); ?>