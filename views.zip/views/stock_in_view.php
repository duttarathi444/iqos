<html>
    
<?php include_once('header.php'); ?>
<body>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>

<script>

$(document).ready(function(){
  $('#CompanyPhone').mask('000-000-0000');
  $('#CompanyFax').mask('000-000-0000');
  $('#client_telephone1').mask('000-000-0000');
  $('#client_telephone2').mask('000-000-0000');
});
</script>
    
<div class="content">

	
  <div class="container">
    <h3 class="gold-underline">Stock In Details</h3>
    
    
     <?php 
		   if(!empty($stock_in_data))
							
							{
								// foreach($product_list as $driver){
						?>
        

          <form name="driver_add" action="driverdetails_update" method="post">
             <div class="gold-underline">
<table width="50%" cellspacing="10" cellpadding="10" border="0" bgcolor="E6B958" align="center">
         <table width="30%" cellspacing="10" cellpadding="10" border="0">
            <tr bgcolor="#FFFFFF">
               <td width="1%" height="3"><b>Carton Number</b></td>
               <td width="1%"><?php echo substr($stock_in_data[0]['carton_no'],4);?></td>
            </tr>
            <tr bgcolor="#FFFFFF">
               <td height="40"><b>Received Date</b></td>
               <td><?php echo $stock_in_data[0]['received_date'];?></td>
            </tr>
            <tr bgcolor="#FFFFFF">
               <td height="2"><b>Received From</b></td>
               <td><?php echo $stock_in_data[0]['received_from'];?></td>
            </tr>
             <tr bgcolor="#FFFFFF">
               <td height="2"><b>Shipment Name</b></td>
               <td><?php echo $stock_in_data[0]['shipment_name'];?></td>
           <!-- <td style="padding-left: 20px;"><img style="width: 200px;" src="http://<?php echo $path?><?php echo $stock_in_data[0]['invoice_img']?>"></td>-->

            </tr>
            
           
            
         </table>
         
</table>
<style>
    div.absolute {
  position: absolute;
  top: 110px;
  right: 110px;
  width: 200px;
  height: 500px;
}
</style>
<div class="absolute">
<img style="width: 150px;" src="http://<?php echo $path?><?php echo $stock_in_data[0]['invoice_img']?>">
</div>

</div>  

        </form><?php } ?>
        
            <h3 class="gold-underline">Stock In Product Details</h3>
             <div class="gold-underline">

         <table width="100%" cellspacing="0" cellpadding="10" border="0">
             <thead>
                 
                <td><b>Product Name</b></td>
                
                <td><b>Barcode</b></td>
                
                <td><b>Product Type</b></td>
                
                <td><b>Product Color</b></td>
            
                <!--<td><b>Product Barcode</b></td>-->
            
                <td><b>Product Quantity</b></td>
            
            </thead>
            <tbody>
                <?php 
		   if(!empty($stock_in_data))
							
							{
								foreach($stock_in_data as $product_list){
						?>
                <tr>
                    <td><?php echo $product_list['product_name'];?></td>
                    <td><?php echo $product_list['product_code'];?></td>
                    <td><?php echo $product_list['product_type'];?></td>
                    <td><?php echo $product_list['product_colr'];?></td>
                    <!--<td><?php echo $product_list['product_barcode'];?></td>-->
                    <td><?php echo $product_list['product_quantity'];?></td>
                </tr>
                <?php }} ?>
            </tbody>
            
         </table>
         </div>
              
              <input type="button" class="btn btn-secondary  btn-lg my-2 " id="agback" value="Back"  onclick="location.href='<?php echo base_url();?>index.php/Stock/stock_master'" />
               
                <input type="hidden" name="driver_id" value="<?php echo $driver_id;?>" />
                
    </div>
</div>
 <?php include_once('footer.php'); ?> 