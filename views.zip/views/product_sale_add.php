<html>
    <head>
        <style>
    table{
        /*border: 1px solid black;*/
        width: 100%;
        margin-bottom: 20px;
		border-collapse: separate;
        /*border-spacing: 20 0px;*/
    }
    table td{
        padding: 2px;
        text-align: left;
    }
    #preview{
    width:500px;
    height: 500px;
    margin:0px auto;
    }
    
    body {font-family: Arial, Helvetica, sans-serif;}

#myImg {
  border-radius: 5px;
  cursor: pointer;
  transition: 0.3s;
}

#myImg:hover {opacity: 0.7;}

/* The Modal (background) */
.modal {
  display: none; /* Hidden by default */
  position: fixed; /* Stay in place */
  z-index: 1; /* Sit on top */
  padding-top: 100px; /* Location of the box */
  left: 0;
  top: 0;
  width: 100%; /* Full width */
  height: 100%; /* Full height */
  overflow: auto; /* Enable scroll if needed */
  background-color: rgb(0,0,0); /* Fallback color */
  background-color: rgba(0,0,0,0.9); /* Black w/ opacity */
}

/* Modal Content (image) */
.modal-content {
  margin: auto;
  display: block;
  width: 80%;
  max-width: 700px;
}

/* Caption of Modal Image */
#caption {
  margin: auto;
  display: block;
  width: 80%;
  max-width: 700px;
  text-align: center;
  color: #ccc;
  padding: 10px 0;
  height: 150px;
}

/* Add Animation */
.modal-content, #caption {  
  -webkit-animation-name: zoom;
  -webkit-animation-duration: 0.6s;
  animation-name: zoom;
  animation-duration: 0.6s;
}

@-webkit-keyframes zoom {
  from {-webkit-transform:scale(0)} 
  to {-webkit-transform:scale(1)}
}

@keyframes zoom {
  from {transform:scale(0)} 
  to {transform:scale(1)}
}

/* The Close Button */
.close {
  position: absolute;
  top: 15px;
  right: 35px;
  color: #f1f1f1;
  font-size: 40px;
  font-weight: bold;
  transition: 0.3s;
}

.close:hover,
.close:focus {
  color: #bbb;
  text-decoration: none;
  cursor: pointer;
}

/* 100% Image Width on Smaller Screens */
@media only screen and (max-width: 700px){
  .modal-content {
    width: 100%;
  }
}
    
    </style>
    </head>
    
<?php include_once('header.php'); ?>
<body onload="dateput()">
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>
<script src="https://cdn.rawgit.com/serratus/quaggaJS/0420d5e0/dist/quagga.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/webrtc-adapter/7.3.0/adapter.min.js"></script>
<script
  src="https://code.jquery.com/jquery-3.4.1.min.js"
  integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo="
  crossorigin="anonymous"></script>

<script>
$(document).ready(function(){
  $('#CompanyPhone').mask('000-000-0000');
  $('#CompanyFax').mask('000-000-0000');
  $('#client_telephone1').mask('000-000-0000');
  $('#quant').mask('0000000000');
});

function select_prod(num){
    if(num == 1){
        var e = document.getElementById('cus_email');
        var val = e.options[e.selectedIndex].value;
        var url = "http://purpuligo.com/iqos/index.php/Stock/all_customer";
    }else if(num == 2){
        var e = document.getElementById('prod_name');
        var val = e.options[e.selectedIndex].value;
        var url = "http://purpuligo.com/iqos/index.php/Stock/all_product_list";
    }
    $.ajax({
                    url : url,
                    method : "POST",
                    data : {cus_id: val},
                    async : true,
                    dataType : 'json',
                    success: function(data){
                        if(num == 1){
                        document.getElementById('cus_name').value = data[0].f_name+' '+data[0].l_name;
                        document.getElementById('cus_phone').value = data[0].ph_no;
                        document.getElementById('postal').value = data[0].postal_code;
                        if(Object.keys(data[0]).length > 4){
                            document.getElementById('god_father_name').value = data[0].p_f_name+' '+data[0].p_l_name;
                            document.getElementById('god_father_email').value = data[0].p_mail;
                            document.getElementById('god_father_phone').value = data[0].p_ph;
                        }else{
                            document.getElementById('god_father_name').value = '';
                            document.getElementById('god_father_email').value = '';
                            document.getElementById('god_father_phone').value = '';
                        }
                        }else if(num == 2){
                            document.getElementById('quant').readOnly=false;
                            document.getElementById('quanti').value=data[0].customer_stock;
                            
                            document.getElementById('quant').value="";
                            
                            document.getElementById('quant').placeholder=`${data[0].customer_stock}`;

                            document.getElementById('prod_color').value = data[0].product_colr;
                            document.getElementById('prod_type').value = data[0].product_type;
                            document.getElementById('prod_code').value = data[0].product_code;
                            var type=data[0].product_type.substring(0,4).toLowerCase();
                            if(type == 'iqos'){
                                document.getElementById('serial').disabled=false;
                            }else{
                                document.getElementById('serial').value="";
                                document.getElementById('serial').disabled=true;
                            }
                        }
                    },
                    error: function(err){
                        console.log(`${err} is here`);
                    }
                    });
}

function pe3date(){
    var s_date = document.getElementById('select_date').value;
    var date = new Date(s_date);
    var newdate = new Date(date);

    newdate.setDate(newdate.getDate() + 21);
    
    var dd = newdate.getDate()+'';
    var mm = newdate.getMonth() + 1+'';
    var y = newdate.getFullYear();
    var modi_mm='';
    var modi_dd='';
    if(mm.length < 2){
        modi_mm='0'+mm;
        if(dd.length < 2){
        modi_dd="0"+dd;
        var someFormattedDate = y + '-' + modi_mm + '-' + modi_dd;
        }else{
        var someFormattedDate = y + '-' + modi_mm + '-' + dd;
        }
    }else{
        if(dd.length < 2){
        modi_dd="0"+dd;
        var someFormattedDate = y + '-' + mm + '-' + modi_dd;
        }else{
        var someFormattedDate = y + '-' + mm + '-' + dd;
        }
    }
    document.getElementById('pe3_date').value = someFormattedDate;
}

function replacedate(id1){
    var s_date = document.getElementById('select_date').value;
    var date = new Date(s_date);
    var newdate = new Date(date);

    newdate.setDate(newdate.getDate() + 7);
    
    var dd = newdate.getDate()+'';
    var mm = newdate.getMonth() + 1+'';
    var y = newdate.getFullYear();
    var modi_mm='';
    var modi_dd='';
    if(mm.length < 2){
        modi_mm='0'+mm;
        if(dd.length < 2){
        modi_dd="0"+dd;
        var someFormattedDate = y + '-' + modi_mm + '-' + modi_dd;
        }else{
        var someFormattedDate = y + '-' + modi_mm + '-' + dd;
        }
    }else{
        if(dd.length < 2){
        modi_dd="0"+dd;
        var someFormattedDate = y + '-' + mm + '-' + modi_dd;
        }else{
        var someFormattedDate = y + '-' + mm + '-' + dd;
        }
    }
    document.getElementById('pe2_date').value = someFormattedDate;
    id1();
}

function saledate(id) {
    var s_date = document.getElementById('select_date').value;
    var date = new Date(s_date);
    var newdate = new Date(date);

    newdate.setDate(newdate.getDate() + 3);
    
    var dd = newdate.getDate()+'';
    var mm = newdate.getMonth() + 1+'';
    var y = newdate.getFullYear();
    var modi_mm='';
    var modi_dd='';
    if(mm.length < 2){
        modi_mm='0'+mm;
        if(dd.length < 2){
        modi_dd="0"+dd;
        var someFormattedDate = y + '-' + modi_mm + '-' + modi_dd;
        }else{
        var someFormattedDate = y + '-' + modi_mm + '-' + dd;
        }
    }else{
        if(dd.length < 2){
        modi_dd="0"+dd;
        var someFormattedDate = y + '-' + mm + '-' + modi_dd;
        }else{
        var someFormattedDate = y + '-' + mm + '-' + dd;
        }
    }
    document.getElementById('pe1_date').value = someFormattedDate;
    id(pe3date);
}

function checkQuantity(){
    var val=document.getElementById('quanti').value;
    var amount=document.getElementById('quant').value;
    if(val != -1){
        if(+amount > 0 && +amount<=(+val)){
            document.getElementById('auto_click').disabled=false;
        }else{
            document.getElementById('auto_click').disabled=true;
        }
    }
}

function dateput(){
    var datenow=new Date(Date.now());
    var month=+datenow.getMonth()+1;
    if((month+"").length<2){
        month='0'+month;
    }
    var date='';
    if((datenow.getDate()+"").length<2){
        date= '0'+datenow.getDate();
    }
    var newdate = datenow.getFullYear()+'-'+month+'-'+date;
    //var newdate = date+'-'+month+'-'+datenow.getFullYear();
    document.getElementById('select_date').value=newdate;
    saledate(replacedate);
}

function order_by_occurrence(arr) {
  var counts = {};
  arr.forEach(function(value){
      if(!counts[value]) {
          counts[value] = 0;
      }
      counts[value]++;
  });

  return Object.keys(counts).sort(function(curKey,nextKey) {
      return counts[curKey] < counts[nextKey];
  });
}

function scanner_on(id){
    id.value="";
    var modal = document.getElementById("myModal");
    modal.style.display = "block";
    var span = document.getElementsByClassName("close")[0];
    
    if ($('#scanner-container').length > 0 && navigator.mediaDevices && typeof navigator.mediaDevices.getUserMedia === 'function') {

    var last_result = [];

    if (Quagga.initialized == undefined) {
      Quagga.onDetected(function(result) {
          last_result.push(result.codeResult.code);
        if (last_result.length > 20) {
          code = order_by_occurrence(last_result)[0];
          last_result = [];
          id.value=code;
          Quagga.stop();
          modal.style.display = "none";
        }
      });
    }

    Quagga.init({
      inputStream : {
        name : "Live",
        type : "LiveStream",
        numOfWorkers: navigator.hardwareConcurrency,
        target: document.querySelector('#scanner-container')
      },
      decoder: {
          readers : ['ean_reader','ean_8_reader','code_39_reader','code_39_vin_reader','codabar_reader','upc_reader','upc_e_reader']
      }
    },function(err) {
        if (err) { console.log(err); return }
        Quagga.initialized = true;
        Quagga.start();
    });

  }
    
    span.onclick = function() {
        modal.style.display = "none";
        Quagga.stop();
    }
    
}

function add_all(){
    var a=[];
    var b=[];
    var prd_id=document.getElementsByName('prd_heet_id');
    var prd_quantity=document.getElementsByName('heet_quantity');
    for(var i=0;i<prd_id.length;i++){
        var prod_id=prd_id[i].value;
        var prod_quan=prd_quantity[i].value;
        if(prod_id!='' && prod_quan!=''){
            a.push(prod_id);
            b.push(prod_quan);
        }else{
            alert('Fill up all the details');
            return;
        }
    }
    if(a.length!=0){
        // console.log(a);
    // console.log(b);
        document.getElementById('product_ids').value=a;
        document.getElementById('product_quantitys').value=b;
        document.getElementById('sale_add').submit();
        // console.log('hi');
    }else{
        // document.getElementById('sale_add').submit();
        console.log('Rathin');
    }
}

</script>


<div id="myModal" class="modal">
    <span class="close">&times;</span>
<center><div id="scanner-container"></div></center>
<!--<div class="btn-group btn-group-toggle mb-5" data-toggle="buttons">-->
  <!--<center><label class="btn btn-primary active">-->
  <!--  <input type="radio" name="options" value="1" autocomplete="off" checked> Front Camera-->
  <!--</label></center>-->
  <!--<center><label class="btn btn-secondary">-->
  <!--  <input type="radio" name="options" value="2" autocomplete="off"> Back Camera-->
  <!--</label></center>-->
</div>
<!--</div>-->


<div class="content">
  <div class="container">
      <a id="back2Top" title="Back to top" href="#">&#10148;</a>
    <h3 class="gold-underline">Add Product Sale</h3>

          <form name="sale_add" id="sale_add" action="sale_information" method="post" enctype="multipart/form-data">
	        <div class="form-row">
              <div class="col-md-2 mb-3">
               <label for="validationPrimaryEmail">Sale Date</label>
                <div class="input-group">
                  <input type="date" class="form-control" onchange="saledate(replacedate)" id="select_date" name="select_date" required>
               </div>
			   
             </div>
             <div class="col-md-4 mb-3">
               <label for="validationPrimaryEmail">Customer Email</label>
                <select name="cus_email_id" required id="cus_email" required class="form-control" onchange=select_prod(1)>
                    <option selected="">Select Customer Email</option>
                    <?php if($customer_list){foreach($customer_list as $c_list){ ?>
                    <option value="<?php echo $c_list['sl_no']; ?>"><?php echo  $c_list['mail_id'];?></option>
                    <?php }}?>
                  </select>
             </div>
           </div>
           
           	<div class="form-row">
           	    
              <div class="col-md-4 mb-2">
               <label for="validationPrimaryEmail">Customer Name</label>
                <div class="input-group">
                <input type="text" class="form-control" id="cus_name" value="" name="customer_name" readonly placeholder="Customer Name" aria-describedby="inputGroupPrepend2">
               </div>
             </div>
             
             <div class="col-md-4 mb-2">
               <label for="validationPrimaryEmail">Customer Phone No</label>
                <div class="input-group">
                <input type="text" class="form-control" name="phone_no" value="" id="cus_phone" readonly placeholder="Phone No" aria-describedby="inputGroupPrepend2">
               </div>
             </div>
             
             <div class="col-md-4 mb-2">
               <label for="validationPrimaryEmail">Customer Postal Code</label>
                <div class="input-group">
                <input type="text" class="form-control" name="postal_code" value="" id="postal" readonly placeholder="Postal Code" aria-describedby="inputGroupPrepend2">
               </div>
             </div>
             
           </div>
           
           <div class="form-row">
           	    
              <div class="col-md-4 mb-2">
               <label for="validationPrimaryEmail">God Father Name</label>
                <div class="input-group">
                <input type="text" class="form-control" id="god_father_name" value="" name="customer_name" readonly aria-describedby="inputGroupPrepend2">
               </div>
             </div>
             
             <div class="col-md-4 mb-2">
               <label for="validationPrimaryEmail">God Father Email</label>
                <div class="input-group">
                <input type="text" class="form-control" name="phone_no" value="" id="god_father_email" readonly aria-describedby="inputGroupPrepend2">
               </div>
             </div>
             
             <div class="col-md-4 mb-2">
               <label for="validationPrimaryEmail">God Father Phone No</label>
                <div class="input-group">
                <input type="text" class="form-control" name="postal_code" value="" id="god_father_phone" readonly aria-describedby="inputGroupPrepend2">
               </div>
             </div>
             
           </div>
           
           
           <div class="form-row">
                
            <div class="col-md-2 mb-2">
               <label for="validationPrimaryEmail">SAP Order No</label>
                <div class="input-group">
                <input type="text" class="form-control" name="sap_no" id="sap_no" placeholder="SAP Order No" aria-describedby="inputGroupPrepend2">
               </div>
            </div>
                
             <div class="col-md-2 mb-3">
               <label for="validationPrimaryEmail">Device Registered</label>
                <select name="res_valid" required onchange="valid()" id="res_validation" class="form-control">
                    <option value=0 selected>Select Option</option>
                    <option value=1>Yes</option>
                    <option value=0>No</option>
                  </select>
             </div>
             
             <div class="col-md-2 mb-3">
               <label for="validationPrimaryEmail">Device Registered Date</label>
                <div class="input-group">
                  <input type="date" class="form-control" id="res_date" readonly name="registation_date" required>
               </div>
            </div>
           <!--</div>-->
           
           <!--<div class="form-row">-->
             <div class="col-md-2 mb-3">
               <label for="validationPrimaryEmail">PE1</label>
                <input type="date" class="form-control" id="pe1_date" readonly name="pe1_date">
             </div>
             
             <div class="col-md-2 mb-3">
               <label for="validationPrimaryEmail">PE2</label>
                <div class="input-group">
                  <input type="date" class="form-control" id="pe2_date" readonly name="pe2_date">
               </div>
            </div>
            
            <div class="col-md-2 mb-3">
               <label for="validationPrimaryEmail">Q+1 Conversion Date</label>
                <div class="input-group">
                  <input type="date" class="form-control" id="pe3_date" readonly name="pe3_date">
               </div>
            </div>
            
           </div>
           
           
           <div class="form-row">
			   
                <div class="col-md-3 mb-3">
                   <label for="validationPrimaryEmail">Device Name</label>
                    <select name="product_id" id="prod_name" class="form-control" onchange=select_prod(2)>
                        <option selected="">Select Device Name</option>
                        <?php if($device_list){foreach($device_list as $p_list){ ?>
                        <option value="<?php echo $p_list['product_id']; ?>"><?php echo  $p_list['product_name'];?></option>
                        <?php }}?>
                    </select>
                </div>
             
             <div class="col-md-2 mb-3">
               <label for="validationPrimaryEmail">Product Type</label>
                <div class="input-group">
                  <input type="type" class="form-control" id="prod_type" placeholder="Product Type" readonly name="prod_type">
               </div>
            </div>
             
             <div class="col-md-2 mb-3">
               <label for="validationPrimaryEmail">Barcode</label>
                <div class="input-group">
                  <input type="type" class="form-control" id="prod_code" placeholder="Product Barcode" readonly name="prod_code">
               </div>
            </div>
             
             <div class="col-md-2 mb-3">
               <label for="validationPrimaryEmail">Product Color</label>
                <div class="input-group">
                  <input type="type" class="form-control" id="prod_color" placeholder="Product Color" readonly name="product_color">
               </div>
            </div>
            
            <div class="col-md-2 mb-2">
               <label for="validationPrimaryEmail">Product Serial No</label>
                <div class="input-group">
                <input type="text" class="form-control" id="serial" name="serial_no" disabled placeholder="Serial No" aria-describedby="inputGroupPrepend2">
               </div>
             </div>
             
             <div class="col-md-1 mb-2">
               <label for="validationPrimaryEmail">Quantity</label>
                <div class="input-group">
                <input type="text" class="form-control" name="quantity" id="quant" onchange="checkQuantity()" readonly placeholder="Quantity" aria-describedby="inputGroupPrepend2">
               </div>
             </div>
             <input type="hidden" id="quanti" value="-1">
            
           </div>
            
            <hr style="border-color: black"></hr>
            
            <table style="width: 100%;">
            <tbody>
            <tr>
                
                <td style="text-align: center;padding-bottom: 25px;padding-left: 15px;"><input type="hidden" name="record"></td>
                
            <td>
            <div class="form-row">
             <div class="col-md-3 mb-3">
               <label for="validationPrimaryEmail">Heets Name</label>
                <select name="prd_heet_id" id="prd_heet_id" class="form-control" onchange=select_heets(this)>
                        <option value="0" selected="">Select Heets Name</option>
                        <?php if($heets_list){foreach($heets_list as $p_list){ ?>
                        <option value="<?php echo $p_list['product_id']; ?>"><?php echo  $p_list['product_name'];?></option>
                        <?php }}?>
                </select>
             </div>
             
             <div class="col-md-3 mb-3">
               <label for="validationPrimaryEmail">Barcode</label>
                <div class="input-group">
                  <input type="type" class="form-control" id="prd_heet_code" placeholder="Barcode" readonly name="prd_heet_code">
               </div>
            </div>
            
            <div class="col-md-3 mb-3">
               <label for="validationPrimaryEmail">Heets Type</label>
                <div class="input-group">
                  <input type="type" class="form-control" id="prd_heet_type" placeholder="Product Type" readonly value=""  name="prd_heet_type">
               </div>
            </div>
            
            <div class="col-md-2 mb-2">
               <label for="validationPrimaryEmail">Product Serial No</label>
                <div class="input-group">
                <input type="text" class="form-control" id="ser" name="se" disabled placeholder="Serial No" aria-describedby="inputGroupPrepend2">
               </div>
             </div>
            
              <div class="col-md-1 mb-2">
               <label for="validationPrimaryEmail">Quantity</label>
                <div class="input-group">
                <input type="text" class="form-control" name="heet_quantity" id="heet_quantity" readonly placeholder="Quantity" aria-describedby="inputGroupPrepend2">
               </div>
            </div>
             <input type="hidden" id="heetquanti" value="-1">
            
               </div>
               </td>
              </tr>
              </tbody>
            </table>
           
           <table style="width: 100%;">
               <tbody id="showTable">
   
                </tbody>
           </table>
            
            <input type="hidden" value="" name="product_ids" id="product_ids">
            <input type="hidden" value="" name="product_quantitys" id="product_quantitys">
          
            <div class="btn-group" role="group" aria-label="Basic example">
		    <input type="button" class="btn btn-secondary btn-lg my-2 pull-left" id="backk" value="Back" onclick="location.href='<?php echo base_url();?>index.php/Stock/product_sale'"/>
		
		    <input type="button" class="btn btn-success  btn-lg my-2 pull-left" id="add-row" value="Add Row">
    		
    		<button type="button" class="btn btn-success  btn-lg my-2 pull-left" id="delete-row">Delete Row</button>
		
		<input type="button" class="btn btn-success  btn-lg my-2 pull-left" onclick="add_all()" id="auto_click" disabled value="Submit"/>
		
		</div>
				<input type="hidden" id="TS" name="TS" value="<?php echo time();?>" />
        </form>
                
    </div>
</div>
<script>
    
    $(document).ready(function(){
        $("#add-row").click(function(){
            var markup = `<tr>
                <td style="text-align: center;padding-bottom: 40px;"><input type="checkbox" name="record"></td>
                <td>
                <div class="form-row">
                <div class="col-md-3 mb-3">
                <select name="prd_heet_id" id="prd_heet_id" class="form-control" onchange=select_heets(this)>
                        <option value="0" selected="">Select Heets Name</option>
                        <?php if($heets_list){foreach($heets_list as $p_list){ ?>
                        <option value="<?php echo $p_list['product_id']; ?>"><?php echo  $p_list['product_name'];?></option>
                        <?php }}?>
                </select>
             </div>
                
                <div class="col-md-3 mb-3">
                <div class="input-group">
                  <input type="type" class="form-control" id="prd_heet_code" placeholder="Barcode" readonly name="prd_heet_code">
               </div>
            </div>
                
                <div class="col-md-3 mb-3">
                <div class="input-group">
                  <input type="type" class="form-control" id="prd_heet_type" placeholder="Product Type" readonly value=""  name="prd_heet_type">
               </div>
            </div>
            
            <div class="col-md-2 mb-2">
                <div class="input-group">
                <input type="text" class="form-control" id="ser" name="se" disabled placeholder="Serial No" aria-describedby="inputGroupPrepend2">
               </div>
             </div>
                
            <div class="col-md-1 mb-2">
            <div class="input-group">
            <input type="text" class="form-control" name="heet_quantity" id="heet_quantity" readonly placeholder="Quantity" aria-describedby="inputGroupPrepend2">
            </div>
            </div>
                
                <input type="hidden" id="heetquanti" value="-1">
                
            </div>
                        </td>
                    </tr>`;
            $("#showTable").append(markup);
        });
        
        // Find and remove selected table rows
        $("#delete-row").click(function(){
            $("table tbody").find('input[name="record"]').each(function(){
            	if($(this).is(":checked")){
                    $(this).parents("tr").remove();
                }
            });
        });
    });
    
</script>
<script>
    function valid(){
    var e = document.getElementById('res_validation');
    var val = e.options[e.selectedIndex].value;
    if(val == 1)
    $('#res_date').removeAttr('readonly');
    else
    $('#res_date').attr('readonly', true);
    var e = document.getElementById('res_date').value='';
    }
    
    function select_heets(id){
        var val1= id.options[id.selectedIndex].value;
    var thisorder=$(id).parents('tr');
    var tds=thisorder.find('td');
    var bar=tds.find('input[id="prd_heet_code"]')[0];
    var prd_quanti=tds.find('input[id="heet_quantity"]')[0];
    var prd_type=tds.find('input[id="prd_heet_type"]')[0];
    var temp_quanti=tds.find('input[id="heetquanti"]')[0];
    
    if(val1==0){
        bar.value="";
        prd_type.value="";
        prd_quanti.readOnly=true;
        prd_quanti.value="";
        prd_quanti.placeholder="Quantity";
        return;
        }
    
    var productdata=trdData(val1);
    productdata
    .then(p=>{
        bar.value=p[0].product_code;
        prd_type.value=p[0].product_type;
        prd_quanti.readOnly=false;
        prd_quanti.placeholder=`${p[0].customer_stock}`;
        temp_quanti.value=p[0].customer_stock;
    })
    }
    
    async function trdData(val1){
    const result = await $.ajax({
                    url : "http://purpuligo.com/iqos/index.php/Stock/all_product_list",
                    method : "POST",
                    data : {cus_id: val1},
                    async : true,
                    dataType : 'json'
    });
    return result
}
</script>
    
 <?php include_once('footer.php'); ?>         

              