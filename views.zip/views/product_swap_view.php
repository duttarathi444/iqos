<html>
    
<?php include_once('header.php'); ?>
<body>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>

<script>

$(document).ready(function(){
  $('#CompanyPhone').mask('000-000-0000');
  $('#CompanyFax').mask('000-000-0000');
  $('#client_telephone1').mask('000-000-0000');
  $('#client_telephone2').mask('000-000-0000');
});
</script>
    
<div class="content">

	
  <div class="container">
    <h3 class="gold-underline">Product Swap Details</h3>
    
    
     <?php 
		   if(!empty($sale_products_data))
							
							{
						?>
        

          <form name="driver_add" action="driverdetails_update" method="post">
             <div class="gold-underline">
<table width="100%" cellspacing="10" cellpadding="6" border="0" bgcolor="E6B958" align="center">
   <tr bgcolor="#FFFFFF">
      <td>
         <table width="50%" cellspacing="10" cellpadding="6" border="0">
             
             <tr bgcolor="#FFFFFF">
               <td width="33%" height="40"><b>Sale Date</b></td>
               <td width="34%"><?php echo $sale_products_data[0]['prd_sale_date'];?></td>
                <td width="33%" height="40"><b>Quantity</b></td>
               <td width="34%"><?php echo $sale_products_data[0]['prd_quantity'];?></td>
                <td height="40"><b>PE1 Status</b></td>
               <td><?php echo $sale_products_data[0]['pe1_status'];?></td>
               <td></td>
               <td></td>
               <td></td>
            </tr>
            
            <tr bgcolor="#FFFFFF">
               <td width="33%" height="40"><b>Customer Name</b></td>
               <td width="34%"><?php echo $sale_products_data[0]['f_name'].' '.$sale_products_data['l_name'];?></td>
                <td height="40"><b>Serial No</b></td>
               <td><?php echo $sale_products_data[0]['serial_no'];?></td>
                <td height="40"><b>PE2 Date</b></td>
               <td><?php echo $sale_products_data[0]['pe2_date'];?></td>
               <td></td>
               <td></td>
               <td></td>
            </tr>
            
            <tr bgcolor="#FFFFFF">
               <td width="33%" height="40"><b>Product Name</b></td>
               <td width="34%"><?php echo $sale_products_data[0]['product_name'];?></td>
               <td height="40"><b>SAP Order No</b></td>
               <td><?php echo $sale_products_data[0]['sap_order_no'];?></td>
                <td height="40"><b>PE2 Status</b></td>
               <td><?php echo $sale_products_data[0]['pe2_status'];?></td>
               <td></td>
               <td></td>
               <td></td>
            </tr>
            
            <tr bgcolor="#FFFFFF">
               <td width="33%" height="40"><b>Product Type</b></td>
               <td width="34%"><?php echo $sale_products_data[0]['product_type'];?></td>
               <td height="40"><b>Device Registation</b></td>
               <td><?php echo ($sale_products_data[0]['device_reg']==1)? 'Yes':'No';?></td>
                <td height="40"><b>Q+1 Conversion Date</b></td>
               <td><?php echo $sale_products_data[0]['pe3_date'];?></td>
               <td></td>
               <td></td>
               <td></td>
            </tr>
            
            <tr bgcolor="#FFFFFF">
               <td width="33%" height="40"><b>Product Color</b></td>
               <td width="34%"><?php echo $sale_products_data[0]['product_colr'];?></td>
               <td height="40"><b>Device Registation Date</b></td>
               <td><?php echo $sale_products_data[0]['device_reg_date'];?></td>
                <td height="40"><b>Q+1 Conversion Status</b></td>
               <td><?php echo $sale_products_data[0]['pe3_status'];?></td>
               <td></td>
               <td></td>
               <td></td>
            </tr>
            
            <tr bgcolor="#FFFFFF">
               <td width="33%" height="40"><b>Product Barcode</b></td>
               <td width="34%"><?php echo $sale_products_data[0]['product_code'];?></td>
               <td height="40"><b>PE1 Date</b></td>
               <td><?php echo $sale_products_data[0]['pe1_date'];?></td>
               <td></td>
               <td></td>
            </tr>
            
         
         </table>
      </td>
   </tr>
</table>
</form><?php } ?>
<div class="gold-underline"></div>
<table cellspacing="20">
<thead>
    <tr>
        <td width="10%"><b>Swap Date</b></td>
        
        <td width="10%"><b>Product Name</b></td>
		
		<td width="10%"><b>Product Color</b></td>
		
		<td width="10%"><b>Product Type</b></td>
		
		<td width="10%"><b>Product Barcode</b></td>
		
		<td width="10%"><b>Registation Date</b></td>
		
		<td width="10%"><b>New Serial No</b></td>
		
		<td width="10%"><b>Glove Service No</b></td>
		
    </tr>
</thead>
<tbody>
<?php 
		   if(!empty($swap_list))
							
							{
								foreach($swap_list as $swap_sdata){
						?>
						
						    <tr>
						        
				    <td width="10%" height="50"><?php echo $swap_sdata['swap_date'];?></td>
						        
						<td width="10%"><?php echo $swap_sdata['product_name'];?></td>
						
						<td width="10%"><?php echo $swap_sdata['product_colr'];?></td>
						
						<td width="10%"><?php echo $swap_sdata['product_type'];?></td>
						
						<td width="10%"><?php echo $swap_sdata['product_code'];?></td>
						
						<td width="10%"><?php echo $swap_sdata['date'];?></td>
						
						<td width="10%"><?php echo $swap_sdata['new_serial_number'];?></td>
						
						<td width="10%"><?php echo $swap_sdata['wgs_no'];?></td>
						
						</tr>
						
						<?php }?>
						<?php }?>
</tbody>
						</table>
</div>  
               
                
                <input type="button" class="btn btn-secondary  btn-lg my-2 " id="agback" value="Back"  onclick="location.href='<?php echo base_url();?>index.php/Stock/product_replace'" />
                
    </div>
</div>
 <?php include_once('footer.php'); ?>         

              