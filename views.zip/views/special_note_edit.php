<html>
    
<?php include_once('header.php'); ?>
<body onload="putdate()">
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>

<script>

$(document).ready(function(){
  $('#g_s_ph_no').mask('000-000-0000');
  $('#g_f_ph_no').mask('000-000-0000');
 
});
  function select_prod(num){
    if(num == 1){
        var e = document.getElementById('cus_email');
        var val = e.options[e.selectedIndex].value;
		console.log(val);
        var url = "http://purpuligo.com/iqos/index.php/Stock/all_customer";
    }else if(num == 2){
        var e = document.getElementById('prod_name');
        var val = e.options[e.selectedIndex].value;
        var url = "http://purpuligo.com/iqos/index.php/Stock/all_product_list";
    }
	else if(num == 3){
        var e = document.getElementById('prod_name2');
        var val = e.options[e.selectedIndex].value;
        var url = "http://purpuligo.com/iqos/index.php/Stock/all_product_list";
    }
	else if(num == 4){
        var e = document.getElementById('prod_name3');
        var val = e.options[e.selectedIndex].value;
        var url = "http://purpuligo.com/iqos/index.php/Stock/all_product_list";
    }
	else if(num == 5){
        var e = document.getElementById('prod_name4');
        var val = e.options[e.selectedIndex].value;
        var url = "http://purpuligo.com/iqos/index.php/Stock/all_product_list";
    }
	else if(num == 6){
        var e = document.getElementById('prod_name5');
        var val = e.options[e.selectedIndex].value;
        var url = "http://purpuligo.com/iqos/index.php/Stock/all_product_list";
    }
	
    $.ajax({
                    url : url,
                    method : "POST",
                    data : {cus_id: val},
                    async : true,
                    dataType : 'json',
                    success: function(data){
                        if(num == 1){
                        document.getElementById('cus_name').value = data[0].f_name+' '+data[0].l_name;
                        document.getElementById('cus_phone').value = data[0].ph_no;
                        document.getElementById('postal').value = data[0].postal_code;
                        if(Object.keys(data[0]).length > 4){
                            document.getElementById('god_father_name').value = data[0].p_f_name+' '+data[0].p_l_name;
                            document.getElementById('god_father_email').value = data[0].p_mail;
                            document.getElementById('god_father_phone').value = data[0].p_ph;
                        }else{
                            document.getElementById('god_father_name').value = '';
                            document.getElementById('god_father_email').value = '';
                            document.getElementById('god_father_phone').value = '';
                        }
                        }else if(num == 2){
                            //document.getElementById('quant').readOnly=false;
                            //document.getElementById('quanti').value=data[0].customer_stock;
                            
                           // document.getElementById('quant').placeholder=`Current Stock ${data[0].customer_stock}`;

                            //document.getElementById('prod_color').value = data[0].product_colr;
                            document.getElementById('prod_type').value = data[0].product_type;
                           // document.getElementById('prod_code').value = data[0].product_code;
                           // var type=data[0].product_type.substring(0,4).toLowerCase();
                           // if(type == 'iqos'){
                               // document.getElementById('serial').disabled=false;
                           // }else{
                                //document.getElementById('serial').value="";
                                //document.getElementById('serial').disabled=true;
                            //}
                        }
						else if(num == 3){
                            //document.getElementById('quant').readOnly=false;
                            //document.getElementById('quanti').value=data[0].customer_stock;
                            
                           // document.getElementById('quant').placeholder=`Current Stock ${data[0].customer_stock}`;

                            //document.getElementById('prod_color').value = data[0].product_colr;
                            document.getElementById('prod_type2').value = data[0].product_type;
                           // document.getElementById('prod_code').value = data[0].product_code;
                           // var type=data[0].product_type.substring(0,4).toLowerCase();
                           // if(type == 'iqos'){
                                //document.getElementById('serial').disabled=false;
                           // }else{
                                //document.getElementById('serial').value="";
                                //document.getElementById('serial').disabled=true;
                            //}
                        }
						else if(num == 4){
                            //document.getElementById('quant').readOnly=false;
                            //document.getElementById('quanti').value=data[0].customer_stock;
                            
                           // document.getElementById('quant').placeholder=`Current Stock ${data[0].customer_stock}`;

                            //document.getElementById('prod_color').value = data[0].product_colr;
                            document.getElementById('prod_type3').value = data[0].product_type;
                           // document.getElementById('prod_code').value = data[0].product_code;
                           // var type=data[0].product_type.substring(0,4).toLowerCase();
                           // if(type == 'iqos'){
                               // document.getElementById('serial').disabled=false;
                           // }else{
                                //document.getElementById('serial').value="";
                                //document.getElementById('serial').disabled=true;
                            //}
                        }
						else if(num == 5){
                            //document.getElementById('quant').readOnly=false;
                            //document.getElementById('quanti').value=data[0].customer_stock;
                            
                           // document.getElementById('quant').placeholder=`Current Stock ${data[0].customer_stock}`;

                            //document.getElementById('prod_color').value = data[0].product_colr;
                            document.getElementById('prod_type4').value = data[0].product_type;
                           // document.getElementById('prod_code').value = data[0].product_code;
                           // var type=data[0].product_type.substring(0,4).toLowerCase();
                           // if(type == 'iqos'){
                               // document.getElementById('serial').disabled=false;
                           // }else{
                                //document.getElementById('serial').value="";
                                //document.getElementById('serial').disabled=true;
                            //}
                        }
						else if(num == 6){
                            //document.getElementById('quant').readOnly=false;
                            //document.getElementById('quanti').value=data[0].customer_stock;
                            
                           // document.getElementById('quant').placeholder=`Current Stock ${data[0].customer_stock}`;

                            //document.getElementById('prod_color').value = data[0].product_colr;
                            document.getElementById('prod_type5').value = data[0].product_type;
                           // document.getElementById('prod_code').value = data[0].product_code;
                           // var type=data[0].product_type.substring(0,4).toLowerCase();
                           // if(type == 'iqos'){
                               // document.getElementById('serial').disabled=false;
                           // }else{
                                //document.getElementById('serial').value="";
                                //document.getElementById('serial').disabled=true;
                            //}
                        }
                    },
                    error: function(err){
                        console.log(`${err} is here`);
                    }
                    });
}
 
</script>

<!--<script>

$(document).ready(function(){
  $('#CompanyPhone').mask('000-000-0000');
  $('#CompanyFax').mask('000-000-0000');
  $('#client_telephone').mask('0000000000');
  $('#client_telephone2').mask('000-000-0000');
});

function check_date(){
    var dob_date = document.getElementById('dob').value;
    var pre_date = new Date(dob_date);
    var previ_date = pre_date.getFullYear();
    var current_date =new Date(Date.now());
    var current_year = current_date.getFullYear();
    if((current_year-previ_date)>=18){
        document.getElementById('auto_click').disabled= false;
        document.getElementById('dob_message').innerHTML="";
    }else{
       document.getElementById('dob_message').innerHTML="You Are Not +18";
    }
}//


$(document).ready(function(){
  $('#phone_num').mask('000-000-0000');
});
</script>//-->

<script>
function putdate(){
    var aext=document.getElementById('textar').value;
    document.getElementById('p_remark').value=aext;
	var aext=document.getElementById('textar2').value;
    document.getElementById('p_note').value=aext;
}
</script>
    
<div class="content">

	
  <div class="container">
      <a id="back2Top" title="Back to top" href="#">&#10148;</a>
    <h3 class="gold-underline">Special Note Edit</h3>
        
		 <?php 
		   if(!empty($note_list))
							
							{
								foreach($note_list as $note){
						?>
        

       <form name="driver_add"  action="special_note_update?a=<?php echo $secure_code; ?>" method="post" >	
	   
	   <input type="hidden" id="textar" value="<?php echo $note['remarks']?>">
	   <input type="hidden" id="textar2" value="<?php echo $note['special_note']?>">
             	  
		<div class="form-row">
					
						<div class="col-md-3 mb-3">
							<label for="validationDefault01">REGISTRATION DATE</label>
							<div class="input-group">
								<input type="date" class="form-control" id="validationDefault01" placeholder="Enter Date"value="<?php echo $note['reg_date'];?>" name="reg_date" required style="">
							</div>
						</div>
						
						<div class="col-md-3 mb-3">
							<label for="validationDefault01">TRANSACTION DATE</label>
								<div class="input-group">
									<input type="date" class="form-control" id="validationDefault01" placeholder="Enter Date" value="<?php echo $note['transaction_date'];?>" name="tr_date" required style="">
								</div>
						</div>
						
		</div>

		<div class="form-row">

						<div class="col-md-3 mb-3">
							<label for="validationDefault01">UNDER GOD FATHER EMAIL</label>
							<div class="input-group">
								<input type="email" class="form-control" id="god_father_email" readonly placeholder="Email Address" value="<?php echo $note['u_g_father_email'];?>" onchange="fun(1)" name="u_g_f_email" required>
							</div>
							<span style="color:red" id="email_message"></span>
						</div>

						<div class="col-md-3 mb-3">
							<label for="validationDefault01">GOD FATHER NAME</label>
							<div class="input-group">
								<input type="text" class="form-control" id="god_father_name" readonly placeholder="Enter God Father Name" value="<?php echo $note['g_father_name'];?>" onchange="fun(2)" name="g_f_nm"   required>
							</div>
							<span style="color:red" id="phone_message"></span>
						</div>
						
						<div class="col-md-3 mb-3">
							<label for="validationDefault01">GOD FATHER PHONE</label>
								<div class="input-group">
									<input type="text" class="form-control" id="god_father_phone" readonly placeholder="Enter God Father Phone no" value="<?php echo $note['g_father_ph_no'];?>" name="g_f_ph_no" required style="">
								</div>
						</div>
						
		</div>


		<div class="form-row">
			
			<div class="col-md-3 mb-3">
							<label for="validationDefault01">GOD SON EMAIL</label>
								
									<!--<input type="email" class="form-control" id="validationDefault01" placeholder="Enter Email" value="<?php echo $note['g_son_email'];?>" name="g_s_email" required style="">//-->
						<select name="g_s_email" id="cus_email" class="form-control" onchange=select_prod(1)>
							
							<option selected value="<?php echo  $note['sl_no'];?>"><?php echo  $note['mail_id'];?></option>
							<?php if($customer_list){foreach($customer_list as $c_list){ ?>
							<option value="<?php echo $c_list['sl_no']; ?>"><?php echo  $c_list['mail_id'];?></option>
							<?php }}?>
						  </select>
								
						</div>
						
						<div class="col-md-3 mb-3">
							<label for="validationDefault01">GOD SON NAME	</label>
							<div class="input-group">
								<input type="text" class="form-control" id="cus_name" readonly placeholder="Enter God Son Name" value="<?php echo $note['g_son_name'];?>" name="g_s_nm" required>
							</div>
							
						</div>
						
						<div class="col-md-2 mb-3">
							<label for="validationDefault01">GOD SON PHONE</label>
							<div class="input-group">
								<input type="text" class="form-control" id="cus_phone" readonly placeholder="Enter God Son Phone no" value="<?php echo $note['g_son_ph_no'];?>" name="g_s_ph_no" required style="">
							</div>
						</div>
						
						<div class="col-md-2 mb-3">
							<label for="validationDefault01">GOD SON DOB</label>
							<div class="input-group">
								<input type="date" class="form-control" id="validationDefault01" placeholder="God Son DOB" value="<?php echo $note['g_son_dob'];?>" name="g_son_dob" required style="">
							</div>
						</div>
						
						<div class="col-md-2 mb-3">
							<label for="validationDefault01">GOD SON POSTAL CODE</label>
							<div class="input-group">
								<input type="text" class="form-control" id="postal" readonly placeholder="Enter Postal Code"  value="<?php echo $note['g_son_postal_code'];?>" name="g_s_postal_code" required>
							</div>
							
						</div>



		</div>


		<div class="form-row">

						<div class="col-md-5 mb-3">
							<label for="validationDefault01">FOR WHOM</label>
								<div class="input-group">
									<input type="text" class="form-control" id="validationDefault01" placeholder="Enter For Whom" value="<?php echo $note['for_whom'];?>" name="f_whome" required style="">
								</div>
						</div>

		</div>

		<div class="form-row">
				
				<div class="col-md-4 mb-3">
							<label for="validationDefault01">PRODUCT BOUGHT 1</label>
							<!--<div class="input-group">
								<input type="text" class="form-control" id="phone_num" placeholder="PRODUCT BOUGHT 1" onchange="fun(2)" value="<?php echo $note['p_bought_1'];?>" name="p_bougt_1"   required>
							</div>//-->
							
						<select name="p_bougt_1" id="prod_name" class="form-control" onchange=select_prod(2)>
                          <?php 
                               
							   
                                    if($product_list)
                                {
                                    foreach($product_list as $p_list)
                                     {
										foreach($note_list as $note)
                                     { 
                                                   
								    if($p_list['product_id'] == $note['p_bought_1'])  
                                
                                { 
                            ?>
						
						
					
                          <option selected value="<?php echo  $p_list['product_id'];?>"><?php echo  $p_list['product_name'];?></option>
                          <?php 
						  }
                        else
                        { 
						?>
        
                        <option value="<?php echo $p_list['product_id']; ?>"><?php echo  $p_list['product_name'];?></option>
								<?php }}}}?>
                      </select>
							
						</div>
						
						<div class="col-md-4 mb-3">
							<label for="validationDefault01">PRODUCT TYPE1</label>
							<div class="input-group">
								<input type="text" class="form-control" id="prod_type" readonly placeholder="PRODUCT TYPE1"  value="<?php echo $note['p_type_1'];?>" onchange="fun(2)" name="p_type1"   required>
							</div>
							
						</div>
						
						<div class="col-md-4 mb-3">
							<label for="validationDefault01">PRODUCT SERIAL1</label>
							<div class="input-group">
								<input type="text" class="form-control" id="validationDefault01" placeholder="PRODUCT SERIAL1" value="<?php echo $note['p_serial_1'];?>" name="p_serial1" required style="">
							</div>
						</div>
		</div>


		<div class="form-row">
						<div class="col-md-4 mb-3">
							<label for="validationDefault01">PRODUCT BOUGHT 2</label>
							<!--<div class="input-group">
								<input type="text" class="form-control" id="dob_b" placeholder="PRODUCT BOUGHT 2" value="<?php echo $note['p_bought_2'];?>" name="p_bougt_2" required onchange="">
							</div>//-->
							
						<select name="p_bougt_2" id="prod_name2" class="form-control" onchange=select_prod(3)>
                         <?php 
                               
							   
                                    if($product_list)
                                {
                                    foreach($product_list as $p_list)
                                     {
										foreach($note_list as $note)
                                     { 
                                                   
								    if($p_list['product_id'] == $note['p_bought_2'])  
                                
                                { 
                            ?>
						
						
					
                          <option selected value="<?php echo  $p_list['product_id'];?>"><?php echo  $p_list['product_name'];?></option>
                          <?php 
						  }
                        else
                        { 
						?>
        
                        <option value="<?php echo $p_list['product_id']; ?>"><?php echo  $p_list['product_name'];?></option>
								<?php }}}}?>
                      </select>
							
							
						</div>
						<div class="col-md-4 mb-3">
							<label for="validationDefault01">PRODUCT TYPE2</label>
							<div class="input-group">
								<input type="text" class="form-control" id="prod_type2" readonly placeholder="PRODUCT TYPE2" value="<?php echo $note['p_type_2'];?>" name="p_type2" required style="">
							</div>
						</div>
						
						<div class="col-md-4 mb-3">
							<label for="validationDefault01">PRODUCT SERIAL2</label>
								<div class="input-group">
									<input type="text" class="form-control" id="validationDefault01" placeholder="PRODUCT SERIAL2" value="<?php echo $note['p_serial_2'];?>" name="p_serial2" required style="">
								</div>
						</div>


		</div>


		<div class="form-row">
				
				<div class="col-md-4 mb-3">
							<label for="validationDefault01">PRODUCT BOUGHT 3</label>
							<!--<div class="input-group">
								<input type="text" class="form-control" id="validationDefault01" placeholder="PRODUCT BOUGHT 3" value="<?php echo $note['p_bought_3'];?>" name="p_bougt_3" required style="" maxlength="6">
							</div>//-->
						<select name="p_bougt_3" id="prod_name3" class="form-control" onchange=select_prod(4)>
                          <?php 
                               
							   
                                    if($product_list)
                                {
                                    foreach($product_list as $p_list)
                                     {
										foreach($note_list as $note)
                                     { 
                                                   
								    if($p_list['product_id'] == $note['p_bought_3'])  
                                
                                { 
                            ?>
						
						
					
                          <option selected value="<?php echo  $p_list['product_id'];?>"><?php echo  $p_list['product_name'];?></option>
                          <?php 
						  }
                        else
                        { 
						?>
        
                        <option value="<?php echo $p_list['product_id']; ?>"><?php echo  $p_list['product_name'];?></option>
								<?php }}}}?>
                      </select>
							
							
							
						</div>
						
						<div class="col-md-4 mb-3">
							<label for="validationDefault01">PRODUCT TYPE3</label>
								<div class="input-group">
									<input type="text" class="form-control"  id="prod_type3" readonly placeholder="PRODUCT TYPE" value="<?php echo $note['p_type_3'];?>" name="p_type3" required style="">
								</div>
						</div>
						
						<div class="col-md-4 mb-3">
							<label for="validationDefault01">PRODUCT SERIAL3</label>
							<div class="input-group">
								<input type="text" class="form-control" id="phone_num" placeholder="PRODUCT SERIAL3" value="<?php echo $note['p_serial_3'];?>" onchange="fun(2)" name="p_serial3"   required>
							</div>
							
						</div>


		</div>

		<div class="form-row">
					
					<div class="col-md-4 mb-3">
							<label for="validationDefault01">PRODUCT BOUGHT 4</label>
							<!--<div class="input-group">
								<input type="text" class="form-control" id="validationDefault01" placeholder="PRODUCT BOUGHT 4" value="<?php echo $note['p_bought_4'];?>" name="p_bougt_4" required style="">
							</div>//-->
							
						<select name="p_bougt_4" id="prod_name4" class="form-control" onchange=select_prod(5)>
                          <?php 
                               
							   
                                    if($product_list)
                                {
                                    foreach($product_list as $p_list)
                                     {
										foreach($note_list as $note)
                                     { 
                                                   
								    if($p_list['product_id'] == $note['p_bought_4'])  
                                
                                { 
                            ?>
						
						
					
                          <option selected value="<?php echo  $p_list['product_id'];?>"><?php echo  $p_list['product_name'];?></option>
                          <?php 
						  }
                        else
                        { 
						?>
        
                        <option value="<?php echo $p_list['product_id']; ?>"><?php echo  $p_list['product_name'];?></option>
								<?php }}}}?>
                      </select>
							
						</div>
						
						<div class="col-md-4 mb-3">
							<label for="validationDefault01">PRODUCT TYPE4</label>
							<div class="input-group">
								<input type="text" class="form-control" id="prod_type4" readonly placeholder="PRODUCT TYPE4" value="<?php echo $note['p_type_4'];?>" onchange="fun(1)" name="p_type4" required>
							</div>
							
						</div>
						
						<div class="col-md-4 mb-3">
							<label for="validationDefault01">PRODUCT SERIAL4</label>
							<div class="input-group">
								<input type="text" class="form-control" id="validationDefault01" placeholder="PRODUCT SERIAL4" value="<?php echo $note['p_serial_4'];?>" name="p_serial4" required style="">
							</div>
						</div>


		</div>

<div class="form-row">

				<div class="col-md-4 mb-3">
					<label for="validationDefault01">PRODUCT BOUGHT 5</label>
						<!--<div class="input-group">
							<input type="text" class="form-control" id="validationDefault01" placeholder="PRODUCT BOUGHT 5" value="<?php echo $note['p_bought_5'];?>" name="p_bougt_5" required style="">
						</div>//-->
						<select name="p_bougt_5" id="prod_name5" class="form-control" onchange=select_prod(6)>
						<?php 
                               
							   
                                    if($product_list)
                                {
                                    foreach($product_list as $p_list)
                                     {
										foreach($note_list as $note)
                                     { 
                                                   
								    if($p_list['product_id'] == $note['p_bought_5'])  
                                
                                { 
                            ?>
						
						
					
                          <option selected value="<?php echo  $p_list['product_id'];?>"><?php echo  $p_list['product_name'];?></option>
                          <?php 
						  }
                        else
                        { 
						?>
        
                        <option value="<?php echo $p_list['product_id']; ?>"><?php echo  $p_list['product_name'];?></option>
								<?php }}}}?>
                      </select>
						
				</div>
				
				<div class="col-md-4 mb-3">
					<label for="validationDefault01">PRODUCT TYPE5</label>
					<div class="input-group">
						<input type="text" class="form-control" id="prod_type5" readonly placeholder="PRODUCT TYPE5" value="<?php echo $note['p_type_5'];?>"  name="p_type5"   required>
					</div>
					
				</div>
				
				<div class="col-md-4 mb-3">
					<label for="validationDefault01">PRODUCT SERIAL5</label>
						<div class="input-group">
							<input type="text" class="form-control" id="validationDefault01" placeholder="PRODUCT SERIAL2" value="<?php echo $note['p_serial_5'];?>" name="p_serial5" required style="">
						</div>
				</div>


</div>


<div class="form-row">
			
			<div class="col-md-4 mb-3">
					<label for="validationDefault01">GOD FATHER 75$ RECEIVED</label>
					<div class="input-group">
						<input type="text" class="form-control" id="client_email" placeholder="God Father 75$ Received" value="<?php echo $note['g_father_75_received'];?>" onchange="fun(1)" name="g_f_75_rec" required>
					</div>
					
				</div>
				
				<div class="col-md-4 mb-3">
					<label for="validationDefault01">75$ RECEIVED DATE</label>
					<div class="input-group">
						<input type="date" class="form-control" id="validationDefault01" placeholder="Enter 75$ Received Date" value="<?php echo $note['75_received_date'];?>" name="p_75rec_date" required style="">
					</div>
				</div>
				
				<div class="col-md-4 mb-3">
					<label for="validationDefault01">DEPOSITED TO</label>
					<div class="input-group">
						<input type="text" class="form-control" id="validationDefault01" placeholder="Deposited To" value="<?php echo $note['deposited_1'];?>" name="deposit1" required style="">
				</div>
				</div>



</div>

<div class="form-row">

		<div class="col-md-4 mb-3">
					<label for="validationDefault01">GOD SON 25$ RECEIVED</label>
					<div class="input-group">
						<input type="text" class="form-control" id="phone_num" placeholder="God Son 25$ Received" value="<?php echo $note['g_son_25_received'];?>" onchange="fun(2)" name="g_s_25_rec"   required>
					</div>
					
				</div>
				
				<div class="col-md-4 mb-3">
					<label for="validationDefault01">25$ RECEIVED DATE</label>
						<div class="input-group">
							<input type="date" class="form-control" id="validationDefault01" placeholder="Enter 25$ Received Date" value="<?php echo $note['25_received_date'];?>" name="p_25rec_date" required style="">
						</div>
				</div>
				
				<div class="col-md-4 mb-3">
					<label for="validationDefault01">DEPOSITED TO</label>
						<div class="input-group">
							<input type="text" class="form-control" id="validationDefault01" placeholder="Deposited To" value="<?php echo $note['deposited_2'];?>" name="deposit2" required style="">
						</div>
				</div>

				



</div>

<div class="form-row">

			<div class="col-md-4 mb-3">
					<label for="validationDefault01">GOD SON 100$ RECEIVED</label>
					<div class="input-group">
						<input type="text" class="form-control" id="validationDefault01" placeholder="God Son 100$ Received" value="<?php echo $note['g_son_100_received'];?>" name="g_s_100_rec" required style="">
					</div>
				</div>
				
				<div class="col-md-4 mb-3">
					<label for="validationDefault01">100$ RECEIVED DATE</label>
					<div class="input-group">
						<input type="date" class="form-control" id="client_email" placeholder="Enter 100$ Received Date" value="<?php echo $note['100_received_date'];?>" onchange="fun(1)" name="p_100rec_date" required>
					</div>
					
				</div>
				
				<div class="col-md-4 mb-3">
					<label for="validationDefault01">DEPOSITED TO</label>
					<div class="input-group">
						<input type="text" class="form-control" id="client_email" placeholder="Deposited To" value="<?php echo $note['deposited_3'];?>" onchange="fun(1)" name="deposit3" required>
					</div>
					
				</div>
				



</div>
<div class="form-row">

			<div class="col-md-5 mb-3">
					<label for="validationDefault01">PAID BY WHOM</label>
					<div class="input-group">
						<input type="text" class="form-control" id="phone_num" placeholder="Paid By Whom" value="<?php echo $note['paid_by_whom'];?>" onchange="fun(2)" name="p_by_whom"   required>
					</div>
					
				</div>
				
				<div class="col-md-2 mb-3">
				</div>

			<div class="col-md-5 mb-3">
					<label for="validationDefault01">ORDER ID (SAP)</label>
					<div class="input-group">
						<input type="text" class="form-control" id="phone_num" placeholder="Enter Order Id" value="<?php echo $note['order_id_swp'];?>" onchange="fun(2)" name="oder_id"   required>
					</div>
					
				</div>



</div>

<div class="form-row">


					<label for="validationDefault01">REMARKS</label>
					<!--<textarea id="validationDefault01"  class="form-control" name="p_remark"   required><?php echo $note['remarks'];?></textarea>//-->
						 
					 <textarea type="text" class="form-control" name="p_remark" id="p_remark"></textarea>	
				
				



</div>


<div class="form-row">

	<!--<div class="col-md-5 mb-3">
					<label for="validationDefault01">SPECIAL NOTE</label>
					<div class="input-group">
						<input type="text" class="form-control" id="client_email" placeholder="Enter Note" value="<?php echo $note['special_note'];?>"  name="p_note" required>
					</div>
					
				</div>//-->
				<label for="validationDefault01">SPECIAL NOTE</label>
				<textarea type="text" class="form-control" name="p_note" id="p_note"></textarea>

</div>
           
          <!-- <div class="form-row">
                <div class="col col-md-4">
                  <input type="file" name="userFile"/>
	              
                </div>
                
              </div> //-->
           
          
		<!--<?php
		   if($customer_type)
                                {
                                    foreach($customer_type as $p_list)
                                     {
                                                    
								    if($p_list['cust_type'] =="God Father")  
                                
                                { 
                            ?>
			   <input type="hidden" id="TS" name="fid" value="1" />
                    <?php 
                        }
                        else
                        {
                        ?>
			   <input type="hidden" id="TS" name="fid" value="2" />
                          <?php 
                                 }
                                }
                               }                                           
                               ?>//-->

		  

        
        
        <div class="btn-group" role="group" aria-label="Basic example">
		<input type="button" class="btn btn-secondary btn-lg my-2 pull-left" id="backk" value="Back" onclick="location.href='<?php echo base_url();?>index.php/Special_note/note_master?a=<?php echo $secure_code; ?>'"/>
		
		
		
		<input type="submit" class="btn btn-success  btn-lg my-2 pull-left" id="auto_click"  value="Submit">
		
		
		</div>
		<input type="hidden" name="code_idd" value="<?=$note['dealer_id']?>">
		 <input type="hidden" id="TS" name="TS" value="<?php echo time();?>" />
		</form><?php }} ?>
                
    </div>
</div>

<!--<script type = "text/javascript">
function disableDrop(){
     if(frmMain.province.options[0].selected){
          frmMain.sltSecondary.disabled = true;
     }
     else{
         frmMain.sltSecondary.disabled = false;
     }
}
</script>
<script type="text/javascript"> 

function fun(id){
    if(id==1){
        var data=document.getElementById("client_email").value;
        var url="http://purpuligo.com/iqos/index.php/Customers/email_exist";
        if(data == '')
        {
            document.getElementById("email_message").innerHTML="Enter Email Address";
            return;
        }
    }else
    {
        var url="http://purpuligo.com/iqos/index.php/Customers/phone_exist";
        var data =document.getElementById("phone_num").value;
        if(data == ''){
            document.getElementById("phone_message").innerHTML="Enter Phone Number";
            return;
    }
    }
  $.ajax({
    method: 'post',
    url: url, 
    data: {alldata : data},
    async : 'true',
    dataType : 'json',
    success: function (response) {
        console.log(response);
       if(response[0].num>0){
      if(id == 1)	
      {
        document.getElementById("email_message").innerHTML=`Email Id already registered in the name of ${response[0].name}`;
        return;
      }
      else
      {
        document.getElementById("phone_message").innerHTML="This phone number is already exist";
        return;	
      }
       }
  }
  });
 }
</script>//-->


 <?php include_once('footer.php'); ?>         

              