<html>
    
<?php include_once('header.php'); ?>
<body>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>

<script>

$(document).ready(function(){
  $('#CompanyPhone').mask('000-000-0000');
  $('#CompanyFax').mask('000-000-0000');
  $('#client_telephone1').mask('000-000-0000');
  $('#client_telephone2').mask('000-000-0000');
});
</script>
    
<div class="content">

	
  <div class="container">
    <h3 class="gold-underline">Product Edit</h3>
    
    
     <?php 
		   if(!empty($product_list))
							
							{
								foreach($product_list as $driver){
						?>
        

          <form name="driver_add" action="productdetails_update" method="post">	 
            <div class="form-row">
              <div class="col-md-3 mb-3">
                
                <label for="validationDefault01">Product Name</label>
                <div class="input-group">

                  <input type="text" class="form-control" id="validationDefault01" placeholder="driver_name"value="<?php echo $driver['product_name'];?>" name="product_name" required style="">
               </div>
              </div>
   <!--         </div>-->
			
			<!--<div class="form-row">-->
              <div class="col-md-3 mb-3">
                
                <label for="validationDefault01"> Product type</label>
                <div class="input-group">

                  <input type="text" class="form-control" id="validationDefault01" placeholder="driver_name"value="<?php echo $driver['product_type'];?>" name="product_type" required style="">
               </div>
              </div>
   <!--         </div>-->
			<!--<div class="form-row">-->
			<div class="col-md-3 mb-3">
               <label for="validationDefault01">Barcode</label>
               <div class="input-group">
                  <input type="text" class="form-control" id="barcode_no" placeholder="Barcode"value="<?php echo $driver['product_code'];?>" name="product_code" required style="">
               </div>
              </div>
              <!--</div>-->
              <!--	<div class="form-row">-->
              <div class="col-md-3 mb-3">
               <label for="validationDefault01"> Product colour</label>
               <div class="input-group">
                  <input type="text" class="form-control" id="validationDefault01" placeholder="colour_name"value="<?php echo $driver['product_colr'];?>" name="product_col" required style="">
               </div>
              </div>
              </div>
            

           
           
           
           
 
          
   <div class="btn-group" role="group" aria-label="Basic example">
		<input type="button" class="btn btn-secondary btn-lg my-2 pull-left" id="backk" value="Back" onclick="location.href='<?php echo base_url();?>index.php/Product/product_master'"/>
		
		<input type="submit" class="btn btn-success  btn-lg my-2 pull-left" id="auto_click" value="Submit" onclick="form_submit()"/>
		
		</div>
               
                <input type="hidden" name="product_id" value="<?php echo $product_id;?>" >
                <input type="hidden" id="TS" name="TS" value="<?php echo time();?>" />

        </form><?php }} ?>
                
    </div>
</div>
<script type="text/javascript"> 

function checkemail()
{
  var user_email=document.getElementById("validationPrimaryEmail").value;
  var flg='3';
  
 if(user_email)
 {
  $.ajax({
  method: 'post',
  url: 'http://purpuligo.com/booya/index.php/User_auth/mail_validation_client_agent',
  data: {
   user_email:user_email,flg:flg
  },
  success: function (response) {
   $( '#email_status' ).html(response);
   if(response=="OK")	
   {
     return true;	
   }
   else
   {
     return false;	
   }
  }
  });
 }
 else
 {
  $( '#email_status' ).html("");
  return false;
 }
}
</script>
<script>
        $(document).ready(function(){
			
			
            
            $('#province').change(function(){ 
                var id=$(this).val();
                $.ajax({
                    url : "<?php echo site_url('Admin/get_region_category_by_province');?>",
                    method : "POST",
                    data : {id: id},
                    async : true,
                    dataType : 'json',
                    success: function(data){
                        var html = '';
                        var i;
                        for(i=0; i<data.length; i++){
                            html += '<option value='+data[i].zone_id+'>'+data[i].zone_name+'</option>';
                            $('#postal_code').val(data[i].postal_code);
                        }
                        $('#region').html(html);
                        
                    }
                });
            }); 

            $.ajax({
                url : "<?php echo site_url('Admin/get_region_category_by_province');?>",
                method : "POST",
                data : {id: <?php echo $p_id;?>},
                async : true,
                dataType : 'json',
                success: function(data){
                    var html = '';
                    var i;
                    for(i=0; i<data.length; i++){
                    html += '<option value='+data[i].zone_id+'>'+data[i].zone_name+'</option>';
					console.log(html);
                    $('#postal_code').val(data[i].postal_code);
                }
                $('#region').html(html);
                $('#region').val(<?php echo $c_id; ?>);

                }
				
            });
           
            
            
			
			
          /*   $.ajax({
            url : "<?php echo site_url('Admin/client_list_ajx');?>",
                    method : "POST",
                    async : true,
                    dataType : 'json',
                    success: function(data){
                        var html = '';
                        var i;
                        for(i=0; i<data.length; i++){
							
							 if($data[i].client_id == $hubb_list[$client_id])
    {

							
                            $("#client").append('<option value='+data[i].client_id+' selected="selected">'+data[i].client_name+'</option>');
	}
                            //html += '<option value='+data[i].client_id+'>'+data[i].client_name+'</option>';
                        }
                        $('#client').multiselect({
                        includeSelectAllOption: true,
                        buttonWidth: 500,
                        enableFiltering: true,
                        selectAll: true
						
                    });
                    
                    }
            }); */
			
			$('#region').change(function(){ 
			console.log("clicked");
                var id=$(this).val();
                $.ajax({
                    url : "<?php echo site_url('Admin/get_fsa_by_zone');?>",
                    method : "POST",
                    data : {id: id},
                    async : true,
                    dataType : 'json',
                    success: function(data){
                        for(i=0; i<data.length; i++){
                            $('#postal_code').val(data[i].postal_code);
                        }
                    }
                });
            }); 
			$('#phone_no1').mask('000-000-0000');
			
			
        });
		
		
		
    </script>

 <?php include_once('footer.php'); ?>         

              