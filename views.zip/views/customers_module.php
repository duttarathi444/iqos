<?php include_once('header.php'); ?>
<body>



<div class="content">
   	
  <div class="container">
 		<h2 class="gold-underline">MODULES</h2>
 		 		
    <div class="row">
   <!--   <div class="col-3 module">-->
   <!-- 	<img src="../../assets/img/Invoice.png">-->
   <!--<?php echo site_url('Product/product_master'); ?>-->
		 <!--<a href="">-->
   <!--   	<h3>PRODUCT MASTER</h3>-->
   <!--   </div>-->
	  <div class="col-3 module last">
    	<img src="../../assets/img/god_father.png">
        <a href="<?php echo site_url('Customers/god_father_master'); ?>">
      	<p>God Father Creation</p></a>
      </div>
	  <div class="col-3 module">
    	<img src="../../assets/img/god_son.png">
		 <a href="<?php echo site_url('Customers/god_son_master'); ?>">
      	<p>God Son Creation</p></a>
      </div>

      </div>
    </div>
</div>
  <!--  <div id="" class="btn-group" role="group" aria-label="Basic example">-->
		<!--<input type="button" class="btn btn-secondary btn-lg my-2 pull-left" id="backk" value="Back" onclick="location.href='<?php echo base_url();?>index.php/Admin/product_module'" />-->
  <!--  </div>-->
</body>
<?php include_once('footer.php'); ?>