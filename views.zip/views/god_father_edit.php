<html>
    
<?php include_once('header.php'); ?>
<body onload="exist()">
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>

<script>

   $(document).ready(function(){
  $('#telephone_num').mask('000-000-0000');
   });
</script>
    <script>
        function exist(){
            var cou=document.getElementById('g_count').value;
            if(+cou>6){
                document.getElementById('gof_count').disabled=false;
            }
        }
        
        function change(){
            var select=document.getElementById('gof_count');
            var val= select.options[select.selectedIndex].value;
            document.getElementById('valid_count').value=val;
        }
    </script>
<div class="content">

	
  <div class="container">
    <h3 class="gold-underline">God Father Edit</h3>
    
    
     <?php 
		   if(!empty($customer_list))
							
							{
								foreach($customer_list as $driver){
						?>
        

          <form name="driver_add" action="god_father_update" method="post">	 
           
             <div class="form-row">
             
               
              <div class="col-md-3 mb-3">
                  <label for="validationDefault03">First Name</label>
                  <input type="text" class="form-control" name="fname" id="postal_code" maxlength="6"value="<?php echo $driver['f_name'];?>" placeholder="First Name">
                </div>
                
                
                 <div class="col-md-3 mb-3">
                
                <label for="validationDefault01">Last Name</label>
                <div class="input-group">

                  <input type="text" class="form-control" id="validationDefault01" placeholder="Barcode" name="lname" value="<?php echo $driver['l_name'];?>" required style="">
               </div>
              </div>
              
                <div class="col-md-3 mb-3">
               <label for="validationPrimaryEmail">Email Id</label>
                <div class="input-group">
                <input type="text" class="form-control" value="<?php echo $driver['mail_id'];?>" name="email" id="validationPrimaryEmail" placeholder="Shipment Name" aria-describedby="inputGroupPrepend2" required="" style="" >
               </div>
             </div>
                
            <!--<input type="text" class="form-control" value="<?php echo $father_count[0]['num'];?>" name="" id="gof_count" placeholder="Shipment Name" aria-describedby="inputGroupPrepend2" required="" style="" >-->
            <input type="hidden" id="g_count" value="<?php echo $father_count[0]['num'];?>">
    
            <div class="col-md-2 mb-3">
               <label for="validationPrimaryEmail">Remainder(God Father Count<?php echo $father_count[0]['num'];?>)</label>
                <div class="input-group">
                    <select name="" id="gof_count" onchange="change()" disabled class="form-control" required>
                        <option value="0" selected>No</option>
                        <option value="1">Yes</option>
                    </select>
               </div>
             </div>
           <input type="hidden" name="valid_count" value="0" id="valid_count">
          
             <div class="col-md-3 mb-3">
               <label for="validationPrimaryEmail">Phone Number</label>
                <div class="input-group">
                <input type="text" class="form-control" name="phonenumber"  value="<?php echo $driver['ph_no'];?>"id="telephone_num" placeholder="Shipment Name" aria-describedby="inputGroupPrepend2" required="" maxlength="10" style="">
               </div>
             </div>
             
                   <div class="col-md-3 mb-3">
                
                <label for="validationDefault01">Date Of Birth</label>
                <div class="input-group">

                  <input type="text" class="form-control" id="validationDefault01" placeholder="Carton Number"  value="<?php echo $driver['dob'];?>" name="dob" required style="">
               </div>
              </div>
              
               <div class="col-md-5 mb-3">
                
                <label for="validationDefault01">Postal Code</label>
                <div class="input-group">

                  <input type="text" class="form-control" id="validationDefault01" placeholder="Carton Number"  value="<?php echo $driver['postal_code'];?>" name="pcode" required style=""maxlength="6">
               </div>
              </div>
           
			   
            
            </div>
			  
           
           
           
           
           
           
           
           
           
 
          
   <div class="btn-group" role="group" aria-label="Basic example">
		<input type="button" class="btn btn-secondary btn-lg my-2 pull-left" id="backk" value="Back" onclick="location.href='<?php echo base_url();?>index.php/Customers/god_father_master'"/>
		
		<input type="submit" class="btn btn-success  btn-lg my-2 pull-left" id="auto_click" value="Submit" onclick="form_submit()"/>
		
		</div>
               
                <input type="hidden" name="sl_no" value="<?php echo $sl_no;?>" >
                <input type="hidden" id="TS" name="TS" value="<?php echo time();?>" />

        </form><?php }} ?>
                
    </div>
</div>
<script type="text/javascript"> 

function checkemail()
{
  var user_email=document.getElementById("validationPrimaryEmail").value;
  var flg='3';
  
 if(user_email)
 {
  $.ajax({
  method: 'post',
  url: 'http://purpuligo.com/booya/index.php/User_auth/mail_validation_client_agent',
  data: {
   user_email:user_email,flg:flg
  },
  success: function (response) {
   $( '#email_status' ).html(response);
   if(response=="OK")	
   {
     return true;	
   }
   else
   {
     return false;	
   }
  }
  });
 }
 else
 {
  $( '#email_status' ).html("");
  return false;
 }
}
</script>
<script>
        $(document).ready(function(){
			
			
            
            $('#province').change(function(){ 
                var id=$(this).val();
				
                $.ajax({
                    url : "<?php echo site_url('Admin/get_region_category_by_province');?>",
                    method : "POST",
                    data : {id: id},
                    async : true,
                    dataType : 'json',
                    success: function(data){
                        var html = '';
                        var i;
                        for(i=0; i<data.length; i++){
                            html += '<option value='+data[i].product_type+'>'+data[i].product_type+'</option>';
                            $('#postal_code').val(data[i].product_code);
                        }
                        $('#region').html(html);
                        
                    }
                });
            }); 

            $.ajax({
                url : "<?php echo site_url('Admin/get_region_category_by_province');?>",
                method : "POST",
                data : {id: <?php echo $p_id;?>},
                async : true,
                dataType : 'json',
                success: function(data){
                    var html = '';
                    var i;
                    for(i=0; i<data.length; i++){
                    html += '<option value='+data[i].product_type+'>'+data[i].product_type+'</option>';
					console.log(html);
                    $('#postal_code').val(data[i].postal_code);
                }
                $('#region').html(html);
                $('#region').val(<?php echo $c_id; ?>);

                }
				
            });
           
            
            
			
			
          /*   $.ajax({
            url : "<?php echo site_url('Admin/client_list_ajx');?>",
                    method : "POST",
                    async : true,
                    dataType : 'json',
                    success: function(data){
                        var html = '';
                        var i;
                        for(i=0; i<data.length; i++){
							
							 if($data[i].client_id == $hubb_list[$client_id])
    {

							
                            $("#client").append('<option value='+data[i].client_id+' selected="selected">'+data[i].client_name+'</option>');
	}
                            //html += '<option value='+data[i].client_id+'>'+data[i].client_name+'</option>';
                        }
                        $('#client').multiselect({
                        includeSelectAllOption: true,
                        buttonWidth: 500,
                        enableFiltering: true,
                        selectAll: true
						
                    });
                    
                    }
            }); */
			
			$('#region').change(function(){ 
			console.log("clicked");
                var id=$(this).val();
                $.ajax({
                    url : "<?php echo site_url('Admin/get_fsa_by_zone');?>",
                    method : "POST",
                    data : {id: id},
                    async : true,
                    dataType : 'json',
                    success: function(data){
                        for(i=0; i<data.length; i++){
                            $('#postal_code').val(data[i].product_code);
                        }
                    }
                });
            }); 
			$('#phone_no1').mask('000-000-0000');
			
			
        });
		
		
		
    </script>

 <?php include_once('footer.php'); ?>         

              