<html>
    <head>
        <style>
    table{
        /*border: 1px solid black;*/
        width: 100%;
        margin-bottom: 20px;
		border-collapse: separate;
        /*border-spacing: 20 0px;*/
    }
    table td{
        padding: 2px;
        text-align: left;
    }
    </style>
    </head>
    
<?php include_once('header.php'); ?>
<body onload="dateput()">
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>

<script>
// $(document).ready(function(){
//   $('#CompanyPhone').mask('000-000-0000');
//   $('#CompanyFax').mask('000-000-0000');
//   $('#client_telephone1').mask('000-000-0000');
//   $('#client_telephone2').mask('000-000-0000');
// });

function select_prod(num){
    if(num == 1){
        var e = document.getElementById('cus_email');
        var val = e.options[e.selectedIndex].value;
        var url = "http://purpuligo.com/iqos/index.php/Stock/all_customer";
    }else if(num == 2){
        var e = document.getElementById('prod_name');
        var val = e.options[e.selectedIndex].value;
        var url = "http://purpuligo.com/iqos/index.php/Stock/all_product_list";
    }
    $.ajax({
                    url : url,
                    method : "POST",
                    data : {cus_id: val},
                    async : true,
                    dataType : 'json',
                    success: function(data){
                        if(num == 1){
                        document.getElementById('cus_name').value = data[0].f_name+' '+data[0].l_name;
                        document.getElementById('cus_phone').value = data[0].ph_no;
                        document.getElementById('postal').value = data[0].postal_code;
                        if(Object.keys(data[0]).length > 4){
                            document.getElementById('god_father_name').value = data[0].p_f_name+' '+data[0].p_l_name;
                            document.getElementById('god_father_email').value = data[0].p_mail;
                            document.getElementById('god_father_phone').value = data[0].p_ph;
                        }else{
                            document.getElementById('god_father_name').value = '';
                            document.getElementById('god_father_email').value = '';
                            document.getElementById('god_father_phone').value = '';
                        }
                        }else if(num == 2){
                            var valid2=data[0].product_type.substring(0,4).toLowerCase().trim()=='iqos';
                            document.getElementById('prod_color').value = data[0].product_colr;
                            document.getElementById('prod_code').value= data[0].product_code;
                            document.getElementById('prod_type').value= data[0].product_type;
                            if(valid2){
                                document.getElementById('prod_serial1').value="";
                                document.getElementById('prod_serial1').readOnly=false;
                            }else{
                                document.getElementById('prod_serial1').value="";
                                document.getElementById('prod_serial1').readOnly=true;
                            }
                        }
                    }
                    });
}


// function check_qty(){
//     var prd_qty=document.getElementById('qty_prd').value;
//     var act_qty=document.getElementById('prod_qty').value;
//     if(prd_qty!='' && act_qty!=''){
//         if(act_qty<=prd_qty && act_qty>0){
//             document.getElementById('auto_click').disabled=false;
//         }else{
//             document.getElementById('auto_click').disabled=true;
//         }
//     }else{
//         document.getElementById('auto_click').disabled=true;
//     }
// }

function dateput(){
    var datenow=new Date(Date.now());
    var month=+datenow.getMonth()+1;
    if((month+"").length<2){
        month='0'+month;
    }
    var date='';
    if((datenow.getDate()+"").length<2){
        date= '0'+datenow.getDate();
    }
    var newdate = datenow.getFullYear()+'-'+month+'-'+date;
    document.getElementById('swap_date').value=newdate;
}

</script>


<div class="content">
  <div class="container">
       <?php 
		   if(!empty($sale_products_data))
							
							{
						?>
        
      <a id="back2Top" title="Back to top" href="#">&#10148;</a>
    <h3 class="gold-underline">Product Swap</h3>
    <br>
    <h4><u>Existing Product Details</u></h4>
    
          <form name="driver_add" action="replace_new_product" method="post" enctype="multipart/form-data">
	        <div class="form-row">
              <div class="col-md-2 mb-2">
               <label for="validationPrimaryEmail"> Product sale Date</label>
                <div class="input-group">
                  <input type="date" class="form-control" value="<?php echo $sale_products_data[0]['prd_sale_date'];?>"
id="select_date" name="select_date"  readonly required>
               </div>
			   
             </div>
             <div class="col-md-3 mb-3">
               <label for="validationPrimaryEmail">Customer Email</label>
             <input type="text" class="form-control" name="phone_no" value="<?php echo $sale_products_data[0]['mail_id'];?>" id="god_father_email" readonly placeholder="God Father Email" >
             </div>
             <div class="col-md-2 mb-3">
               <label for="validationPrimaryEmail">Customer Name</label>
                <div class="input-group">
                <input type="text" class="form-control" id="cus_name" value="<?php echo $sale_products_data[0]['f_name'].' '.$sale_products_data[0]['l_name'];?>" name="customer_name" readonly placeholder="Customer Name" >
               </div>
             </div>
             
                <div class="col-md-2 mb-3">
               <label for="validationPrimaryEmail">Customer Phone No</label>
                <div class="input-group">
                <input type="text" class="form-control" name="phone_no" value="<?php echo $sale_products_data[0]['ph_no'];?>" id="cus_phone" readonly  placeholder="Phone No" >
               </div>
             </div>
             
                <div class="col-md-3 mb-2">
               <label for="validationPrimaryEmail">Customer Postal Code</label>
                <div class="input-group">
                <input type="text" class="form-control" name="postal_code" value="<?php echo $sale_products_data[0]['postal_code'];?>" id="postal" readonly placeholder="Postal Code" >
               </div>
             </div>
           
           
    
           
          
           	    
              <div class="col-md-3 mb-3">
               <label for="validationPrimaryEmail">God Father Name</label>
                <div class="input-group">
                <input type="text" class="form-control" id="god_father_name" value="<?php echo $sale_products_data[0]['fname'].' '.$sale_products_data['lname'];?>" name="customer_name" readonly placeholder="God Father Name" >
               </div>
             </div>
             
             <div class="col-md-3 mb-2">
               <label for="validationPrimaryEmail">God Father Email</label>
                <div class="input-group">
                <input type="text" class="form-control" name="phone_no" value="<?php echo $sale_products_data[0]['email'];?>" id="god_father_email" readonly placeholder="God Father Email" >
               </div>
             </div>
             
             <div class="col-md-3 mb-3">
               <label for="validationPrimaryEmail">God Father Phone No</label>
                <div class="input-group">
                <input type="text" class="form-control" name="postal_code" value="<?php echo $sale_products_data[0]['phone_no'];?>" id="god_father_phone" readonly placeholder="God Father Phone No" >
               </div>
             </div>
             
              <div class="col-md-3 mb-2">
               <label for="validationPrimaryEmail">God Father Postal Code</label>
                <div class="input-group">
                <input type="text" class="form-control" name="postal_code" value="<?php echo $sale_products_data[0]['postal_code'];?>" id="god_father_phone"readonly  placeholder="God Father Phone No" >
               </div>
             </div>
           
           
			   
             <div class="col-md-3 mb-3">
               <label for="validationPrimaryEmail">Product Name</label>
            <input type="text" class="form-control" name="postal_code" value="<?php echo $sale_products_data[0]['product_name'];?>"  id="god_father_phone" readonly placeholder="God Father Phone No" >

               
             </div>
                   <div class="col-md-3 mb-3">
               <label for="validationPrimaryEmail">Product Color</label>
                <div class="input-group">
                  <input type="type" class="form-control"  value="<?php echo $sale_products_data[0]['product_colr'];?>" placeholder="Product Color" readonly name="product_color">
               </div>
            </div>

        <div class="col-md-3 mb-2">
               <label for="validationPrimaryEmail">Barcode</label>
                <div class="input-group">
                <input type="text" class="form-control"  value="<?php echo $sale_products_data[0]['product_code'];?>"  name="serial_no" placeholder="Barcode" readonly>
               </div>
             </div>
             
           	      <div class="col-md-3 mb-2">
               <label for="validationPrimaryEmail">Product Type</label>
                <div class="input-group">
                <input type="text" class="form-control"  value="<?php echo $sale_products_data[0]['product_type'];?>"  name="serial_no" placeholder="Serial Number" readonly>
               </div>
             </div>
             
           	    
              <div class="col-md-3 mb-2">
               <label for="validationPrimaryEmail">Serial Number</label>
                <div class="input-group">
                <input type="text" class="form-control"  value="<?php echo $sale_products_data[0]['serial_no'];?>"  name="serial_no" placeholder="Serial Number" readonly>
               </div>
             </div>
             
          
             
             <div class="col-md-3 mb-2">
               <label for="validationPrimaryEmail">SAP Order No</label>
                <div class="input-group">
                <input type="text" class="form-control" name="sap_no" id="sap_no" value="<?php echo $sale_products_data[0]['sap_order_no'];?>" placeholder="SAP Order No" readonly>
               </div>
             </div>
             
   

          
            
            
             <div class="col-md-3 mb-3">
               <label for="validationPrimaryEmail">Device Registered</label>
            <input type="text" class="form-control"  value="<?php echo ($sale_products_data[0]['device_reg']==1)? 'Yes':'No';?>" id="res_dat"  name="registation_date" readonly required>
       
             </div>
             
             <div class="col-md-3 mb-3">
               <label for="validationPrimaryEmail">Device Registered Date</label>
                <div class="input-group">
                  <input type="date" class="form-control" value="<?php echo $sale_products_data[0]['device_reg_date'];?>"   name="" readonly required>
               </div>
            </div>
           
           </div>
           
              <h3 class="gold-underline">Swap Product Details</h3>
            
             <?php } ?>
          
           
           <table>
    
<thead>
    <tr>
        
        <td width="10%"><b>Swap Date</b></td>
        
        <td width="10%"><b>Product Name</b></td>
		
		<td width="10%"><b>Product Color</b></td>
		
		<td width="10%"><b>Product Type</b></td>
		
		<td width="10%"><b>Barcode</b></td>
		
		<td width="10%"><b>Registation Date</b></td>
		
		<td width="10%"><b>New Serial No</b></td>
		
		<td width="10%"><b>Glove Service No</b></td>
		
    </tr>
</thead>
<tbody>
						    
<?php 
		   if(!empty($swap_list))
							
							{
								foreach($swap_list as $swap_sdata){
						?>
						
					<tr>
					    
				    <td width="10%" ><?php echo $swap_sdata['swap_date'];?></td>
						        
						<td width="10%" height="50"><?php echo $swap_sdata['product_name'];?></td>
						
						<td width="10%"><?php echo $swap_sdata['product_colr'];?></td>
						
						<td width="10%"><?php echo $swap_sdata['product_type'];?></td>
						
						<td width="10%"><?php echo $swap_sdata['product_code'];?></td>
						
						<td width="10%"><?php echo $swap_sdata['date'];?></td>
						
						<td width="10%"><?php echo $swap_sdata['new_serial_number'];?></td>
						
						<td width="10%"><?php echo $swap_sdata['wgs_no'];?></td>
						
						</tr>
						
						
						<?php }}?>
						</tbody>
						</table>
           
           <h4><u>New Product Details</u></h4>
           <br>
          	<div class="form-row">
             <div class="col-md-3 mb-3">
               <label for="validationPrimaryEmail">Product Name</label>
                <select name="product_id" id="prod_name" class="form-control" onchange=select_prod(2) required>
                    <option selected="">Select Product Name</option>
                    <?php if($product_list){foreach($product_list as $p_list){ ?>
                    <option value="<?php echo $p_list['product_id']; ?>"><?php echo  $p_list['product_name'];?></option>
                    <?php }}?>
                  </select>
             </div>
             
             <div class="col-md-3 mb-3">
               <label for="validationPrimaryEmail">Product Color</label>
                <div class="input-group">
                  <input type="type" class="form-control" id="prod_color" value="" placeholder="Product Color"  name="product_color" readonly>
               </div>
            </div>
            
               
             <div class="col-md-3 mb-3">
               <label for="validationPrimaryEmail">Barcode</label>
                <div class="input-group">
                  <input type="type" class="form-control" id="prod_code" value="" placeholder="Product Barcode"  name="product_color"readonly>
               </div>
            </div>
            
                  
             <div class="col-md-2 mb-3">
               <label for="validationPrimaryEmail">Product Type</label>
                <div class="input-group">
                  <input type="type" class="form-control" id="prod_type" value="" placeholder="Product Type"  name="product_color" readonly>
               </div>
            </div>
            
            <!--<div class="col-md-2 mb-3">-->
            <!--   <label for="validationPrimaryEmail">Product Serial No</label>-->
            <!--    <div class="input-group">-->
            <!--      <input type="type" class="form-control" id="prod_bar" value="" placeholder="Serial No"  name="prod_bar" disabled>-->
            <!--   </div>-->
            <!--</div>-->
            
            <!--<div class="col-md-2 mb-3">-->
            <!--   <label for="validationPrimaryEmail">Quantity</label>-->
            <!--    <div class="input-group">-->
            <!--      <input type="type" class="form-control" id="prod_qty" value="" onchange="check_qty()" placeholder="Quantity"  name="product_quantity" readonly>-->
            <!--   </div>-->
            <!--</div>-->
            
            <input type="hidden" name="product_quantity" value="1">
            
             <div class="col-md-3 mb-3">
               <label for="validationPrimaryEmail">White Glove Service No</label>
                <div class="input-group">
                  <input type="text" class="form-control" id="" name="glove" placeholder="White Glove Service No" required>
               </div>
            </div>
              
            
              <div class="col-md-3 mb-3">
               <label for="validationPrimaryEmail">New Serial Number</label>
                <div class="input-group">
                  <input type="type" class="form-control" id="prod_serial1" readonly name="serial_num" placeholder="Product Serial Number">
               </div>
            </div>
           
           
           
             <div class="col-md-2 mb-3">
               <label for="validationPrimaryEmail">Device Registered</label>
              <select name="res_valid" onchange="valid()" id="res_validation" class="form-control" required>
                    <option value=1 selected>Yes</option>
                    <option value=0>No</option>
                  </select>
            </div>
            
             <div class="col-md-2 mb-3">
               <label for="validationPrimaryEmail">Device Registered Date</label>
                <div class="input-group">
                  <input type="date" class="form-control" id="res_date"  name="registation_date" required>
               </div>
            </div>
            
              <div class="col-md-2 mb-3">
               <label for="validationPrimaryEmail">Swap date</label>
                <div class="input-group">
                  <input type="date" class="form-control" id="swap_date"  name="swap_date" required>
               </div>
            </div>
            
            
        </div>
            

          
            <div class="btn-group" role="group" aria-label="Basic example">
		    <input type="button" class="btn btn-secondary btn-lg my-2 pull-left" id="backk" value="Back" onclick="location.href='<?php echo base_url();?>index.php/Stock/product_replace'"/>
		
		<!--<input type="button" class="btn btn-success  btn-lg my-2 pull-left" id="add-row" value="Add Row">-->
		
		<!--<button type="button" class="btn btn-success  btn-lg my-2 pull-left" id="delete-row">Delete Row</button>-->
		
		<input type="submit" class="btn btn-success  btn-lg my-2 pull-left" id="auto_click" value="Submit"/>
		
		</div>
		 <input type="hidden" id="sale_id3" value="<?php echo $sale_id;?>" name="sale_id3" />

        </form>
                
    </div>
</div>
<script>
    function valid(){
    var e = document.getElementById('res_validation');
    var val = e.options[e.selectedIndex].value;
    console.log(val);
    if(val == 1)
    $('#res_date').removeAttr('readonly');
    else
    $('#res_date').attr('readonly', true);
    document.getElementById('res_date').value='';
    }
</script>
    
 <?php include_once('footer.php'); ?>         

              