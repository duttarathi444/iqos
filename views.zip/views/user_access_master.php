<html>
<?php include_once('header.php'); ?>

    <link  href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css" rel="stylesheet" />
    <link href="https://cdn.datatables.net/buttons/1.6.0/css/buttons.dataTables.min.css" rel="stylesheet" />
    <script src="https://code.jquery.com/jquery-3.3.1.js"></script>
    <script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.6.0/js/dataTables.buttons.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.6.0/js/buttons.colVis.min.js"></script>

<style>
	table.dataTable tbody td {
    
	font-size: 13px;}
	table.dataTable tbody th {
    
	font-size: 14px;}
	</style>
<body>
   <script>
    
    $(document).ready(function() {
    $('#example').DataTable( {
        dom: 'Bfrtip',
        columnDefs: [
            {
                targets: 1,
                className: 'noVis'
            }
        ],
        buttons: [
            {
                extend: 'colvis',
                columns: ':not(.noVis)'
            }
        ],
        "order": [[ 0, "desc" ]]
    } );
 } );



    
</script>



<form name="user_access_list"action="user_accesss"  method="post">
<div class="content">
  <div class="container">
      <a id="back2Top" title="Back to top" href="#">&#10148;</a>
    <h3 class="gold-underline">User Accesss List</h3>
   
       <table id="example" class="display" >
        <thead>
            <tr>
                <th>Record Id</th>
                <th>User</th>
                <th>Group</th>
                <th>Date</th>
                <th>Time</th>
                <th>Module</th>
                <th>Details</th>
            </tr>
        </thead>
        
        <tbody>
             <?php if($user_access_master_list){
                  foreach($user_access_master_list as $master_list){ ?>
           
           <tr>
                <td><?php echo $master_list['log_id'];?></td>
                <td><?php echo $master_list['email_id'];?></td>
                <td><?php echo $master_list['role_name'];?></td>
                <td><?php echo $master_list['log_date'];?></td>
                <td><?php echo $master_list['log_time'];?></td>
                <td><?php echo $master_list['module_name'];?></td>
                <td><?php echo $master_list['page_name'];?></td>
           </tr>
           <?php }}?>
        </tbody>
        

    </table>
 <div class="btn-group" role="group" aria-label="Basic example">             
<input type="button" class="btn btn-secondary btn-lg my-2 pull-left" id="backk" value="Back" onclick="location.href='<?php echo base_url();?>index.php/Admin/product_module2'" />
</div>
</div>
   

</div>
</form>
  
  
 <?php include_once('footer.php'); ?>  