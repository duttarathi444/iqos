<html>
<?php include_once('header.php'); ?>

    <link  href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css" rel="stylesheet" />
    <link href="https://cdn.datatables.net/buttons/1.6.0/css/buttons.dataTables.min.css" rel="stylesheet" />
    <script src="https://code.jquery.com/jquery-3.3.1.js"></script>
    <script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.6.0/js/dataTables.buttons.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.6.0/js/buttons.colVis.min.js"></script>

<style>
	table.dataTable tbody td {
    
	font-size: 13px;}
	table.dataTable tbody th {
    
	font-size: 14px;}
	</style>
<body>




    <script>
    
    $(document).ready(function() {
    $('#example').DataTable( {
        dom: 'Bfrtip',
        columnDefs: [
            {
                targets: 1,
                className: 'noVis'
            }
        ],
        buttons: [
            {
                extend: 'colvis',
                columns: ':not(.noVis)'
            }
        ],
        "order": [[ 0, "desc" ]]
    } );
 } );




        
        function modi(c_id)
        {
			console.log(c_id);
            document.getElementById("sale_id").value = c_id;
            document.getElementById("c2").submit();
        }
        
        function module_list()
        {
            document.getElementById("c3").submit();
        }
        
        function view_p(d_id)
        {
            document.getElementById("sale_id6").value = d_id;
            document.getElementById("c6").submit();
        }
        
        function dr_delete(c_id)
        {
            var conirm_delete = confirm("You are about to Delete Sale ID "+c_id+ " . Please confirm ?")
            if (conirm_delete == true) { 
                document.getElementById("sale_id3").value = c_id;
                document.getElementById("c4").submit();
            } else { 
                return;
            } 
            
        }
        
        function driver_reg()
        {
            document.getElementById("c5").submit();
        }
        
        $(document).ready(function(){
            $("#agadd").click(function(){
                $("#c5").submit(); // Submit the form
            });
            $("#agedit").click(function(){
                $("#c3").submit(); // Submit the form
            });
        })


    
</script>
<form name="c2" id="c2" action="sale_data_edit" method="post">
    <input type="hidden" id="sale_id" name="sale_id" />
</form>
<form name="c3" id="c3" action="admin_tools" method="post">
</form>

<form name="c4" id="c4" action="delete_sale_data_by_id" method="post">
    <input type="hidden" id="sale_id3" name="sale_id3" />
</form>

<form name="c5" id="c5" action="product_stock_out" method="post">
    
</form>

 <form name="c6" id="c6" action="show_sales_by_id"method="post">
    <input type="hidden" id="sale_id6" name="sale_id6"/>
</form>


<form name="driver_list"  method="post">
<div class="content">
  <div class="container">
  <a id="back2Top" title="Back to top" href="#">&#10148;</a>
  <?php if($alert_flag == 1){?>
  <div class="alert alert-success alert-dismissible">
  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
  <?php echo $alert_message;?>
  </div>
  <?php }$alert_flag = 0;
  $alert_message = "" ?>
  
   <h3 class="gold-underline">Product Sale Details</h3>
   
     <div class="btn-group" role="group" aria-label="Basic example">
   <!--  <input type="button" class="btn btn-primary btn-lg my-2 pull-left" id="agadd" value="Driver Add" onclick="agent_reg()" />//-->
   <input type="button" class="btn btn-success  btn-lg my-2 pull-left" id="agadd" value="New Product Sale" onclick="agent_reg()"/>
   </div>
             

    
      <table id="example" class="display" >
        <thead>
            <tr>
                <th>Sale ID</th>
                <th>Sale Date</th>
                <th>Customer Name</th>
                <th>PRODUCT Name</th>
                 <th>Quantity</th>
				 <!--<th>Serial No</th>-->
				 
				 <th>SAP Order No</th>
				 <!--<th>Device Registation</th>-->
				 <!--<th>Device Registation Date</th>-->
				 <th>PE1 Date</th>
				 <!--<th>PE1 Status</th>-->
				 <th>PE2 Date</th>
				 <!--<th>PE2 Status</th>-->
                 <th>Action</th>
               
            </tr>
        </thead>
        
        <tbody>
            
            <?php if($product_sale_details){
                  foreach($product_sale_details as $master_list){ ?>
            <tr>
                <td><?php echo $master_list['p_sale_id'];?></td>
                <td><?php echo $master_list['prd_sale_date'];?></td>
                <td><?php echo $master_list['f_name'].' '.$master_list['l_name'];?></td>
                <td><?php echo $master_list['product_name'];?></td>
                <td><?php echo $master_list['prd_quantity'];?></td>
				<!--<td><?php echo $master_list['product_code'];?></td>-->
				<td><?php echo $master_list['sap_order_no'];?></td>
				
    <!--            <?php if($master_list['device_reg'] == 1){?>-->
				<!--<td>Yes</td>-->
				<!--<?php }else{?>-->
				<!--<td>No</td>-->
				<!--<?php }?>-->
				<!--<td><?php echo $master_list['device_reg_date'];?></td>-->
				<td><?php echo $master_list['pe1_date'];?></td>
				<!--<td><?php echo $master_list['pe1_status'];?></td>-->
                <td><?php echo $master_list['pe2_date'];?></td>
                <!--<td><?php echo $master_list['pe2_status'];?></td>-->
                
                <td>
			         <!--href="javascript:ajx_view(<?php echo $master_list['order_id'];?>);"-->
			   <div class="btn-group">
			       <!--<a href="javascript:show_prod(<?php echo $master_list['p_sale_id'];?>)"> <i class="fa fa-search" data-toggle="tooltip" title="Client List"> </i></a> &nbsp;&nbsp;-->
			         <a href="javascript:view_p(<?php echo $master_list['p_sale_id'];?>)" ><i class="fa fa-eye" data-toggle="tooltip" title="View"> </i></a> &nbsp;&nbsp;
			        <a href="javascript:modi(<?php echo $master_list['p_sale_id'];?>)" > <i class="fa fa-pencil-square-o"></i></a>&nbsp;&nbsp;
			        <a  href="javascript:dr_delete(<?php echo $master_list['p_sale_id'];?>)" ><i class="fa fa-window-close-o"></i></a>
			    </div>
			    </td>
            </tr>
            <?php }}?>
        </tbody>
        

    </table>
 <div class="btn-group" role="group" aria-label="Basic example">             
<input type="button" class="btn btn-secondary btn-lg my-2 pull-left" id="backk" value="Back" onclick="location.href='<?php echo base_url();?>index.php/Admin/product_module'" />
</div>
</div>
   
       <!-- <input type="hidden" name="product_id" value="<?php echo $order_no;?>"/>  //-->
  
  
</div>
</form>
  
  
 <?php include_once('footer.php'); ?>