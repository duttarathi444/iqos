<html>
    
<?php include_once('header.php'); ?>
<body>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>

<script>

$(document).ready(function(){
  $('#CompanyPhone').mask('000-000-0000');
  $('#CompanyFax').mask('000-000-0000');
  $('#client_telephone1').mask('000-000-0000');
  $('#client_telephone2').mask('000-000-0000');
});
</script>
    
<div class="content">

	
  <div class="container">
    <h2 class="gold-underline">Edit Stock</h2>
    
    
     <?php 
		   if(!empty($stock_list))
							
							{
								foreach($stock_list as $driver){
						?>
        

          <form name="driver_add" action="stockdetails_update" method="post">	 
           
             <div class="form-row">
              <div class="col col-md-4">
                  <label for="inputState">Product Name</label>
                  <select name="province" id="province" class="form-control">
                      <?php 
                                if($product_master_list)
                                {
                                    foreach($product_master_list as $p_list)
                                     {
                                    $p_id = $driver['product_name'];               
								    if($p_list['product_name'] == $driver['product_name'])  
                                
                                { 
                            ?>
                    <option selected value="<?php echo $p_list['product_name']; ?>"><?php echo  $p_list['product_name'];?></option>
                    <?php 
                        }
                        else
                        {
                        ?>
                         <option value="<?php echo $p_list['product_name'];?>"><?php echo $p_list['product_name'];?></option>
                          <?php 
                                 }
                                }
                               }                                           
                               ?>
                  </select>
                </div>
                <div class="col col-md-4">
                  <label for="inputState">Product Type</label>
                  <select name="region" id="region" class="form-control">
                  <!--<input type="text" class="form-control" value="<?php echo $driver['product_type'];?>" readonly>//-->
				    <?php 
                               $c_id = $driver['product_id'];
							   
                                    if($product_master_list)
                                {
                                    foreach($product_master_list as $p_list)
                                     {
                                                   
								    if($p_list['product_type'] == $driver['product_type'])  
                                
                                { 
                            ?>
                    <option selected value="<?php echo $p_list['product_type']; ?>"><?php echo  $p_list['product_type'];?></option>
                    <?php 
                        }
                        else
                        {
                        ?>
                         <option value="<?php echo $p_list['product_type'];?>"><?php echo $p_list['product_type'];?></option>
                          <?php 
                                 }
                                }
                               }                                           
                               ?>
                  </select>
                </div>
              <div class="col col-md-4">
                  <label for="validationDefault03">Product Code</label>
                  <input type="text" class="form-control" name="postal_code" id="postal_code" maxlength="6"value="<?php echo $driver['item_code'];?>" placeholder="TO1">
                </div>
                </div>
             <div class="form-row">
              <div class="col-md-12 mb-3">
                
                <label for="validationDefault01">Barcode</label>
                <div class="input-group">

                  <input type="text" class="form-control" id="validationDefault01" placeholder="Barcode" name="barcode" value="<?php echo $driver['product_bar_code'];?>" required style="">
               </div>
              </div>
            </div>

           <div class="form-row">
              <div class="col-md-6 mb-3">
               <label for="validationPrimaryEmail">Received From</label>
                <div class="input-group">
                <input type="text" class="form-control" value="<?php echo $driver['recevied_from'];?>" name="recevided_from" id="validationPrimaryEmail" placeholder="Shipment Name" aria-describedby="inputGroupPrepend2" required="" style="" onkeyup="checkemail();">
               </div>
			   <span id="email_status"></span>
             </div>
             <div class="col-md-6 mb-3">
               <label for="validationPrimaryEmail">Shipment Name</label>
                <div class="input-group">
                <input type="text" class="form-control" name="shipment"  value="<?php echo $driver['shipmnt_name'];?>"id="validationPrimaryEmail" placeholder="Shipment Name" aria-describedby="inputGroupPrepend2" required="" style="" onkeyup="checkemail();">
               </div>
			   <span id="email_status"></span>
             </div>
           </div>
               <div class="form-row">
              <div class="col-md-12 mb-3">
                
                <label for="validationDefault01">Carton Number</label>
                <div class="input-group">

                  <input type="text" class="form-control" id="validationDefault01" placeholder="Carton Number"  value="<?php echo $driver['carton_number'];?>" name="carton" required style="">
               </div>
              </div>
            </div>
             <div class="form-row">
              <div class="col-md-12 mb-3">
                
                <label for="validationDefault01">Received Date</label>
                <div class="input-group">

                  <input type="date" class="form-control" id="validationDefault01" placeholder="date"  value="<?php echo $driver['recived_date'];?>" name="date" required style="">
               </div>
              </div>
            </div>
			  
           
           
           
           
           
           
           
           
           
 
          
   <div class="btn-group" role="group" aria-label="Basic example">
		<input type="button" class="btn btn-secondary btn-lg my-2 pull-left" id="backk" value="Back" onclick="location.href='<?php echo base_url();?>index.php/Stock/stock_master'"/>
		
		<input type="submit" class="btn btn-success  btn-lg my-2 pull-left" id="auto_click" value="Submit" onclick="form_submit()"/>
		
		</div>
               
                <input type="hidden" name="order_no" value="<?php echo $order_no;?>" >
                <input type="hidden" id="TS" name="TS" value="<?php echo time();?>" />

        </form><?php }} ?>
                
    </div>
</div>
<script type="text/javascript"> 

function checkemail()
{
  var user_email=document.getElementById("validationPrimaryEmail").value;
  var flg='3';
  
 if(user_email)
 {
  $.ajax({
  method: 'post',
  url: 'http://purpuligo.com/booya/index.php/User_auth/mail_validation_client_agent',
  data: {
   user_email:user_email,flg:flg
  },
  success: function (response) {
   $( '#email_status' ).html(response);
   if(response=="OK")	
   {
     return true;	
   }
   else
   {
     return false;	
   }
  }
  });
 }
 else
 {
  $( '#email_status' ).html("");
  return false;
 }
}
</script>
<script>
        $(document).ready(function(){
			
			
            
            $('#province').change(function(){ 
                var id=$(this).val();
				
                $.ajax({
                    url : "<?php echo site_url('Admin/get_region_category_by_province');?>",
                    method : "POST",
                    data : {id: id},
                    async : true,
                    dataType : 'json',
                    success: function(data){
                        var html = '';
                        var i;
                        for(i=0; i<data.length; i++){
                            html += '<option value='+data[i].product_type+'>'+data[i].product_type+'</option>';
                            $('#postal_code').val(data[i].product_code);
                        }
                        $('#region').html(html);
                        
                    }
                });
            }); 

            $.ajax({
                url : "<?php echo site_url('Admin/get_region_category_by_province');?>",
                method : "POST",
                data : {id: <?php echo $p_id;?>},
                async : true,
                dataType : 'json',
                success: function(data){
                    var html = '';
                    var i;
                    for(i=0; i<data.length; i++){
                    html += '<option value='+data[i].product_type+'>'+data[i].product_type+'</option>';
					console.log(html);
                    $('#postal_code').val(data[i].postal_code);
                }
                $('#region').html(html);
                $('#region').val(<?php echo $c_id; ?>);

                }
				
            });
           
            
            
			
			
          /*   $.ajax({
            url : "<?php echo site_url('Admin/client_list_ajx');?>",
                    method : "POST",
                    async : true,
                    dataType : 'json',
                    success: function(data){
                        var html = '';
                        var i;
                        for(i=0; i<data.length; i++){
							
							 if($data[i].client_id == $hubb_list[$client_id])
    {

							
                            $("#client").append('<option value='+data[i].client_id+' selected="selected">'+data[i].client_name+'</option>');
	}
                            //html += '<option value='+data[i].client_id+'>'+data[i].client_name+'</option>';
                        }
                        $('#client').multiselect({
                        includeSelectAllOption: true,
                        buttonWidth: 500,
                        enableFiltering: true,
                        selectAll: true
						
                    });
                    
                    }
            }); */
			
			$('#region').change(function(){ 
			console.log("clicked");
                var id=$(this).val();
                $.ajax({
                    url : "<?php echo site_url('Admin/get_fsa_by_zone');?>",
                    method : "POST",
                    data : {id: id},
                    async : true,
                    dataType : 'json',
                    success: function(data){
                        for(i=0; i<data.length; i++){
                            $('#postal_code').val(data[i].product_code);
                        }
                    }
                });
            }); 
			$('#phone_no1').mask('000-000-0000');
			
			
        });
		
		
		
    </script>

 <?php include_once('footer.php'); ?>         

              