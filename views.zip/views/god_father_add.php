<html>
    
<?php include_once('header.php'); ?>
<body>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>

<script>

$(document).ready(function(){
  $('#CompanyPhone').mask('000-000-0000');
  $('#CompanyFax').mask('000-000-0000');
  $('#client_telephone').mask('0000000000');
  $('#client_telephone2').mask('000-000-0000');
});

function check_date(){
    var dob_date = document.getElementById('dob').value;
    var pre_date = new Date(dob_date);
    var previ_date = pre_date.getFullYear();
    var current_date =new Date(Date.now());
    var current_year = current_date.getFullYear();
    if((current_year-previ_date)>=18){
        document.getElementById('auto_click').disabled= false;
        document.getElementById('dob_message').innerHTML="";
    }else{
       document.getElementById('dob_message').innerHTML="You Are Not +18";
    }
}


$(document).ready(function(){
  $('#phone_num').mask('000-000-0000');
});
</script>
    
<div class="content">

	
  <div class="container">
      <a id="back2Top" title="Back to top" href="#">&#10148;</a>
    <h3 class="gold-underline">Add new God Father</h3>
        

          <form name="driver_add" ID = "frmMain" action="god_father_registration" method="post" enctype="multipart/form-data">	
             	  
            <div class="form-row">
                
             

			  <div class="col-md-3 mb-3">
                
                <label for="validationDefault01">First Name</label>
                <div class="input-group">
				

                  <input type="text" class="form-control" id="validationDefault01" placeholder="First Name" name="fname" required style="">
				  
               </div>
			    
			  
            </div>
			 <div class="col-md-3 mb-3">
                
                <label for="validationDefault01">Last Name</label>
                <div class="input-group">
                  <input type="text" class="form-control" id="validationDefault01" placeholder="Last Name" name="lname" required style="">
               </div>
			   
              </div>
              
			  <div class="col-md-3 mb-3">
                
                <label for="validationDefault01">Email Address</label>
                <div class="input-group">
                  <input type="email" class="form-control" id="client_email" placeholder="Email Address" onchange="fun(1)" name="email" required>
               </div>
			   <span style="color:red" id="email_message"></span>
              </div>
              
			  <div class="col-md-3 mb-3">
                
                <label for="validationDefault01">Phone Number</label>
                <div class="input-group">
                  <input type="text" class="form-control" id="phone_num" placeholder="Phone Number" onchange="fun(2)" name="phone"   required>
               </div>
			   <span style="color:red" id="phone_message"></span>
              </div>
              
			  <div class="col-md-3 mb-3">
                
                <label for="validationDefault01">Date Of Birth</label>
                <div class="input-group">
				

                  <input type="date" class="form-control" id="dob" placeholder="1990-09-08" name="dob" required onchange="check_date()">
               </div>
			   <span style="color:red" id="dob_message"></span>
              </div>
			  <div class="col-md-3 mb-3">
                
                <label for="validationDefault01">Postal Code</label>
                <div class="input-group">
				

                  <input type="text" class="form-control" id="validationDefault01" placeholder="Postal Code" name="pcode" required style="" maxlength="6">
				  
               </div>
			   
              </div>
			
			  
			  
	</div>
          
            
           
           
           

           
           
           
          <!-- <div class="form-row">
                <div class="col col-md-4">
                  <input type="file" name="userFile"/>
	              
                </div>
                
              </div> //-->
           
          
		<?php
		   if($customer_type)
                                {
                                    foreach($customer_type as $p_list)
                                     {
                                                    
								    if($p_list['cust_type'] =="God Father")  
                                
                                { 
                            ?>
			   <input type="hidden" id="TS" name="fid" value="1" />
                    <?php 
                        }
                        else
                        {
                        ?>
			   <input type="hidden" id="TS" name="fid" value="2" />
                          <?php 
                                 }
                                }
                               }                                           
                               ?>

		  

        
        
        <div class="btn-group" role="group" aria-label="Basic example">
		<input type="button" class="btn btn-secondary btn-lg my-2 pull-left" id="backk" value="Back" onclick="location.href='<?php echo base_url();?>index.php/Customers/god_father_master'"/>
		
		
		
		<input type="submit" class="btn btn-success  btn-lg my-2 pull-left" id="auto_click" disabled value="Submit">
		 <input type="hidden" id="TS" name="TS" value="<?php echo time();?>" />
		
		</div>
		</form>
                
    </div>
</div>

<script type = "text/javascript">
function disableDrop(){
     if(frmMain.province.options[0].selected){
          frmMain.sltSecondary.disabled = true;
     }
     else{
         frmMain.sltSecondary.disabled = false;
     }
}
</script>
<script type="text/javascript"> 

function fun(id){
    if(id==1){
        var data=document.getElementById("client_email").value;
        var url="http://purpuligo.com/iqos/index.php/Customers/email_exist";
        if(data == '')
        {
            document.getElementById("email_message").innerHTML="Enter Email Address";
            return;
        }
    }else
    {
        var url="http://purpuligo.com/iqos/index.php/Customers/phone_exist";
        var data =document.getElementById("phone_num").value;
        if(data == ''){
            document.getElementById("phone_message").innerHTML="Enter Phone Number";
            return;
    }
    }
  $.ajax({
    method: 'post',
    url: url, 
    data: {alldata : data},
    async : 'true',
    dataType : 'json',
    success: function (response) {
        console.log(response);
    if(id == 1){
        if(response[0].num>0){
            document.getElementById("email_message").innerHTML=`Email Id already registered in the name of ${response[0].name}`;
            return;
        }else{
          document.getElementById("email_message").innerHTML="";
          return;
        }
       }else{
           if(response[0].num>0){
                document.getElementById("phone_message").innerHTML="This phone number is already exist";
                return;
            }else{
                document.getElementById("phone_message").innerHTML="";
                return;
            }
       }
  }
  });
 }
</script>

<script>
        // $(document).ready(function(){
            
            // $('#province').change(function(){ 
            //     var id=$(this).val();
            //     $.ajax({
            //         url : "<?php echo site_url('Admin/get_region_category_by_province');?>",
            //         method : "POST",
            //         data : {id: id},
            //         async : true,
            //         dataType : 'json',
            //         success: function(data){
            //             var html = '';
            //             var i;
            //             for(i=0; i<data.length; i++){
            //                 html += '<option value='+data[i].zone_id+'>'+data[i].zone_name+'</option>';
            //                 $('#postal_code').val(data[i].postal_code);
            //             }
            //             $('#region').html(html);
                        
            //         }
            //     });
            // }); 
            // $.ajax({
            // url : "<?php echo site_url('Admin/client_list_ajx');?>",
            //         method : "POST",
            //         async : true,
            //         dataType : 'json',
            //         success: function(data){
            //             var html = '';
            //             var i;
            //             for(i=0; i<data.length; i++){
            //                 $("#client").append('<option value='+data[i].client_id+'>'+data[i].client_name+'</option>');
            //                 //html += '<option value='+data[i].client_id+'>'+data[i].client_name+'</option>';
            //             }
            //             $('#client').multiselect({
            //             includeSelectAllOption: true,
            //             buttonWidth: 500,
            //             enableFiltering: true,
            //             selectAll: true
            //         });
                    
            //         }
            // });
			
// 			$('#region').change(function(){ 
//                 var id=$(this).val();
//                 $.ajax({
//                     url : "<?php echo site_url('Admin/get_fsa_by_zone');?>",
//                     method : "POST",
//                     data : {id: id},
//                     async : true,
//                     dataType : 'json',
//                     success: function(data){
//                         for(i=0; i<data.length; i++){
//                             $('#postal_code').val(data[i].postal_code);
//                         }
//                     }
//                 });
//             }); 
// 			$('#phone_no1').mask('000-000-0000');
			
			
        // });
    </script>
 <?php include_once('footer.php'); ?>         

              