<?php include_once('header.php'); ?>
<body>



<div class="content">
   	
  <div class="container">
 		<h3 class="gold-underline">MODULES</h3>
 		 		
    <div class="row">
      <div class="col-3 lost">
		 <a href="<?php echo site_url('Product/product_master'); ?>">
		         	<img src="../../assets/img/pa.png">
      	<p>Product Master</p></a>
      </div>
	  
	   <div class="col-3 lost">
	 
		 <a href="<?php echo site_url('User_reg/user_master'); ?>">
		 <img src="../../assets/img/us.png">
      	<p>Users</p></a>
        </div>
		
		<div class="col-3 lost">
		 <a href="<?php echo site_url('User_reg/user_accesss'); ?>">
		 <img src="../../assets/img/pe.png">
      	<p>Users Log</p></a>
		
      </div>
	  
	   <div class="col-3 lost">
		 <a href="<?php echo site_url('Report/report_module'); ?>">
		 <img src="../../assets/img/rp.png">
      	<p>Reports</p></a>
        </div>
      
	  
      </div>
      <!--&-->
     <!-- <div class="row">
        <div class="col-3 lost">
	       <a href="<?php echo site_url('Stock/product_sale'); ?>">
	       <img src="../../assets/img/sl.png">
  	       <p>Sale</p></a>
        </div>
          
      <div class="col-3 lost">
		 <a href="<?php echo site_url('Stock/product_replace'); ?>">
		         	<img src="../../assets/img/sw.png">
      	<p>Product Replace(Swap)</p></a>
      </div>
      
        <div class="col-3 lost">
		 <a href="<?php echo site_url('Report/report_module'); ?>">
		 <img src="../../assets/img/rp.png">
      	<p>Reports</p></a>
        </div>
      
       <div class="col-3 lost">
		 <a href="<?php echo site_url('Lead_followup/lead_followup_master'); ?>">
		         	<img src="../../assets/img/fu.png">
      	<p>Lead Follow Up</p></a>
      </div>
      
      </div>
      
    <div class="row">
	
	 
	<?php if($admin ==2){?>
	 <div class="col-3 lost">
	 
		 <a href="<?php echo site_url('User_reg/user_master'); ?>">
		 <img src="../../assets/img/report_4.png">
      	<p>Users</p></a>
        </div>
      
      <div class="col-3 lost">
		 <a href="<?php echo site_url('User_reg/user_accesss'); ?>">
		 <img src="../../assets/img/report_4.png">
      	<p>Users Log</p></a>
		
      </div>
      
     <?php }else{?>
	  
	 
      
    </div>
      <?php }?>//-->
    </div>
</div>
</body>
<?php include_once('footer.php'); ?>