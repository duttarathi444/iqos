<html>
    
<?php include_once('header.php'); ?>
<body>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>

<script>

$(document).ready(function(){
  $('#CompanyPhone').mask('000-000-0000');
  $('#CompanyFax').mask('000-000-0000');
  $('#client_telephone1').mask('000-000-0000');
  $('#client_telephone2').mask('000-000-0000');
});
</script>
    
    <script>
        
        function select_prod(num){
    if(num == 1){
        var e = document.getElementById('cus_email');
        var val = e.options[e.selectedIndex].value;
        var url = "http://purpuligo.com/iqos/index.php/Stock/all_customer";
    }else if(num == 2){
        var e = document.getElementById('prod_name');
        var val = e.options[e.selectedIndex].value;
        var url = "http://purpuligo.com/iqos/index.php/Stock/all_product_list";
    }
    $.ajax({
                    url : url,
                    method : "POST",
                    data : {cus_id: val},
                    async : true,
                    dataType : 'json',
                    success: function(data){
                        if(num == 1){
                        document.getElementById('cus_name').value = data[0].f_name+' '+data[0].l_name;
                        document.getElementById('cus_phone').value = data[0].ph_no;
                        document.getElementById('postal').value = data[0].postal_code;
                        if(Object.keys(data[0]).length > 4){
                            document.getElementById('god_father_name').value = data[0].p_f_name+' '+data[0].p_l_name;
                            document.getElementById('god_father_email').value = data[0].p_mail;
                            document.getElementById('god_father_phone').value = data[0].p_ph;
                        }else{
                            document.getElementById('god_father_name').value = '';
                            document.getElementById('god_father_email').value = '';
                            document.getElementById('god_father_phone').value = '';
                        }
                        }else if(num == 2){
                            var valid2=data[0].product_type.substring(0,4).toLowerCase()=='iqos';
                            
                            document.getElementById('prod_color').value = data[0].product_colr;
                            document.getElementById('prod_code').value= data[0].product_code;
                            document.getElementById('prod_type').value= data[0].product_type;
                            if(valid2){
                                document.getElementById('prod_serial').value="";
                                document.getElementById('prod_serial').readOnly=false;
                            }else{
                                document.getElementById('prod_serial').value="";
                                document.getElementById('prod_serial').readOnly=true;
                            }
                        }
                    }
                    });
}
        prod_bar
    </script>
    
<div class="content">

	
  <div class="container">
    <h3 class="gold-underline">Product Swap Details</h3>
    
    
  <!--   <div class="content">-->
  <!--<div class="container">-->
       <?php 
		   if(!empty($sale_products_data))
							
							{
						?>
        
      <a id="back2Top" title="Back to top" href="#">&#10148;</a>
    <h3 class="gold-underline">Existing Product Details</h3>
          <form name="driver_add" action="replace_new_product" method="post" enctype="multipart/form-data">
	        <div class="form-row">
              <div class="col-md-2 mb-2">
               <label for="validationPrimaryEmail"> Product sale Date</label>
                <div class="input-group">
                  <input type="date" class="form-control" value="<?php echo $sale_products_data[0]['prd_sale_date'];?>"
id="select_date" name="select_date"  readonly required>
               </div>
             </div>
             
             <div class="col-md-3 mb-3">
               <label for="validationPrimaryEmail">Customer Email</label>
             <input type="text" class="form-control" name="phone_no" value="<?php echo $sale_products_data[0]['mail_id'];?>" id="god_father_email" readonly placeholder="God Father Email" >
             </div>
             
             <div class="col-md-2 mb-3">
               <label for="validationPrimaryEmail">Customer Name</label>
                <div class="input-group">
                <input type="text" class="form-control" id="cus_name" value="<?php echo $sale_products_data[0]['f_name'].' '.$sale_products_data[0]['l_name'];?>" name="customer_name" readonly placeholder="Customer Name" >
               </div>
             </div>
             
                <div class="col-md-2 mb-3">
               <label for="validationPrimaryEmail">Customer Phone No</label>
                <div class="input-group">
                <input type="text" class="form-control" name="phone_no" value="<?php echo $sale_products_data[0]['ph_no'];?>" id="cus_phone" readonly  placeholder="Phone No" >
               </div>
             </div>
             
                <div class="col-md-3 mb-2">
               <label for="validationPrimaryEmail">Customer Postal Code</label>
                <div class="input-group">
                <input type="text" class="form-control" name="postal_code" value="<?php echo $sale_products_data[0]['postal_code'];?>" id="postal" readonly placeholder="Postal Code" >
               </div>
             </div>
           </div>
           
    
           
          
           	<div class="form-row">
              <div class="col-md-3 mb-3">
               <label for="validationPrimaryEmail">God Father Name</label>
                <div class="input-group">
                <input type="text" class="form-control" id="god_father_name" value="<?php echo $sale_products_data[0]['fname'].' '.$sale_products_data[0]['lname'];?>" name="customer_name" readonly placeholder="God Father Name" >
               </div>
             </div>
             
             <div class="col-md-3 mb-2">
               <label for="validationPrimaryEmail">God Father Email</label>
                <div class="input-group">
                <input type="text" class="form-control" name="phone_no" value="<?php echo $sale_products_data[0]['email'];?>" id="god_father_email" readonly placeholder="God Father Email" >
               </div>
             </div>
             
             <div class="col-md-3 mb-3">
               <label for="validationPrimaryEmail">God Father Phone No</label>
                <div class="input-group">
                <input type="text" class="form-control" name="postal_code" value="<?php echo $sale_products_data[0]['phone_no'];?>" id="god_father_phone" readonly placeholder="God Father Phone No" >
               </div>
             </div>
             
              <div class="col-md-3 mb-2">
               <label for="validationPrimaryEmail">God Father Postal Code</label>
                <div class="input-group">
                <input type="text" class="form-control" name="postal_code" value="<?php echo $sale_products_data[0]['postal_code'];?>" id="god_father_phone"readonly  placeholder="God Father Phone No" >
               </div>
             </div>
           </div>
           
			   
		<div class="form-row">
             <div class="col-md-3 mb-3">
               <label for="validationPrimaryEmail">Product Name</label>
            <input type="text" class="form-control" name="postal_code" value="<?php echo $sale_products_data[0]['product_name'];?>"  id="god_father_phone" readonly placeholder="God Father Phone No" >
             </div>
             
                   <div class="col-md-3 mb-3">
               <label for="validationPrimaryEmail">Product Color</label>
                <div class="input-group">
                  <input type="type" class="form-control"  value="<?php echo $sale_products_data[0]['product_colr'];?>" placeholder="Product Color" readonly name="product_color">
               </div>
            </div>

        <div class="col-md-3 mb-2">
               <label for="validationPrimaryEmail">Barcode</label>
                <div class="input-group">
                <input type="text" class="form-control"  value="<?php echo $sale_products_data[0]['product_code'];?>"  name="serial_no" placeholder="Serial Number" readonly>
               </div>
             </div>
             
           	      <div class="col-md-3 mb-2">
               <label for="validationPrimaryEmail">Product Type</label>
                <div class="input-group">
                <input type="text" class="form-control"  value="<?php echo $sale_products_data[0]['product_type'];?>"  name="serial_no" placeholder="Serial Number" readonly>
               </div>
             </div>
             </div>
             
             
           	<div class="form-row"> 
              <div class="col-md-3 mb-2">
               <label for="validationPrimaryEmail">Serial Number</label>
                <div class="input-group">
                <input type="text" class="form-control"  value="<?php echo $sale_products_data[0]['serial_no'];?>" name="serial_no" placeholder="Serial Number" readonly>
               </div>
             </div>
             
          
             
             <div class="col-md-3 mb-2">
               <label for="validationPrimaryEmail">SAP Order No</label>
                <div class="input-group">
                <input type="text" class="form-control" name="sap_no" id="sap_no" value="<?php echo $sale_products_data[0]['sap_order_no'];?>" placeholder="SAP Order No" readonly>
               </div>
             </div>
             
   

          
            
            
             <div class="col-md-3 mb-3">
               <label for="validationPrimaryEmail">Device Registered</label>
            <input type="text" class="form-control"  value="<?php echo ($sale_products_data[0]['device_reg']==1)? 'Yes':'No';?>"id="res_dat"  name="registation_date" readonly required>
       
             </div>
             
             <div class="col-md-3 mb-3">
               <label for="validationPrimaryEmail">Device Registered Date</label>
                <div class="input-group">
                  <input type="date" class="form-control" value="<?php echo $sale_products_data[0]['device_reg_date'];?>" name="registation_date" readonly required>
               </div>
            </div>
           
           </div>
           
              <h3 class="gold-underline">New Product Details</h3>
            
             <?php } ?>
             </form>
<!--</div>-->
<!--</div>-->

<table>
    
<thead>
    <tr>
        
        <td width="10%"><b>Swap Date</b></td>
        
        <td width="10%"><b>Product Name</b></td>
		
		<td width="10%"><b>Product Color</b></td>
		
		<td width="10%"><b>Product Type</b></td>
		
		<td width="10%"><b>Barcode</b></td>
		
		<td width="10%"><b>Registation Date</b></td>
		
		<td width="10%"><b>New Serial No</b></td>
		
		<td width="10%"><b>Glove Service No</b></td>
		
    </tr>
</thead>
<tbody>
						    
<?php 
		   if(!empty($swap_list))
							
							{
								foreach($swap_list as $swap_sdata){
								    if($swap_sdata['swap_flag']!=1){
						?>
						
					<tr>
					    
				    <td width="10%" ><?php echo $swap_sdata['swap_date'];?></td>
						        
						<td width="10%" height="50"><?php echo $swap_sdata['product_name'];?></td>
						
						<td width="10%"><?php echo $swap_sdata['product_colr'];?></td>
						
						<td width="10%"><?php echo $swap_sdata['product_type'];?></td>
						
						<td width="10%"><?php echo $swap_sdata['product_code'];?></td>
						
						<td width="10%"><?php echo $swap_sdata['date'];?></td>
						
						<td width="10%"><?php echo $swap_sdata['new_serial_number'];?></td>
						
						<td width="10%"><?php echo $swap_sdata['wgs_no'];?></td>
						
						</tr>
						
						
						
						</tbody>
						<?php }else{?>
						</table>
						
				<div class="gold-underline"></div>		
			<form name="swap_product_update" action="swap_update" method="post">			
			<div class="form-row">
             <div class="col-md-3 mb-3">
               <label for="validationPrimaryEmail">Product Name</label>
                <select name="product_id" id="prod_name" class="form-control" onchange=select_prod(2)>
                    <option selected="" value="<?php echo $swap_sdata['product_id'];?>"><?php echo $swap_sdata['product_name'];?></option>
                    <?php if($product_list){foreach($product_list as $p_list){ ?>
                    <option value="<?php echo $p_list['product_id']; ?>"><?php echo  $p_list['product_name'];?></option>
                    <?php }}?>
                  </select>
             </div>
             
             <div class="col-md-3 mb-3">
               <label for="validationPrimaryEmail">Product Color</label>
                <div class="input-group">
                  <input type="type" class="form-control" id="prod_color" value="<?php echo $swap_sdata['product_colr'];?>" placeholder="Product Color"  name="product_color" readonly>
               </div>
            </div>
            
               
             <div class="col-md-2 mb-3">
               <label for="validationPrimaryEmail">Barcode</label>
                <div class="input-group">
                  <input type="type" class="form-control" id="prod_code" value="<?php echo $swap_sdata['product_code'];?>" placeholder="Product Code"  name="product_color"readonly>
               </div>
            </div>
            
                  
             <div class="col-md-3 mb-3">
               <label for="validationPrimaryEmail">Product Type</label>
                <div class="input-group">
                  <input type="type" class="form-control" id="prod_type" value="<?php echo $swap_sdata['product_type'];?>" placeholder="Product Type"  name="product_color" readonly>
               </div>
            </div>
            
            <!--<div class="col-md-2 mb-3">-->
            <!--   <label for="validationPrimaryEmail">Product Serial No</label>-->
            <!--    <div class="input-group">-->
            <!--      <input type="type" name="prod_bar" class="form-control" id="prod_bar" value="<?php echo $swap_sdata['prd_barcode'];?>" placeholder="Serial No" <?php if(strtolower(substr($swap_sdata['product_type'],0,4))!='iqos') echo "readonly ";?>>-->
            <!--   </div>-->
            <!--</div>-->
            
            <!--<input type="hidden" name="prod_bar" value="" id="bar_prd">-->
            
            <!--<div class="col-md-2 mb-3">-->
            <!--   <label for="validationPrimaryEmail">Quantity</label>-->
            <!--    <div class="input-group">-->
            <!--      <input type="type" class="form-control" id="prod_qty" value="<?php echo $swap_sdata['product_quantity'];?>" onchange="check_qty()" placeholder="Quantity"  name="product_quantity" readonly>-->
            <!--   </div>-->
            <!--</div>-->
            <input type="hidden" name="product_quantity" value="1">
            
            <input type="hidden" id="swap_id" name="swap_id" value="<?php echo $swap_sdata['id'];?>">
            
             <div class="col-md-3 mb-3">
               <label for="validationPrimaryEmail">White Glove Service No</label>
                <div class="input-group">
                  <input type="text" class="form-control" id="" name="glove" value="<?php echo $swap_sdata['wgs_no'];?>" placeholder="White Glove Service No" required>
               </div>
            </div>
              
            
              <div class="col-md-3 mb-3">
               <label for="validationPrimaryEmail">New Serial Number</label>
                <div class="input-group">
                  <input type="type" class="form-control" id="prod_serial" name="serial_num" value="<?php echo $swap_sdata['new_serial_number'];?>" <?php if(strtolower(substr($swap_sdata['product_type'],0,4)) != 'iqos') echo "readonly ";?> placeholder="Serial No">
               </div>
            </div>
           
           
           
             <div class="col-md-2 mb-3">
               <label for="validationPrimaryEmail">Device Registered</label>
              <select name="res_valid" onchange="valid()" id="res_validation" class="form-control">
                    <option value="<?php echo $swap_sdata['device_reg']?>" selected><?php echo ($swap_sdata['device_reg']==1)? 'Yes':'No';?></option>
                    <option value=1>Yes</option>
                    <option value=0>No</option>
                  </select>
            </div>
            
             <div class="col-md-2 mb-3">
               <label for="validationPrimaryEmail">Device Registered Date</label>
                <div class="input-group">
                  <input type="date" class="form-control" value="<?php echo $swap_sdata['date'];?>" id="res_date" <?php if($swap_sdata['device_reg']!=1)echo "readonly" ;?> name="registation_date" required>
               </div>
            </div>
            
              <div class="col-md-2 mb-3">
               <label for="validationPrimaryEmail">Swap date</label>
                <div class="input-group">
                  <input type="date" class="form-control" id="res_date" value="<?php echo $swap_sdata['swap_date'];?>" name="swap_date" required>
               </div>
            </div>
            
            </div>
            
            
						<?php }}}?>
			
			
			<input type="button" class="btn btn-secondary  btn-lg my-2 " id="agback" value="Back"  onclick="location.href='<?php echo base_url();?>index.php/Stock/product_replace'" />
                
                <input type="submit" class="btn btn-success  btn-lg my-2 pull-left" id="auto_click" value="Submit"/>
            </form>
  
            </div>   
          </div>  
                
                
    
</div>
<script>
    function valid(){
    var e = document.getElementById('res_validation');
    var val = e.options[e.selectedIndex].value;
    console.log(val);
    if(val == 1)
    $('#res_date').removeAttr('readonly');
    else
    $('#res_date').attr('readonly', true);
    document.getElementById('res_date').value='';
    }
    // function repl(){
    //     var bar=document.getElementById('prod_bar1').value;
    //     document.getElementById('bar_prd').value=bar;
    // }
</script>
 <?php include_once('footer.php'); ?>         
