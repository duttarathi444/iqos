<?php include_once('header.php'); ?>
<body>



<div class="content">
   	
  <div class="container">
 		<h3 class="gold-underline">REPORT MODULES</h3>
 		 		
    <div class="row">
   <!--   <div class="col-3 module">-->
   <!-- 	<img src="../../assets/img/Invoice.png">-->
   <!--<?php echo site_url('Product/product_master'); ?>-->
		 <!--<a href="">-->
   <!--   	<h3>PRODUCT MASTER</h3>-->
   <!--   </div>-->
	  <div class="col-3 lost last">
        <a href="<?php echo site_url('Report/product_stock_report'); ?>">
                    <img src="../../assets/img/ps.png">
      	<p>Product stock reports</p></a>
      </div>
	  <div class="col-3 lost">
		 <a href="<?php echo site_url('Report/product_stock_movement'); ?>">
		         	<img src="../../assets/img/rp.png">
      	<p>Product stock movements</p></a>
      </div>
       <div class="col-3 lost">
		 <a href="<?php echo site_url('Report/pe_dealer_module'); ?>">
		         	<img src="../../assets/img/pe.png">
      	<p>P.E Reports</p></a>
      </div>
       <div class="col-3 lost">
		 <a href="<?php echo site_url('Report/customer_reports'); ?>">
		         	<img src="../../assets/img/cr.png">
      	<p>Customer Reports</p></a>
      </div>

      </div>
    </div>
</div>
  <!--  <div id="" class="btn-group" role="group" aria-label="Basic example">-->
		<!--<input type="button" class="btn btn-secondary btn-lg my-2 pull-left" id="backk" value="Back" onclick="location.href='<?php echo base_url();?>index.php/Admin/product_module'" />-->
  <!--  </div>-->
</body>
<?php include_once('footer.php'); ?>