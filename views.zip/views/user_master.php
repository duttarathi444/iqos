<html>
<?php include_once('header.php'); ?>

   <link  href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css" rel="stylesheet" />
    <link href="https://cdn.datatables.net/buttons/1.6.0/css/buttons.dataTables.min.css" rel="stylesheet" />
    <script src="https://code.jquery.com/jquery-3.3.1.js"></script>
    <script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.6.0/js/dataTables.buttons.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.6.0/js/buttons.colVis.min.js"></script>
    
<body>
   <script>
function goBack() {
  window.history.back();
}
</script>
<style>
.button2 {background-color: #4CAF50;} /* Blue */
.button3 {background-color: #f44336;} /* Red */ 
</style>

    <script>
    
    $(document).ready(function() {
    $('#example').DataTable( {
        dom: 'Bfrtip',
        columnDefs: [
            {
                targets: 1,
                className: 'noVis'
            }
        ],
        buttons: [
            {
                extend: 'colvis',
                columns: ':not(.noVis)'
            }
        ],
        scroll:true,
        "order": [[ 0, "desc" ]]
    } );
    $("#back").click(function(){
        $("#c2").submit()
        
    });
    
} );


        
        function modi(c_id)
        {
            document.getElementById("user_d_id").value = c_id;
            document.getElementById("c2").submit();
        }
        
        function user_update(d_id)
        {
			document.getElementById("user_details_id").value = d_id;
            document.getElementById("c3").submit();
            
        }
        
        function user_delete(c_id)
        {
            var conirm_delete = confirm("You are about  to Delete User Id "+c_id+ " . Please confirm ?")
            if (conirm_delete == true) { 
                document.getElementById("user_id2").value = c_id;
                document.getElementById("c4").submit();
            } else { 
                return;
            } 
            
        }
        
          function modiy(d_id)
        {
            document.getElementById("user_id3").value = d_id;
            document.getElementById("c5").submit();
        }

    
</script>
<form name="c2" id="c2" action="user_view" method="post">
    <input type="hidden" id="scan_id2" name="scan_id2" />
</form>
<!--<form name="c4" id="c4" action="user_delete" method="post">
    <input type="hidden" id="user_id2" name="user_id2" />
</form>//-->

<form name="c3" id="c3" action="user_master_status_update" method="post">
 <input type="hidden" id="user_details_id" name="user_details_id" />
</form>
<form name="c5" id="c5" action="user_edit1" method="post">
    <input type="hidden" id="user_id3" name="user_id3"/>
</form>

<form name="agent_list"  method="post">
<div class="content">
  <div class="container">
      <a id="back2Top" title="Back to top" href="#">&#10148;</a>
   <h3 class="gold-underline">User List</h3>
   
   <div class="btn-group" role="group" aria-label="Basic example">
   <!-- <input type="button" class="btn btn-primary pull-left" value="New User"  onclick="user_reg()" />
   <input type="button" class="btn btn-success  btn-lg my-2 pull-left" id="auto_click" value="New User" onclick="user_reg()"/>//-->
   </div>
   
   <div>
    
   </div>
   <?php if($alert_flag ==1){?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">

        <button type="button" class="close" data-dismiss="alert"  aria-label="Close">
        <span aria-hidden="true">&times;</span>
        </button>
		        <?php echo $alert_message;?>
    </div>
	
	
	
    <?php } ?>
  
        
  
       
  
  
  
<table id="example" class="display" >
  <thead>
            <tr>
                <th>User ID</th>
                <th>User Name</th>
                <th>E-mail</th>
                <th>Phone No</th>
				 <th>Address</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            
            <?php if($user_master_list){
                  foreach($user_master_list as $user_list){ ?>
            <tr>
                <td><?php echo $user_list['user_details_id'];?></td>
                <td><?php echo $user_list['user_name'];?></td>
                <td><?php echo $user_list['email_id'];?></td>
                <td><?php echo $user_list['phone_number'];?></td>
				<td><?php echo $user_list['address'];?></td>
                <td>
				<?php 	
						$admin =($user_list['status']);
						
						
							?>
			    <div class="btn-group">
				<?php if($admin == 0){?>
			        <input type="button"<?php if($admin =0 ){?> disabled <?php }?> class="button3" id="auto_click" value="Pending" onclick="user_update(<?php echo $user_list['user_details_id'];?>)"/>
				<?php }else{?>
					<input type="button" class="button2" id="auto_click" value="Approved"/>
				<?php }?>
			    </div>
			    </td>
            </tr>
            <?php }}?>
        </tbody>
    </table>
    <div class="btn-group" role="group" aria-label="Basic example">             
<input type="button" class="btn btn-secondary btn-lg my-2 pull-left" id="backk" value="Back" onclick="location.href='<?php echo base_url();?>index.php/Admin/product_module2'" />
</div>
</div>
  
<input type="hidden" name="code_idd" value="">
  
</div>
</form>
  
  
 <?php include_once('footer.php'); ?>  