<html>
    <head>
        <style>
    table{
        /*border: 1px solid black;*/
        width: 100%;
        margin-bottom: 20px;
		border-collapse: separate;
        /*border-spacing: 20 0px;*/
    }
    table td{
        text-align: left;
    }
    
    #preview{
    width:500px;
    height: 500px;
    margin:0px auto;
    }
    
    body {font-family: Arial, Helvetica, sans-serif;}

#myImg {
  border-radius: 5px;
  cursor: pointer;
  transition: 0.3s;
}

#myImg:hover {opacity: 0.7;}

/* The Modal (background) */
.modal {
  display: none; /* Hidden by default */
  position: fixed; /* Stay in place */
  z-index: 1; /* Sit on top */
  padding-top: 100px; /* Location of the box */
  left: 0;
  top: 0;
  width: 100%; /* Full width */
  height: 100%; /* Full height */
  overflow: auto; /* Enable scroll if needed */
  background-color: rgb(0,0,0); /* Fallback color */
  background-color: rgba(0,0,0,0.9); /* Black w/ opacity */
}

/* Modal Content (image) */
.modal-content {
  margin: auto;
  display: block;
  width: 80%;
  max-width: 700px;
}

/* Caption of Modal Image */
#caption {
  margin: auto;
  display: block;
  width: 80%;
  max-width: 700px;
  text-align: center;
  color: #ccc;
  padding: 10px 0;
  height: 150px;
}

/* Add Animation */
.modal-content, #caption {  
  -webkit-animation-name: zoom;
  -webkit-animation-duration: 0.6s;
  animation-name: zoom;
  animation-duration: 0.6s;
}

@-webkit-keyframes zoom {
  from {-webkit-transform:scale(0)} 
  to {-webkit-transform:scale(1)}
}

@keyframes zoom {
  from {transform:scale(0)} 
  to {transform:scale(1)}
}

/* The Close Button */
.close {
  position: absolute;
  top: 15px;
  right: 35px;
  color: #f1f1f1;
  font-size: 40px;
  font-weight: bold;
  transition: 0.3s;
}

.close:hover,
.close:focus {
  color: #bbb;
  text-decoration: none;
  cursor: pointer;
}

/* 100% Image Width on Smaller Screens */
@media only screen and (max-width: 700px){
  .modal-content {
    width: 100%;
  }
}
    
    </style>
    </head>
    
<?php include_once('header.php'); ?>
<body onload="dateput()">
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>

<script src="https://cdn.rawgit.com/serratus/quaggaJS/0420d5e0/dist/quagga.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/webrtc-adapter/7.3.0/adapter.min.js"></script>
<script
  src="https://code.jquery.com/jquery-3.4.1.min.js"
  integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo="
  crossorigin="anonymous"></script>

<script>
$(document).ready(function(){
  $('#CompanyPhone').mask('000-000-0000');
  $('#CompanyFax').mask('000-000-0000');
  $('#client_telephone1').mask('000-000-0000');
  $('#client_telephone2').mask('000-000-0000');
});
</script>

<script  type="text/javascript" language="javascript" >
function addAll(){
        var products=document.getElementsByName("product");
        //var barcodes=document.getElementsByName("barcode_no");
        var quantitys=document.getElementsByName("quantity");
        var rec_from=document.getElementById('receivded_from').value;
        var ship_from=document.getElementById('shipment_name').value;
        
var b=[];
//var c=[];
var d=[];
var j=0;
for(var i=0;i<products.length;i++){
	//var valid2=products[i].options[products[i].selectedIndex].text.substring(0,4).toLowerCase()=='iqos';
	var b1=products[i].value;
	//var c1=barcodes[i].value;
	var d1=quantitys[i].value;
	//if(valid2){
	if(b1!='' && d1!=''){
	b[j]=b1;
	//c[j]=c1;
	d[j]=d1;
	j++;
	}else{
	    alert('Fill Up All Details');
	    return false;
	}
// 	}else{
// 	    if(b1!='' && d1!=''){
// 	b[j]=b1;
// 	//c[j]=c1;
// 	d[j]=d1;
// 	j++;
// 	}else{
// 	    alert('Fill Up All Details');
// 	    return false;
// 	}
	}
document.getElementById("all-product").value=b;
//document.getElementById("all-barcode").value=c;
document.getElementById("all-quantity").value=d;
if(rec_from!='' && ship_from!=''){
document.getElementById("driver_add").submit();
}else{
    alert('Fill Up All Details');
}
}

function dateput(){
    var datenow=new Date(Date.now());
    var month=+datenow.getMonth()+1;
    if((month+"").length<2){
        month='0'+month;
    }
    var date='';
    if((datenow.getDate()+"").length<2){
        date= '0'+datenow.getDate();
    }
    var newdate = datenow.getFullYear()+'-'+month+'-'+date;
    document.getElementById('receive_date').value=newdate;
}

function check(){
    
    var datenow=new Date(Date.now());
    var car_id=datenow.getFullYear()+document.getElementById('carton_num').value;
    $.ajax({
                    url : "http://purpuligo.com/iqos/index.php/Stock/check_carton",
                    method : "POST",
                    data : {id: car_id},
                    async : true,
                    dataType : 'json',
                    success: function(data){
                        if(data[0].num > 0){
                            document.getElementById('cartom_message').innerHTML="This Carton No already Exist";
                        }else{
                            document.getElementById('cartom_message').innerHTML="";
                            document.getElementById('carton_no').value=car_id;
                            document.getElementById('auto_click').disabled=false;
                        }
                    }
    });
}

function order_by_occurrence(arr) {
  var counts = {};
  arr.forEach(function(value){
      if(!counts[value]) {
          counts[value] = 0;
      }
      counts[value]++;
  });

  return Object.keys(counts).sort(function(curKey,nextKey) {
      return counts[curKey] < counts[nextKey];
  });
}

function scanner_on(id){
    id.value="";
    var modal = document.getElementById("myModal");
    modal.style.display = "block";
    var span = document.getElementsByClassName("close")[0];
    
    if ($('#scanner-container').length > 0 && navigator.mediaDevices && typeof navigator.mediaDevices.getUserMedia === 'function') {

    var last_result = [];

    if (Quagga.initialized == undefined) {
      Quagga.onDetected(function(result) {
          last_result.push(result.codeResult.code);
        if (last_result.length > 20) {
          code = order_by_occurrence(last_result)[0];
          last_result = [];
          id.value=code;
          Quagga.stop();
          modal.style.display = "none";
        }
      });
    }

    Quagga.init({
      inputStream : {
        name : "Live",
        type : "LiveStream",
        numOfWorkers: navigator.hardwareConcurrency,
        target: document.querySelector('#scanner-container')
      },
      decoder: {
          readers : ['ean_reader','ean_8_reader','code_39_reader','code_39_vin_reader','codabar_reader','upc_reader','upc_e_reader']
      }
    },function(err) {
        if (err) { console.log(err); return }
        Quagga.initialized = true;
        Quagga.start();
    });

  }
    
    span.onclick = function() {
        modal.style.display = "none";
        Quagga.stop();
    }
    
}

function select_prod(id){
    //var val= id.options[id.selectedIndex].innerHTML;
    var val1= id.options[id.selectedIndex].value;
    var thisorder=$(id).parents('tr');
    var tds=thisorder.find('td');
    //var bar=tds.find('input[id="barcode_no"]')[0];
    var prd_code=tds.find('input[id="prd_code"]')[0];
    var prd_type=tds.find('input[id="prd_type"]')[0];
    var prd_color=tds.find('input[id="prd_color"]')[0];
    var productdata=trdData(val1);
    // if(val.substring(0,5).toLowerCase().trim()=='iqos'){
    //     bar.disabled=false;
    // }else{
    //     bar.value="";
    //     bar.disabled=true;
    // }
    productdata
    .then(p=>{
        prd_code.value=p[0].product_code;
        prd_type.value=p[0].product_type;
        prd_color.value=p[0].product_colr;
    })
}

async function trdData(val1){
    const result = await $.ajax({
                    url : "http://purpuligo.com/iqos/index.php/Stock/all_product_show",
                    method : "POST",
                    data : {cus_id: val1},
                    async : true,
                    dataType : 'json'
    });
    return result
}

window.pressed = function(b,a){
  var input = b.target;
  console.log(a);
  var reader = new FileReader();
    var temp = a.name[a.name.length-1];
    var im = document.getElementById('im'+temp);
    var a1 = document.getElementById('fileLabel'+temp);
    if(a.value == "")
    {
        a1.innerHTML = "Choose file";
    }
    else
    {
        var theSplit = a.value.split('\\');
        a1.innerHTML = theSplit[theSplit.length-1];

        reader.onload = function(){
      var dataURL = reader.result;
      im.src = dataURL;
    };
    reader.readAsDataURL(input.files[0]);

    }
};

</script>

<div id="myModal" class="modal">
    <span class="close">&times;</span>
<center><div id="scanner-container"></div></center>
</div>

<div class="content">
  <div class="container">
      <a id="back2Top" title="Back to top" href="#">&#10148;</a>
        <h3 class="gold-underline">Add New Stock</h3>
        
        <!--action="stock_in" method="post"-->

         <form name="driver_add" id="driver_add" action="stock_in" method="post" enctype="multipart/form-data">	
	    
	    `       <div class="form-row">
                    <div class="col-md-3 mb-3">
                        <label for="validationPrimaryEmail">Carton Number</label>
                        <div class="input-group">
                            <input type="text" class="form-control" id="carton_num" placeholder="Carton Number" onchange="check()" required>
                        </div>
                        <span style="color:red" id="cartom_message"></span>
                </div>
                
                <input type="hidden" name="carton_no" id="carton_no">
           
              <div class="col-md-3 mb-3">
               <label for="validationPrimaryEmail">Received From</label>
                <div class="input-group">
                <input type="text" class="form-control" name="receivded_from" id="receivded_from" required="" placeholder="Received Name" aria-describedby="inputGroupPrepend2">
               </div>
             </div>
             
             <div class="col-md-2 mb-3">
               <label for="validationPrimaryEmail">Shipment Name</label>
                <div class="input-group">
                <input type="text" class="form-control" name="shipment_name" id="shipment_name" required="" placeholder="Shipment Name" aria-describedby="inputGroupPrepend2">
               </div>
             </div>
             
             <div class="col-md-2 mb-3">
               <label for="validationPrimaryEmail">Received Date</label>
                <div class="input-group">
                  <input type="date" class="form-control" id="receive_date" value="" name="receive_date" required>
               </div>
             </div>
             
             <div class="col-md-2 mb-3">
              <label for="validationDefault02">Document</label><br>
              <input type='file' onchange="pressed(event,this)" style="color: transparent; width: 100px;" accept=".png, .jpg, .jpeg" name="image1" value="Choose file"><br>

              <span id="fileLabel1">Choose file</span>
            </div>
             
           </div>
           
           </div>
            
            <div class="container">
              <h4>Enter Item Details Below </h4>
            <table style="width: 100%;">
                <tbody>
                    <tr>
                        <td style="text-align: center;padding-bottom: 15px; padding-left:15px;">
                            <input type="hidden" name="record">
                        </td>
                <td>
                <div class="form-row">
                    <div class="col col-md-3">
                      <label for="inputState">Product Name</label>
                      <select name="product" id="product" class="form-control" onchange=select_prod(this)>
                          <option selected="" value="">Select the Product</option>
                          <?php if($product_master_list){foreach($product_master_list as $p_list){ ?>
        
                        <option value="<?php echo $p_list['product_id']; ?>"><?php echo  $p_list['product_name'];?></option>
                        <?php }}?>
                      </select>
                    </div>
                    
                    <div class="col col-md-2">
                      <label for="inputState">Barcode</label>
                      <input type="text" class="form-control" name="prd_code" id="prd_code" readonly placeholder="Product Barcode" required="">
                    </div>
                    
                    <div class="col col-md-2">
                      <label for="inputState">Product Type</label>
                      <input type="text" class="form-control" name="prd_type" id="prd_type" readonly placeholder="Product Type" required="">
                    </div>
                    
                    <div class="col col-md-2">
                      <label for="inputState">Product Color</label>
                      <input type="text" class="form-control" name="prd_color" id="prd_color" readonly placeholder="Product Color" required="">
                    </div>
                
                    <!--<div class="col col-md-2">-->
                    <!--  <label for="inputState">Barcode No</label>-->
                    <!--  <input type="text" disabled class="form-control" name="barcode_no" id="barcode_no" value="" placeholder="Barcode No" required="">-->
                    <!--</div>-->
                <!--onclick="scanner_on(this)"-->
                    <div class="col col-md-2">
                      <label for="validationDefault03">Product Quantity</label>
                      <input type="text" class="form-control" name="quantity" id="quantity" placeholder="Quantity" required="">
                    </div>
                </div>
                    </td>
                </tr>
            </tbody>
        </table>

        <table>
            <tbody id="second_table">
                
			</tbody>
        </table>  
           
        <input type="hidden" name="al-products" id="all-product" value="">
		<input type="hidden" name="al-barcodes" id="all-barcode" value="">
		<input type="hidden" name="al-quantities" id="all-quantity" value="">
           
           
          
        <div class="btn-group" role="group" aria-label="Basic example">
    		<input type="button" class="btn btn-secondary btn-lg my-2 pull-left" id="backk" value="Back" onclick="location.href='<?php echo base_url();?>index.php/Stock/stock_master'"/>
    		
    		<input type="button" class="btn btn-success  btn-lg my-2 pull-left" id="add-row" value="Add Row">
    		
    		<button type="button" class="btn btn-success  btn-lg my-2 pull-left" id="delete-row">Delete Row</button>
    		
    		<input type="button" class="btn btn-success  btn-lg my-2 pull-left" id="auto_click" disabled onclick="addAll();" value="Submit"/>
		</div>
           <input type="hidden" id="TS" name="TS" value="<?php echo time();?>" />
        </form>  
                
    </div>
</div>


<script type="text/javascript">
    $(document).ready(function(){
        $("#add-row").click(function(){
            var markup = `<tr>
                <td style="text-align: center;padding-bottom: 40px; padding-left:-20px;">
                <input type="checkbox" name="record">
                </td>
                <td>
                <div class="form-row">
                <div class="col col-md-3">
                  <select name="product" id="product" class="form-control" onchange=select_prod(this)>
                  <option selected="" value="">Select the Product</option>
                       <?php if($product_master_list){foreach($product_master_list as $p_list){ ?> 
    
                    <option value="<?php echo $p_list['product_id']; ?>"> <?php echo  $p_list['product_name'];?> </option>
                     <?php }}?> 
                  </select>
                </div>
                
                <div class="col col-md-2">
                      <input type="text" class="form-control" name="prd_code" id="prd_code" readonly placeholder="Product Barcode" required="">
                    </div>
                    
                    <div class="col col-md-2">
                      <input type="text" class="form-control" name="prd_type" id="prd_type" readonly placeholder="Product Type" required="">
                    </div>
                    
                    <div class="col col-md-2">
                      <input type="text" class="form-control" name="prd_color" id="prd_color" readonly placeholder="Product Color" required="">
                    </div>
                
                <div class="col col-md-2">
                  <input type="text" class="form-control" name="quantity" id="quantity" placeholder="Quantity" required="">
                </div>
                </div>
                </td>
            </tr>`;
            $("#second_table").append(markup);
        });
        
        // Find and remove selected table rows
        $("#delete-row").click(function(){
            $("table tbody").find('input[name="record"]').each(function(){
            	if($(this).is(":checked")){
                    $(this).parents("tr").remove();
                }
            });
        });
    });    

</script>
    
 <?php include_once('footer.php'); ?>         

              