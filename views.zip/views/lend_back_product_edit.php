<html>
    <head>
        <style>
  /*  table{*/
        /*border: 1px solid black;*/
  /*      width: 100%;*/
  /*      margin-bottom: 20px;*/
		/*border-collapse: separate;*/
        /*border-spacing: 20 0px;*/
  /*  }*/
  /*  table td{*/
  /*      padding: 2px;*/
  /*      text-align: left;*/
  /*  }*/
    </style>
    </head>
    
<?php include_once('header.php'); ?>
<body onload="putdate()">
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>

<script>
$(document).ready(function(){
  $('#CompanyPhone').mask('000-000-0000');
  $('#phone_no').mask('000-000-0000');
  $('#client_telephone1').mask('000-000-0000');
  $('#client_telephone2').mask('000-000-0000');
//   $('#message').hide();
});
</script>

<script  type="text/javascript" language="javascript" >

function addAll(){
var b=[];
var e=[];
var f=[];
var g=[];
        var products_id=document.getElementsByName("product_id");
        var return_date=document.getElementsByName("return_date");
        var r_quantity=document.getElementsByName("return_qty");
        var expect_date=document.getElementsByName("res_date");
        
        var p_record=document.getElementsByName("record");

var j=0;
for(var i=0;i<p_record.length;i++){
	
	var b1=products_id[i].value;
	var f1=r_quantity[i].value;
	var e1=return_date[i].value;
	var g1=expect_date[i].value;
	if(p_record[i].checked==true){
	if(b1 != '' && f1 != '' && e1 != ''){
	b[j]=b1;
	f[j]=f1;
	e[j]=e1;
	g[j]=g1;
	j++;
	}else{
	    alert('Fill Up all the Details');
	    return false;
	}
	}
}

document.getElementById("all-product").value=b;
document.getElementById("all-quantity").value=f;
document.getElementById("all-return_date").value=e;
document.getElementById("expected-return_date").value=g;

    document.forms['lend_back'].submit();
}

</script>
<script>
function check(id){
    var quantity= id.value;
    var thisorder = $(id).parents('tr');
    var tds = thisorder.find("td");
    var pre_stock=tds.find('input[id="quantity"]')[0].value;
    if(+quantity<0){
        id.value="";
        id.placeholder=`Minimum Amount 0`;
    }else{
    if(+quantity > +pre_stock || (/[!@#$%^&*(),.?":{}|<>]/g.test(quantity)==true)){
        id.value="";
        id.placeholder=`${pre_stock}`;
    }
    }
}

</script>

<div class="content">
  <div class="container">
      <a id="back2Top" title="Back to top" href="#">&#10148;</a>
    <h3 class="gold-underline">Product Lend Back</h3>
        
  <!--      <div class="alert alert-success alert-dismissible" id="message">-->
  <!--<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>-->
  <!--<center><p>Fill Up all the Details</p></center>-->
  <!--</div>-->

          <form name="lend_back" action="lend_back_data?a=<?php echo $secure_code; ?>" method="post" enctype="multipart/form-data">	
	    
	     <div class="form-row">
	         
              <div class="col-md-3 mb-3">
               <label for="validationPrimaryEmail">Lend Date</label>
                <div class="input-group">
                  <input type="date" readonly class="form-control" id="lenddate" name="lenddate" value="<?php echo $lend_back_edit_data[0]['lending_date']; ?>" required>
               </div>
               
               <!--<input type="hidden" id="coach_id" name="coach_id" value="<?php echo $coach_id; ?>">-->

             </div>
             <div class="col-md-3 mb-3">
               <label for="validationPrimaryEmail">Enter Coach email</label>
                <div class="input-group">
                  <input type="email" readonly class="form-control" id="coach_email" placeholder="Enter Coach Email" value="<?php echo $lend_back_edit_data[0]['coach_email']; ?>" name="coach_email" required>
               </div>
			   <!--<span id="email_status"></span>-->
             </div>
          
              <div class="col-md-3 mb-3">
               <label for="validationPrimaryEmail">Coach Name</label>
                <div class="input-group">
                <input type="text" readonly class="form-control" name="coach_name" id="coach_name" placeholder="Coach Name" value="<?php echo $lend_back_edit_data[0]['coach_name']; ?>" aria-describedby="inputGroupPrepend2" required="">
               </div>
             </div>
             
             <input type="hidden" value="<?php echo $lend_back_edit_data[0]['coach_lending_head_id']; ?>" id="header_id" name="header_id">
             
             <div class="col-md-3 mb-3">
               <label for="validationPrimaryEmail">Coach Phone Number</label>
                <div class="input-group">
                <input type="text" readonly class="form-control" name="phone_no" id="phone_no" placeholder="Coach Phone Number" value="<?php echo $lend_back_edit_data[0]['phone_no']; ?>" aria-describedby="inputGroupPrepend2" required>
               </div>
			   <!--<span id="phone_status"></span>-->
             </div>
           </div>
           </div>
           <!--second stage-->
    <div>
        <div class="container">
              <h4>Enter Item Details Below </h4>
              
        <table style="width: 100%;">
            <tbody>
            <tr>
                
                <td style="text-align: center;padding-bottom: -5px;padding-left: 15px;"><input type="checkbox" name="record"></td>
                
            <td>
            <div class="form-row">
             <div class="col-md-2 mb-3">
               <label for="validationPrimaryEmail">Product Name</label>
                <select name="product_id" id="product" readonly class="form-control">
                     <option value="<?php echo $lend_back_edit_data[0]['product_id']; ?>" selected><?php echo $lend_back_edit_data[0]['product_name']; ?></option>
                 </select>
             </div>
             
             <div class="col-md-2 mb-3">
               <label for="validationPrimaryEmail">Product Barcode</label>
                <div class="input-group">
                  <input type="type" readonly class="form-control" id="serial_no" placeholder="Barcode" readonly value="<?php echo $lend_back_edit_data[0]['product_code']; ?>"  name="serial_no">
               </div>
            </div>
            
            <div class="col-md-1 mb-3">
               <label for="">Type</label>
                <div class="input-group">
                  <input type="text" readonly class="form-control" id="prod_type"  name="prod_type" value="<?php echo $lend_back_edit_data[0]['product_type']; ?>" readonly placeholder="Product Type" required>
               </div>
            </div>
            
               <div class="col-md-1 mb-3">
               <label for="">Color</label>
                <div class="input-group">
                  <input type="text" readonly class="form-control" id="prod_color"  name="prod_color" value="<?php echo $lend_back_edit_data[0]['product_colr']; ?>" readonly placeholder="Product Color" required>
               </div>
            </div>
            
            
              <div class="col-md-1 mb-3">
               <label for="">Quantity</label>
                <div class="input-group">
                  <input type="text" readonly name="quantity" value="<?php echo $total_data[0]['total']; ?>" class="form-control" onchange="check1(this)" id="quantity" placeholder="Quantity" required>
               </div>
               <span style="color:red" id="quanti_status"></span>
            </div>
            
            <!--<input type="hidden" value="<?php echo $lend_back_edit_data[0]['quantity']; ?>" id="presentStock">-->
            
            <!--<input type="hidden" value="<?php echo $lend_back_edit_data[0]['customer_stock']; ?>" id="totalStock">-->
            
             <div class="col-md-2 mb-3">
               <label for="">Expected Return Date</label>
                <div class="input-group">
                  <input type="date" readonly value="<?php echo $lend_back_edit_data[0]['expected_return_date']; ?>" class="form-control" name="res_date" id="res_date"  required>
               </div>
               </div>
               
               <div class="col-md-2 mb-3">
               <label for="">Return Date</label>
                <div class="input-group">
                  <input type="date" class="form-control" name="return_date" id="return_date" value="<?php echo $lend_back_edit_data[0]['received_date']; ?>" required>
               </div>
               </div>
               
               <div class="col-md-1 mb-3">
               <label for="">Return QTY</label>
                <div class="input-group">
                  <input type="text" class="form-control" onchange="check(this)" value="<?php echo substr($lend_back_edit_data[0]['quantity'],1,sizeof($lend_back_edit_data[0]['quantity'])+1); ?>" name="return_qty" id="return_qty"  required>
               </div>
               </div>
               
               </div>
               </td>
              </tr>
              
              <?php if($lend_back_edit_data){for($i=1;$i<(sizeof($lend_back_edit_data));++$i){ ?>
              
              <tr>
                
                <td style="text-align: center;padding-bottom: 25px;padding-left: 15px;"><input type="checkbox" name="record"></td>
                
            <td>
            <div class="form-row">
             <div class="col-md-2 mb-3">
                 <select name="product_id" id="product" readonly class="form-control">
                     <option value="<?php echo $lend_back_edit_data[$i]['product_id']; ?>" selected><?php echo $lend_back_edit_data[$i]['product_name']; ?></option>
                 </select>
             </div>
             
             <div class="col-md-2 mb-3">
                <div class="input-group">
                  <input type="type" class="form-control" id="serial_no" placeholder="Barcode" readonly value="<?php echo $lend_back_edit_data[$i]['product_code']; ?>"  name="serial_no">
               </div>
            </div>
             
             <div class="col-md-1 mb-3">
                <div class="input-group">
                  <input type="type" class="form-control" id="" placeholder="Type" readonly value="<?php echo $lend_back_edit_data[$i]['product_type']; ?>"  name="">
               </div>
            </div>
            
            
               <div class="col-md-1 mb-3">
                <div class="input-group">
                  <input type="text"  class="form-control" id="prod_color" readonly name="prod_color" value="<?php echo $lend_back_edit_data[$i]['product_colr']; ?>" readonly placeholder="Product Color" required>
               </div>
            </div>
            
            <input type="hidden" value="<?php echo $lend_back_edit_data[$i]['header_id']; ?>" id="header_id">
            
              <div class="col-md-1 mb-3">
                <div class="input-group">
                  <input type="text" name="quantity" readonly value="<?php echo $lend_back_edit_data[$i]['quantity']; ?>" class="form-control" onchange="check1(this)" id="quantity" placeholder="Quantity" required>
               </div>
            </div>
            
            <input type="hidden" value="<?php echo $lend_back_data[$i]['quantity']; ?>" id="presentStock">
            
            <input type="hidden" value="<?php echo $lend_back_data[$i]['customer_stock']; ?>" id="totalStock">
            
             <div class="col-md-2 mb-3">
                <div class="input-group">
                  <input type="date" readonly value="<?php echo $lend_back_edit_data[$i]['expected_return_date']; ?>" class="form-control" name="res_date" id="res_date"  required>
               </div>
               </div>
               
               <div class="col-md-2 mb-3">
                <div class="input-group">
                  <input type="date" class="form-control" name="return_date" id="return_date"  required>
               </div>
               </div>
               
               <div class="col-md-1 mb-3">
                <div class="input-group">
                  <input type="text" class="form-control" onchange="check(this)" name="return_qty" id="return_qty"  required>
               </div>
               <span style="color:red" id="quanti_status"></span>
               </div>
               
               </div>
               </td>
              </tr>
              
              <?php }}?>
              </tbody>
            </table>
           
           <!--<table style="width: 100%;">-->
           <!--    <tbody id="showTable">-->
   
           <!--     </tbody>-->
           <!--</table>-->
           
        <input type="hidden" name="al-products" id="all-product" value="">
	    <input type="hidden" name="al-quantities" id="all-quantity" value="">
	    <input type="hidden" name="al-return_date" id="all-return_date" value="">
        <input type="hidden" name="ex-return_date" id="expected-return_date" value="">
          
          
            
            <div class="btn-group" role="group" aria-label="Basic example">
		    <input type="button" class="btn btn-secondary btn-lg my-2 pull-left" id="backk" value="Back" onclick="location.href='<?php echo base_url();?>index.php/Lending_received/lend_back_master?a=<?php echo $secure_code; ?>'"/>
		
		<!--<input type="button" class="btn btn-success  btn-lg my-2 pull-left" id="add-row" value="Add Row">-->
		
		<!--<button type="button" class="btn btn-success  btn-lg my-2 pull-left" id="delete-row">Delete Row</button>-->
		
		<input type="button" class="btn btn-success  btn-lg my-2 pull-left" id="auto_click" onclick="addAll()" value="Submit"/>
		
		</div>
		
        </form>
        
</div>
</div>
</div>

<script>
    
    // $("#delete-row").click(function(){
    //         $("table tbody").find('input[name="record"]').each(function(){
    //         	if($(this).is(":checked")){
    //         	    var thisorder = $(this).parents('tr')
    //         	    var tds = thisorder.find("td")
    //         	    var head_id=tds.find('input[id="header_id"]')[0].value
    //         	    if(+head_id > 0)
    //         	       var product_id=tds.find('input[name="record"]')[0].value
    //         	        if(confirm(`Delete the Product ${product_id}`))
    //         	        delete_product(product_id)
    //         	        $(this).parents("tr").remove()
    //         	        }else
    //         	           tds.find('input[name="record"]')[0].checked=false
            	        
    //         	    }else
    //                 $(this).parents("tr").remove()
                
            	
    //         })
    //     })
    // });   
    
</script>
    
 <?php include_once('footer.php'); ?>         

              