<html>
    
<?php include_once('header.php'); ?>
<body>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>

<script>

$(document).ready(function(){
  $('#CompanyPhone').mask('000-000-0000');
  $('#CompanyFax').mask('000-000-0000');
  $('#client_telephone1').mask('000-000-0000');
  $('#client_telephone2').mask('000-000-0000');
});
</script>
    
<div class="content">

	
  <div class="container">
      <a id="back2Top" title="Back to top" href="#">&#10148;</a>
    <h3 class="gold-underline">Add new Product</h3>
        

          <form name="driver_add" action="product_registration" method="post" enctype="multipart/form-data">	 
            <div class="form-row">
              <div class="col-md-3 mb-3">
                
                <label for="product_name">Product Name</label>
                <div class="input-group">
				

                  <input type="text" class="form-control" id="product_name" placeholder="Product Name" name="product_name" required style="">
				  
               </div>
			   
              </div>
			  <div class="col-md-3 mb-3">
                
                <label for="product_type">Product Type</label>
                <div class="input-group">
				

                  <input type="text" class="form-control" id="product_type" placeholder="Product Type" name="product_type" required style="">
				  
               </div>
			    
			  
            </div>
			 <div class="col-md-3 mb-3">
                
                <label for="product_code">Barcode</label>
                <div class="input-group">
                  <input type="text" class="form-control" id="barcode_no" placeholder="Barcode" onchange="check()" name="product_code" required>
               </div>
			   <span style="color:red" id="barcode_message"></span>
              </div>
              
              
               <div class="col-md-3 mb-3">
                <label for="product_col">Product Color</label>
                <div class="input-group">
                  <input type="text" class="form-control" id="product_col" placeholder="Product Color" name="product_col" required>
               </div>
			   
              </div>
              
              
</div>
           
          
    <div class="btn-group" role="group" aria-label="Basic example">
		<input type="button" class="btn btn-secondary btn-lg my-2 pull-left" id="backk" value="Back" onclick="location.href='<?php echo base_url();?>index.php/Product/product_master'"/>
		
		
		
		<input type="submit" class="btn btn-success  btn-lg my-2 pull-left" id="auto_click" disabled value="Submit" onclick="form_submit()"/>
		
		</div>
			   <input type="hidden" id="TS" name="TS" value="<?php echo time();?>" />

        </form>
                
    </div>
</div>

<script>
    function check(){
        console.log('hello');
        var barcode=document.getElementById('barcode_no').value;
        if(/[!@#$%^&*(),.?":{}|<>]/g.test(barcode)==true){
        document.getElementById('barcode_message').innerHTML="Special Character Not Allow";
        return;    
            }
        if(barcode == ''){
        document.getElementById('barcode_message').innerHTML="Enter Barcode";
        return;    
        }
        $.ajax({
  method: 'post',
  url: "http://purpuligo.com/iqos/index.php/Product/barcode_exist",
  data: {code : barcode},
  dataType : 'json',
  success: function (response) {
      if(response[0].num>0){
          document.getElementById('barcode_message').innerHTML="This Barcode is already exist";
      }else{
          document.getElementById('auto_click').disabled=false;
          document.getElementById('barcode_message').innerHTML="";
      }
  }
  });
    }
</script>

 <?php include_once('footer.php'); ?>         

              