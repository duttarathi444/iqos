<?php include_once('header.php'); ?>
<body>

<input type="hidden" value="<?php echo $secure_id;?>" name="secure_code">

<div class="content">
   	
  <div class="container">
 		<h3 class="gold-underline">EXTRA MODULES</h3>
 		 		
    <div class="row">
      <div class="col-3 lost">
		 <a href="<?php echo site_url('Lending_Product/lend_view?a='.$secure_id); ?>">
		         	<img src="../../assets/img/pe.png">
      	<p>Product Lend to Coaches</p></a>
      </div>
      
	  <div class="col-3 lost">
      	<a href="<?php echo site_url('Lending_received/lend_back_master?a='.$secure_id); ?>">
      	        	<img src="../../assets/img/rec.png">
      	    <p>Product Lend Received</p></a>
      </div>
     
     <div class="col-3 lost">
		 <a href="<?php echo site_url('Lending_received/lending_report?a='.$secure_id); ?>">
		 <img src="../../assets/img/lan.png">
      	<p>Lending Reports</p></a>
      </div>
      
      <div class="col-3 lost">
		 <a href="<?php echo site_url('Special_note/note_master?a='.$secure_id); ?>">
		         	<img src="../../assets/img/spc.png">
      	<p>Special Note</p></a>
      </div>
      
   <!--   <div class="col-3 module">-->
   <!-- 	<img src="../../assets/img/god_son.png">-->
		 <!--<a href="<?php echo site_url('Lead_followup/lead_followup_master?a='.$secure_id); ?>">-->
   <!--   	<p>Lead Follow Up</p></a>-->
   <!--   </div>-->
     
      </div>
      
    </div>
</div>
</body>
<?php include_once('footer.php'); ?>