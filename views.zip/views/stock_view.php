<html>
    
<?php include_once('header.php'); ?>
<body>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>

<script>

$(document).ready(function(){
  $('#CompanyPhone').mask('000-000-0000');
  $('#CompanyFax').mask('000-000-0000');
  $('#client_telephone1').mask('000-000-0000');
  $('#client_telephone2').mask('000-000-0000');
});
</script>
    
<div class="content">

	
  <div class="container">
    <h2 class="gold-underline">Product Stock Details</h2>
    
    
     <?php 
		   if(!empty($stock_list))
							
							{
								foreach($stock_list as $driver){
						?>
        

          <form name="driver_add" action="driverdetails_update" method="post">
             <div class="gold-underline">
<table width="100%" cellspacing="5" cellpadding="5" border="0" bgcolor="E6B958" align="center">
   <tr bgcolor="#FFFFFF">
      <td>
         <table width="100%" cellspacing="0" cellpadding="0" border="0">
            <tr bgcolor="#FFFFFF">
               <td width="33%" height="40"><b>Product Name</b></td>
               <td width="34%"><?php echo $driver['product_name'];?></td>
               <td></td>
            </tr>
            <tr bgcolor="#FFFFFF">
               <td height="40"><b> Product Type</b></td>
               <td><?php echo $driver['product_type'];?></td>
               <td></td>
            </tr>
            <tr bgcolor="#FFFFFF">
               <td height="40"><b>Product Code</b></td>
               <td><?php echo $driver['item_code'];?></td>
               <td></td>
            </tr>
			 <tr bgcolor="#FFFFFF">
               <td width="33%" height="40"><b>Cartoon Number</b></td>
               <td width="34%"><?php echo "kk";?></td>
               <td></td>
            </tr>
            <tr bgcolor="#FFFFFF">
               <td height="40"><b> Product Barcode</b></td>
               <td><?php echo $driver['product_bar_code'];?></td>
               <td></td>
            </tr>
            <tr bgcolor="#FFFFFF">
               <td height="40"><b>Received from</b></td>
               <td><?php echo $driver['recevied_from'];?></td>
               <td></td>
            </tr>
             <tr bgcolor="#FFFFFF">
               <td height="40"><b>Shipment Name</b></td>
               <td><?php echo $driver['shipmnt_name'];?></td>
               <td></td>
            </tr>
            <tr bgcolor="#FFFFFF">
               <td height="40"><b>Received Date</b></td>
               <td><?php echo $driver['recived_date'];?></td>
               <td></td>
            </tr>
            
            
         </table>
      </td>
   </tr>
</table>
</div>  


               <input type="button" class="btn btn-secondary  btn-lg my-2 " id="agback" value="Back"  onclick="location.href='<?php echo base_url();?>index.php/Stock/stock_master'" />
               
                <input type="hidden" name="driver_id" value="<?php echo $driver_id;?>" />

        </form><?php }} ?>
                
    </div>
</div>
 <?php include_once('footer.php'); ?>         

              