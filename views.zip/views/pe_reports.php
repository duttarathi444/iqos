<?php include_once('header.php'); ?>

<!DOCTYPE html>
<html lang="en" >
<head>
<meta charset="utf-8">


<link rel="stylesheet" href="../../assets/css/bootstrap.min.css">
<link rel="stylesheet" href="../../assets/css/bootstrap.min2.css">

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>

<link href="//maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">

<link  href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css" rel="stylesheet" />
    <link href="https://cdn.datatables.net/buttons/1.6.0/css/buttons.dataTables.min.css" rel="stylesheet" />
    <script src="https://code.jquery.com/jquery-3.3.1.js"></script>
    <script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.6.0/js/dataTables.buttons.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.6.0/js/buttons.colVis.min.js"></script>

<link rel="stylesheet" href="file:///Users/Chung/Desktop/Metro%20SCG/Admin%20Module/hub-m_files/css">

<link  href="../../assets/css/top.css" rel="stylesheet" />
<script src="../../assets/js/top.js"></script>
<style>
    
	table.dataTable tbody td {
    
	font-size: 13px;}
	table.dataTable tbody th {
    
	font-size: 14px;}
    
</style>
    </head>
    
    <script>
            $(this_id).tooltip({
                classes: {
                    "ui-tooltip":"highlight"
                },
                position:{ my:'left center', at:'right+50 center'},
                content:function(prd_details){
                    prd_details();
                }
            });
            
            function prd_details(this_id){
        var id=document.getElementById('prd_id').value;
            $.ajax({
                method: 'post',
                url: "http://purpuligo.com/iqos/index.php/Report/prd_details_by_id", 
                data: {alldata : id},
                async : 'true',
                dataType : 'json',
                success: function (response) {
                    alert(`${response[0].name} ${response[0].sap_order_no} ${response[0].serial_no} ${response[0].prd_quantity}`);
                }
            });
        }

        $('#datfrom_date').datetimepicker({
    defaultDate: new Date()
}); 

function dateput(){
    var datenow=new Date(Date.now());
    var month=+datenow.getMonth()+1;
    if((month+"").length<2){
        month='0'+month;
    }
    var date='';
    if((datenow.getDate()+"").length<2){
        date= '0'+datenow.getDate();
    }
    var newdate = datenow.getFullYear()+'-'+month+'-'+date;
    document.getElementById('from_date').value=newdate;
    document.getElementById('to_date').value=newdate;
}

 $(document).ready(function() {
    $('#example').DataTable( {
        dom: 'Bfrtip',
        columnDefs: [
            {
                targets: 1,
                className: 'noVis'
            }
        ],
        buttons: [
            {
                extend: 'colvis',
                columns: ':not(.noVis)'
            }
        ],
        "order": [[ 0, "desc" ]]
    } );
 } );

</script>
    
<body>
    
<div id="header" class="site-header">
</div>
<body onload="dateput();">
<div class="content">
  <div class="container">
    <h3 class="gold-underline">PE Report</h3>
       
          <form method ="post" action="pe_reports_gen">
           

            <div class="row">
    <!--          <div class="col-3">-->
    <!--              <label for="validationPrimaryEmail">Product Name</label>-->
    <!--               <div id="drop">-->
    <!--                <select class="form-control" name="items"  id="a2" maxlength=200; placeholder="Select Product Name" required>-->
    <!--                    <?php if($product_data){foreach($product_data as $p_list){ ?>-->
    
    <!--                <option value="<?php echo $p_list['product_id']; ?>"><?php echo  $p_list['product_name'];?></option>-->
    <!--                <?php }}?>-->
    <!--                </select>-->
			 <!--   </div>-->
			 <!--</div>-->
			 
			 <div class="col-3">
                  <label for="validationPrimaryEmail">Status Type</label>
                   <div id="drop">
                    <select class="form-control" name="status"  id="a3" maxlength=200; placeholder="Select " required>
                        <option value="0"> Select Options</option>
						<option value="1">PE1</option>
						<option value="2">PE2</option>
						<option value="3">Q+1 Conversion</option>
                    </select>
			    </div>
			 </div>
			 
			 <div class="col-3">
			     <label for="validationPrimaryEmail">From Date</label>
                   <div id="drop">
                    <input type="date" class="form-control" id="from_date" name="from_date">
			    </div>
			 </div>
			 
			 <div class="col-3">
			     <label for="validationPrimaryEmail">To Date</label>
                   <div id="drop">
                    <input type="date" class="form-control" id="to_date" name="to_date">
			    </div>
			 </div>
			 
			 
        <div class="col-2">
		<div id="drop">
		<label for="validationDefault01"> </label>
            <button class="btn btn-primary" type="submit">Submit</button>
        </div>
		  </div>
     </div>
		 </form>
 <!--class="table table-hover table-striped"-->
			 
<table class="table table-hover table-striped">
      <thead class="thead-dark">
            <tr>
                <!--<th scope="col">Product Name</th>-->
			   <!-- <th scope="col">PE1</th>
				<th scope="col">PE2</th>
                 <th scope="col">Q+1 Conversion</th>//-->
				 <th scope="col">Customer Name</th>
				 <th scope="col">Customer Email</th>
				 <th scope="col">Customer Phone</th>
				 
               
            </tr>
        </thead>
        
        <tbody>
		 <?php if($cust_details){foreach($cust_details as $p_list){ ?>
            <tr>
                <!--<td><?php echo  $p_list['product_name'];?></td>-->
	            <td><?php echo  $p_list['f_name'].' '.$p_list['l_name'];?></td>
                <td><?php echo  $p_list['emails'];?></td>
                <td><?php echo  $p_list['ph_no'];?></td>
				
            </tr>
			<?php }}?>
        </tbody>
 
    </table>
  <input type="hidden" id="prd_id" value="<?php echo  $p_list['product_stock_details_id'];?>">
  <div class="btn-group" role="group" aria-label="Basic example">             
<input type="button" class="btn btn-secondary btn-lg my-2 pull-left" id="backk" value="Back" onclick="location.href='<?php echo base_url();?>index.php/Report/report_module'" />
</div>
			 
    </div>
  </div>
        
   
		 
  

    <script>
        function myfun(){
            var e = document.getElementById('a2');
            var val = e.options[e.selectedIndex].value;
            var fr_date=document.getElementById('from_date').value;
            var t_date=document.getElementById('to_date').value;
            console.log(val);
            console.log(fr_date);
            console.log(t_date);
            $.ajax({
                    url : "http://purpuligo.com/iqos/index.php/Report/product_stock_movement_ajx",
                    method : "POST",
                    data : {pud_id: val,form_date: fr_date,to_date: t_date},
                    async : true,
                    dataType : 'json',
                    success: function(data){
                        console.log(data);
                    }
                    });
        }
    </script>

</body>
</body>
</html>
<?php include_once('footer.php'); ?>