<html>

<body>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta content="width=device-width, initial-scale=1" name="viewport"/>
  <link rel="stylesheet" href="<?php echo base_url();?>/assets/css/bootstrap.min.css">
  <link rel="stylesheet" href="<?php echo base_url();?>/assets/css/bootstrap.min2.css">
    <!--<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>-->
    <script
  src="https://code.jquery.com/jquery-3.4.1.min.js"
  integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo="
  crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>

<script>
$(document).ready(function(){
  //$('#u_phone').mask('000-000-0000');
});
</script>

<style>
  .modal{
      position: fixed;
      border: 2px;
      padding: 5rem;
      z-index: 2;
      display: none;
  }
</style>
<body>
           <!--navbar-->
           <div id="header" class="site-header">
    <nav class="navbar navbar-dark bg-dark">
      <a class="navbar-brand"><img src="./assets/img/logo-white.svg"></a>
    <div class="navbar-toggler"  data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <!--<span class="navbar-toggler-icon"></span>--><button class="modal-open  material-tooltip-smaller" data-toggle="tooltip"
  data-placement="top" title="Log in" data-modal="modal1" ><img src="./assets/img/tri.png"  alt="Smiley face" height="12" width="12"></button>
    <button class="modal-open material-tooltip-smaller" data-toggle="tooltip"
  data-placement="top" title="Registation" data-modal="modal2"><img src="./assets/img/rag0.png" alt="Smiley face" height="12" width="12"></button>
    <button class="modal-open material-tooltip-smaller" data-toggle="tooltip"
  data-placement="top" title="Forget Password" data-modal="modal3"><img src="./assets/img/forget.svg" alt="Smiley face" height="12" width="12"></button>
    </div>
    </nav>
</div>
           <!--navend-->

    <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
        <div class="carousel-inner">
          <div class="carousel-item active">
            <img class="d-block w-100" src="./assets/img/12.png" alt="First slide" height="85%">
          </div>
          <div class="carousel-item">
            <img class="d-block w-100" src="./assets/img/14.png" alt="Second slide" height="85%">
          </div>
          <div class="carousel-item">
            <img class="d-block w-100" src="./assets/img/16.png" alt="Third slide" height="85%">
          </div>
        </div>
        <a class="carousel-control-prev" href="" role="button" data-slide="prev">
          <!--<span class="carousel-control-prev-icon" aria-hidden="true"></span>-->
          <span class="sr-only"></span>
        </a>
        <a class="carousel-control-next" href="" role="button" data-slide="next">
          <!--<span class="carousel-control-next-icon" aria-hidden="true"></span>-->
          <span class="sr-only"></span>
        </a>
        </div>
       <!--model-->
       <div class="modal" id="modal1">
           <div class="modal-close"></div>
       <!--login from-->
     <div id="login" class="login-form">
 	<h3 class="gold-underline">Login</h3>
 	<form role="form" method="post" action="index.php/welcome/user_auth">
  <div class="form-group">
    <label for="exampleInputEmail1">User Name</label>
    <input type="email" class="form-control" id="UserEmail" name="email" required aria-describedby="emailHelp" placeholder="Enter your user name"  onkeyup="checkemail();">
	
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Password</label>
    <input type="password" class="form-control" name="password" required placeholder="Enter your Password">
  </div>
  
  <button type="submit" class="btn btn-primary">Submit</button>
  </form>
  </div>
       <!--end from-->
       </div>
       
           <!--end login-->
            
            <!--reg-->
               <div class="modal" id="modal2">
                   <div class="modal-close"></div>
     <div id="login" class="login-form">
         
         <span id="reg_message2"></span>
         
 	<h3 class="gold-underline">Registation</h3>
 		<form role="form" method="post">
  <div class="form-group">
    <label for="exampleInputEmail1">Name</label>
    <input type="text" class="form-control" id="Username" name="first_name" required aria-describedby="emailHelp" placeholder="Enter your user name">
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Email</label>
    <input type="email" class="form-control" id="email_reg" onchange="check(2)" name="email" required placeholder="Enter your email">
    <span style="color:red" id="reg_message"></span>
  </div>
  
  <div class="form-group">
    <label for="exampleInputPassword1">Phone Number</label>
    <input type="number" class="form-control" id="u_phone" name="c_telephone" maxlength="10" required placeholder="Enter your Phone number">
  </div>
  
  <div class="form-group">
    <label for="exampleInputPassword1">Address</label>
    <input type="text" class="form-control" id="u_address" name="address" required placeholder="Enter your address">
  </div>
  
  <button type="button" disabled id="reg_button" onclick="add_reg()" class="btn btn-primary">Submit</button>
  
                   </div>
                   </form>
                   
                   
   
</div>
              <!--page end-->
        <!--reg end-->
        
   <!--forget pass     -->
        <div class="modal" id="modal3">
                               <div class="modal-close"></div>

                 <div id="login" class="login-form">
                     <span id="forget_message"></span>
 	<h3 class="gold-underline">Forget Password</h3>
	<form role="form">
  <div class="form-group">
    <label for="exampleInputEmail1">User Email</label>
    <input type="email" class="form-control" id="UserEmail1" name="u_email" required aria-describedby="emailHelp" placeholder="Enter your user name">
  </div>
  
  <button type="button" onclick="check(1)" class="btn btn-primary">Submit</button>
  </div>
            
            

        </div>
        <!--end forget-->
     </div>
     
     <script>
         function check(id){
             if(id == 1){
                var url="http://purpuligo.com/iqos/index.php/User_reg/forget_password";
                var data=document.getElementById('UserEmail1').value;
                 if(data==''){
                     document.getElementById('email_forget').innerHTML="Enter Your Email";
                     return;
                 }
             }else{
                var url="http://purpuligo.com/iqos/index.php/User_reg/check_email";
                 var data=document.getElementById('email_reg').value;
                 if(data==''){
                     document.getElementById('reg_message').innerHTML="Enter Your Email";
                     return;
                 }
             }
               var result=check_email(data,url);
               result
               .then(p=>{
                   if(id==1){
                   if(p=='1001'){
                       document.getElementById('forget_message').innerHTML="Message has been Sent";
                       document.getElementById('forget_message').style.color="green";
                   }else{
                       document.getElementById('forget_message').innerHTML="Enter Valid Email id";
                       document.getElementById('forget_message').style.color="red";
                   }
                   }else{
                       if(p[0].num>0){
                           document.getElementById('reg_message').innerHTML="Email id is already Exist";
                           document.getElementById('reg_button').disabled=true;
                       }else{
                           document.getElementById('reg_message').innerHTML="";
                           document.getElementById('reg_button').disabled=false;
                       }
                   }
               })
         }
         async function check_email(id1,ur){
             var result=await $.ajax({
                    url: ur,
                    method: 'POST',
                    data: {u_email: id1},
                    dataType : 'json',
                    async: 'true',
              });
              return result;
         }
         
         function add_reg(){
             var name=document.getElementById('Username').value;
             var email=document.getElementById('email_reg').value;
             var phone=document.getElementById('u_phone').value;
             var address=document.getElementById('u_address').value;
             if(name!='' && email!='' && phone!='' && address!=''){
                 $.ajax({
                    url: "http://purpuligo.com/iqos/index.php/User_reg/user_reg",
                    method: 'POST',
                    data: {email: email,
                        first_name: name,
                        c_telephone: phone,
                        address: address
                    },
                    //dataType : 'json',
                    async: 'true',
                    success: function(data){
                        if(data > 0){
                            document.getElementById('reg_message2').innerHTML="Registation Completed";
                            document.getElementById('reg_message2').style.color="green"
                    }else{
                        document.getElementById('reg_message2').innerHTML="Registation Not Completed";
                        document.getElementById('reg_message2').style.color="red";
                    }
                    }
              });
             }
         }
         
     </script>
     
      <script>
var tom = document.querySelectorAll('.modal-open');
        tom.forEach(function(btn){
            btn.onclick = function(){
                var modal = btn.getAttribute("data-modal");
                document.getElementById(modal).style.display = "block";
            };
        });
var closeBtns = document.querySelectorAll('.modal-close');
closeBtns.forEach(function(btn){
    btn.onclick = function(){
        var modal = (btn.closest(".modal").style.display = "none");
    };
});
        window.onclick = function(e){
            if(e.target.className == "modal"){
                e.target.style.display = "none";
            }
        };


 </script>
       <?php include_once('footer.php'); ?>         
      
      </body>


