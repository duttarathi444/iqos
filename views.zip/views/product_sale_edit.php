<html>
    <head>
        <style>
    table{
        /*border: 1px solid black;*/
        width: 100%;
        margin-bottom: 20px;
		border-collapse: separate;
        /*border-spacing: 20 0px;*/
    }
    table td{
        padding: 2px;
        text-align: left;
    }
    
    </style>
    </head>
    
<?php include_once('header.php'); ?>
<body>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>

<script>
$(document).ready(function(){
  $('#CompanyPhone').mask('000-000-0000');
  $('#CompanyFax').mask('000-000-0000');
  $('#client_telephone1').mask('000-000-0000');
  $('#quant').mask('0000000000');
});

function select_prod(num){
    if(num == 1){
        var e = document.getElementById('cus_email');
        var val = e.options[e.selectedIndex].value;
        var url = "http://purpuligo.com/iqos/index.php/Stock/all_customer";
    }else if(num == 2){
        var e = document.getElementById('prod_name');
        var val = e.options[e.selectedIndex].value;
        var url = "http://purpuligo.com/iqos/index.php/Stock/all_product_list";
    }
    $.ajax({
                    url : url,
                    method : "POST",
                    data : {cus_id: val},
                    async : true,
                    dataType : 'json',
                    success: function(data){
                        if(num == 1){
                        document.getElementById('cus_name').value = data[0].f_name+' '+data[0].l_name;
                        document.getElementById('cus_phone').value = data[0].ph_no;
                        document.getElementById('postal').value = data[0].postal_code;
                        if(Object.keys(data[0]).length > 4){
                            document.getElementById('god_father_name').value = data[0].p_f_name+' '+data[0].p_l_name;
                            document.getElementById('god_father_email').value = data[0].p_mail;
                            document.getElementById('god_father_phone').value = data[0].p_ph;
                        }else{
                            document.getElementById('god_father_name').value = '';
                            document.getElementById('god_father_email').value = '';
                            document.getElementById('god_father_phone').value = '';
                        }
                        }else if(num == 2){
                            console.log(data);
                            document.getElementById('prod_color').value = data[0].product_colr;
                            document.getElementById('prod_code').value= data[0].product_code;
                            document.getElementById('prod_type').value= data[0].product_type;
                            var type=data[0].product_type.substring(0,4).toLowerCase();
                            if(type == 'iqos'){
                                document.getElementById('serial').disabled=false;
                            }else{
                                document.getElementById('serial').value="";
                                document.getElementById('serial').disabled=true;
                            }
                        }
                    }
                    });
}

function pe3date(){
    var s_date = document.getElementById('select_date').value;
    var date = new Date(s_date);
    var newdate = new Date(date);

    newdate.setDate(newdate.getDate() + 21);
    
    var dd = newdate.getDate()+'';
    var mm = newdate.getMonth() + 1+'';
    var y = newdate.getFullYear();
    var modi_mm='';
    var modi_dd='';
    if(mm.length < 2){
        modi_mm='0'+mm;
        if(dd.length < 2){
        modi_dd="0"+dd;
        var someFormattedDate = y + '-' + modi_mm + '-' + modi_dd;
        }else{
        var someFormattedDate = y + '-' + modi_mm + '-' + dd;
        }
    }else{
        if(dd.length < 2){
        modi_dd="0"+dd;
        var someFormattedDate = y + '-' + mm + '-' + modi_dd;
        }else{
        var someFormattedDate = y + '-' + mm + '-' + dd;
        }
    }
    document.getElementById('pe3_date').value = someFormattedDate;
}

function replacedate(id){
    var s_date = document.getElementById('select_date').value;
    var date = new Date(s_date);
    var newdate = new Date(date);

    newdate.setDate(newdate.getDate() + 7);
    
    var dd = newdate.getDate()+'';
    var mm = newdate.getMonth() + 1+'';
    var y = newdate.getFullYear();
    var modi_mm='';
    var modi_dd='';
    if(mm.length < 2){
        modi_mm='0'+mm;
        if(dd.length < 2){
        modi_dd="0"+dd;
        var someFormattedDate = y + '-' + modi_mm + '-' + modi_dd;
        }else{
        var someFormattedDate = y + '-' + modi_mm + '-' + dd;
        }
    }else{
        if(dd.length < 2){
        modi_dd="0"+dd;
        var someFormattedDate = y + '-' + mm + '-' + modi_dd;
        }else{
        var someFormattedDate = y + '-' + mm + '-' + dd;
        }
    }
    document.getElementById('pe2_date').value = someFormattedDate;
    id();
}

function saledate(id) {
    var s_date = document.getElementById('select_date').value;
    var date = new Date(s_date);
    var newdate = new Date(date);

    newdate.setDate(newdate.getDate() + 3);
    
    var dd = newdate.getDate()+'';
    var mm = newdate.getMonth() + 1+'';
    var y = newdate.getFullYear();
    var modi_mm='';
    var modi_dd='';
    if(mm.length < 2){
        modi_mm='0'+mm;
        if(dd.length < 2){
        modi_dd="0"+dd;
        var someFormattedDate = y + '-' + modi_mm + '-' + modi_dd;
        }else{
        var someFormattedDate = y + '-' + modi_mm + '-' + dd;
        }
    }else{
        if(dd.length < 2){
        modi_dd="0"+dd;
        var someFormattedDate = y + '-' + mm + '-' + modi_dd;
        }else{
        var someFormattedDate = y + '-' + mm + '-' + dd;
        }
    }
    document.getElementById('pe1_date').value = someFormattedDate;
    id(pe3date);
}

function checkQuantity(){
    
    var val=document.getElementById('quanti').value;
    var amount=document.getElementById('quant').value;
    if(val != -1){
        if(amount > 0 && +amount <= +val){
            document.getElementById('auto_click').disabled=false;
        }else{
            document.getElementById('auto_click').disabled=true;
        }
    }
}

// function checkDate(){
//     console.log('hello');
//     var existdate=document.getElementById('existDate').value;
//     var presentdate=document.getElementById('select_date').value;
//     var a=new Date(existdate);
//     var b=new Date(presentdate);
//     if(+a === +b){
//         console.log('hello');
//     }
// }

</script>


<div class="content">
  <div class="container">
      <a id="back2Top" title="Back to top" href="#">&#10148;</a>
    <h3 class="gold-underline">Edit Product Sale</h3>
            
            <!--updated_sale_information-->
    
          <form name="driver_add" action="updated_sale_information" method="post" enctype="multipart/form-data">
	        <div class="form-row">
              <div class="col-md-6 mb-3">
               <label for="validationPrimaryEmail">Sale Date</label>
                <div class="input-group">
                  <input type="date" class="form-control" onchange="saledate(replacedate)" id="select_date" name="select_date" value="<?php echo $sale_products_data[0]['prd_sale_date']; ?>" required>
               </div>
             </div>
             <!--<input type="hidden" value="<?php echo $sale_products_data[0]['prd_sale_date']; ?>" id="existDate">-->
             
             <div class="col-md-6 mb-3">
               <label for="validationPrimaryEmail">Customer Email</label>
                <select name="cus_email_id" id="cus_email" class="form-control" onchange=select_prod(1)>
                    
                    <option selected value="<?php echo  $sale_products_data[0]['sl_no'];?>"><?php echo  $sale_products_data[0]['mail_id'];?></option>
                    <?php if($customer_list){foreach($customer_list as $c_list){ ?>
                    <option value="<?php echo $c_list['sl_no']; ?>"><?php echo  $c_list['mail_id'];?></option>
                    <?php }}?>
                  </select>
             </div>
           </div>
           
           	<div class="form-row">
           	    
              <div class="col-md-4 mb-2">
               <label for="validationPrimaryEmail">Customer Name</label>
                <div class="input-group">
                <input type="text" class="form-control" id="cus_name" name="customer_name" readonly placeholder="Customer Name" value="<?php echo $sale_products_data[0]['f_name'].' '.$sale_products_data[0]['l_name']; ?>" aria-describedby="inputGroupPrepend2">
               </div>
             </div>
             
             <div class="col-md-4 mb-2">
               <label for="validationPrimaryEmail">Customer Phone No</label>
                <div class="input-group">
                <input type="text" class="form-control" name="phone_no" value="<?php echo $sale_products_data[0]['ph_no']; ?>" id="cus_phone" readonly placeholder="Phone No" aria-describedby="inputGroupPrepend2">
               </div>
             </div>
             
             <div class="col-md-4 mb-2">
               <label for="validationPrimaryEmail">Customer Postal Code</label>
                <div class="input-group">
                <input type="text" class="form-control" name="postal_code" value="<?php echo $sale_products_data[0]['postal_code']; ?>" id="postal" readonly placeholder="Postal Code" aria-describedby="inputGroupPrepend2">
               </div>
             </div>
             
           </div>
           
           <div class="form-row">
           	    
              <div class="col-md-4 mb-2">
               <label for="validationPrimaryEmail">God Father Name</label>
                <div class="input-group">
                <input type="text" class="form-control" id="god_father_name" value="<?php echo ($sale_products_data[0]['fname'] != '')? ($sale_products_data[0]['fname'].' '.$sale_products_data[0]['lname']):(''); ?>" name="customer_name" readonly placeholder="God Father Name" aria-describedby="inputGroupPrepend2">
               </div>
             </div>
             
             <div class="col-md-4 mb-2">
               <label for="validationPrimaryEmail">God Father Email</label>
                <div class="input-group">
                <input type="text" class="form-control" name="phone_no" value="<?php echo $sale_products_data[0]['email']; ?>" id="god_father_email" readonly placeholder="God Father Email" aria-describedby="inputGroupPrepend2">
               </div>
             </div>
             
             <div class="col-md-4 mb-2">
               <label for="validationPrimaryEmail">God Father Phone No</label>
                <div class="input-group">
                <input type="text" class="form-control" name="postal_code" value="<?php echo $sale_products_data[0]['phone_no']; ?>" id="god_father_phone" readonly placeholder="God Father Phone No" aria-describedby="inputGroupPrepend2">
               </div>
             </div>
             
           </div>
           
           <div class="form-row">
			   
             <div class="col-md-3 mb-3">
               <label for="validationPrimaryEmail">Product Name</label>
                <select name="product_id" id="prod_name" class="form-control" onchange=select_prod(2)>
                    
                    <option selected="" value="<?php echo $sale_products_data[0]['product_id']; ?>"><?php echo  $sale_products_data[0]['product_name'];?></option>
                    <?php if($product_list){foreach($product_list as $p_list){ ?>
                    <option value="<?php echo $p_list['product_id']; ?>"><?php echo  $p_list['product_name'];?></option>
                    <?php }}?>
                  </select>
             </div>
             
             <div class="col-md-3 mb-3">
               <label for="validationPrimaryEmail">Product Type</label>
                <div class="input-group">
                  <input type="type" class="form-control" id="prod_type" placeholder="Product Type" value="<?php echo $sale_products_data[0]['product_type']; ?>" readonly name="product_color">
               </div>
            </div>
            
            <div class="col-md-3 mb-3">
               <label for="validationPrimaryEmail">Barcode</label>
                <div class="input-group">
                  <input type="type" class="form-control" id="prod_code" placeholder="Barcode" value="<?php echo $sale_products_data[0]['product_code']; ?>" readonly name="product_color">
               </div>
            </div>
             
             <div class="col-md-3 mb-3">
               <label for="validationPrimaryEmail">Product Color</label>
                <div class="input-group">
                  <input type="type" class="form-control" id="prod_color" placeholder="Product Color" value="<?php echo $sale_products_data[0]['product_colr']; ?>" readonly name="product_color">
               </div>
            </div>
            
           </div>

            <div class="form-row">
           	    
              <div class="col-md-4 mb-2">
               <label for="validationPrimaryEmail">Product Serial No</label>
                <div class="input-group">
                <input type="text" class="form-control" id="serial" name="serial_no" value="<?php echo$sale_products_data[0]['serial_no']?>" <?php if(strtolower(substr($sale_products_data[0]['product_type'],0,4)) != 'iqos') echo "readonly ";?> placeholder="Serial No" aria-describedby="inputGroupPrepend2">
               </div>
             </div>
             
             <div class="col-md-4 mb-2">
               <label for="validationPrimaryEmail">SAP Order No</label>
                <div class="input-group">
                <input type="text" class="form-control" name="sap_no" id="sap_no" value="<?php echo $sale_products_data[0]['sap_order_no']; ?>" placeholder="SAP Order No" aria-describedby="inputGroupPrepend2">
               </div>
             </div>
             
             <div class="col-md-4 mb-2">
               <label for="validationPrimaryEmail">Quantity</label>
                <div class="input-group">
                <input type="text" class="form-control" readonly name="quantity" id="quant" value="1" placeholder="Quantity" aria-describedby="inputGroupPrepend2">
               </div>
             </div>
             <!--<input type="hidden" id="quanti" name="quanti" value="<?php echo $sale_products_data[0]['customer_stock']; ?>">-->
           </div>
            
            <div class="form-row">
             <div class="col-md-3 mb-3">
               <label for="validationPrimaryEmail">Device Registered</label>
                <select name="res_valid" onchange="valid()" id="res_validation" class="form-control">
                    <option value=<?php echo $sale_products_data[0]['device_reg']; ?> selected><?php echo ($sale_products_data[0]['device_reg']==1) ? ('Yes'):('No'); ?></option>
                    <option value=1>Yes</option>
                    <option value=0>No</option>
                  </select>
             </div>
             
             <div class="col-md-3 mb-3">
               <label for="validationPrimaryEmail">Device Registered Date</label>
                <div class="input-group">
                  <input type="date" class="form-control" id="res_date" value="<?php $sale_products_data[0]['device_reg']?>" name="registation_date" <?php if($sale_products_data[0]['device_reg']!=1) echo "readonly"; ?>>
               </div>
            </div>
           </div>
           
           <div class="form-row">
             <div class="col-md-2 mb-3">
               <label for="validationPrimaryEmail">PE1 Date</label>
                <input type="date" class="form-control" value="<?php echo $sale_products_data[0]['pe1_date']; ?>" id="pe1_date" readonly name="pe1_date">
             </div>
             
             <div class="col-md-2 mb-3">
               <label for="validationPrimaryEmail">PE1 Status</label>
               
               <?php if($sale_products_data[0]['pe1_status']!='Complete'){;?>
               
                <select name="pe1_status" id="pe1_status" class="form-control">
                    <option selected value="<?php echo $sale_products_data[0]['pe1_status']; ?>"><?php echo $sale_products_data[0]['pe1_status'];?></option>
                    <option value="Complete">Complete</option>
                  </select>
                  <?php }else{?>
                  <input type="text" class="form-control" readonly value="Complete" name="pe1_status">
                  <?php }?>
             </div>
             
             <div class="col-md-2 mb-3">
               <label for="validationPrimaryEmail">PE2 Date</label>
                <div class="input-group">
                  <input type="date" class="form-control" value="<?php echo $sale_products_data[0]['pe2_date']; ?>" id="pe2_date" readonly name="pe2_date">
               </div>
            </div>
             
             <div class="col-md-2 mb-3">
               <label for="validationPrimaryEmail">PE2 Status</label>
               
               <?php if($sale_products_data[0]['pe2_status']!='Complete'){;?>
               
                <select name="pe2_status" id="pe2_status" class="form-control">
                    <option selected value=<?php echo $sale_products_data[0]['pe2_status']?>><?php echo $sale_products_data[0]['pe2_status']?></option>
                    <option value="Complete">Complete</option>
                  </select>
                  
                  <?php }else{?>
                  <input type="text" class="form-control" readonly value="Complete" name="pe2_status">
                  <?php }?>
                  
             </div>
             
              <div class="col-md-2 mb-3">
               <label for="validationPrimaryEmail">Q+1 Conversion Date</label>
                <div class="input-group">
                  <input type="date" class="form-control" value="<?php echo $sale_products_data[0]['pe3_date']; ?>" id="pe3_date" readonly name="pe3_date">
               </div>
            </div>
             
             <div class="col-md-2 mb-3">
               <label for="validationPrimaryEmail">Q+1 Conversion Status</label>
               
               <?php if($sale_products_data[0]['pe3_status']!='Complete'){;?>
               
                <select name="pe3_status" id="pe3_status" class="form-control">
                    <option selected value=<?php echo $sale_products_data[0]['pe3_status']?>><?php echo $sale_products_data[0]['pe3_status']?></option>
                    <option value="Complete">Complete</option>
                  </select>
                  
                  <?php }else{?>
                  <input type="text" class="form-control" readonly value="Complete" name="pe3_status">
                  <?php }?>
                  
             </div>
            
           </div>
           
          <input type="hidden" id="sale_id" name="sale_id" value="<?php echo $sale_products_data[0]['p_sale_id']; ?>">
          
            <div class="btn-group" role="group" aria-label="Basic example">
		    <input type="button" class="btn btn-secondary btn-lg my-2 pull-left" id="backk" value="Back" onclick="location.href='<?php echo base_url();?>index.php/Stock/product_sale'"/>
		
		<!--<input type="button" class="btn btn-success  btn-lg my-2 pull-left" id="add-row" value="Add Row">-->
		
		<!--<button type="button" class="btn btn-success  btn-lg my-2 pull-left" id="delete-row">Delete Row</button>-->
		
		<input type="submit" class="btn btn-success  btn-lg my-2 pull-left" id="auto_click" value="Update"/>
		
		</div>
			<input type="hidden" id="TS" name="TS" value="<?php echo time();?>" />
        </form>
                
    </div>
</div>
<script>
    function valid(){
    var e = document.getElementById('res_validation');
    var val = e.options[e.selectedIndex].value;
    if(val == 1)
    $('#res_date').removeAttr('readonly');
    else
    $('#res_date').attr('readonly', true);
    var e = document.getElementById('res_date').value='';
    }
    // $(document).ready(function(){
    //     $('#auto_click').click(function(){
    //         var existDate=document.getElementById('existDate').value;
    //         var presentDate=document.getElementById('select_date').value;
    //         if(existDate != presentDate){
    //             document.getElementById('pe1_status').value="Done";
    //             document.getElementById('pe2_status').value="Done";
    //         }else{
    //             document.getElementById('pe1_status').value="Pending";
    //             document.getElementById('pe2_status').value="Pending";
    //         }
    //     })
    // })
</script>
    
 <?php include_once('footer.php'); ?>         

              