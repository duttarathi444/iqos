<!DOCTYPE html>
<html lang="en" >
<head>
<link rel="stylesheet" href="<?php echo base_url();?>/assets/css/bootstrap.min.css">

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>

<link href="//maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">

<!--external css -->

<!--external css -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jasny-bootstrap/3.1.3/js/jasny-bootstrap.min.js"></script>
<link rel="stylesheet" href="">
<style>
.pass_show{position: relative} 
.pass_show .ptxt { 
position: absolute; 
top: 40%; 
right: 10px; 
z-index: 1; 
color: rgba(0, 0, 0, .9); 
margin-top: -5px; 
cursor: pointer; 
transition: .3s ease all; 
} 
.pass_show .ptxt:hover{color: #333333;} 

.login-form {
    width: 434px;
    background-color: rgba(0, 0, 0, 0.33);
    display: block;
    position: absolute;
    top: 54%;
    left: 50%;
    transform: translateX(-50%) translateY(-50%);
    padding: 25px 30px;
    /* text-align: center; */
}
</style>
<script>
$(document).ready(function(){
$('.pass_show').append('<span class="ptxt">Show</span>');  
});
$(document).on('click','.pass_show .ptxt', function(){ 
$(this).text($(this).text() == "Show" ? "Hide" : "Show"); 
$(this).prev().attr('type', function(index, attr){return attr == 'password' ? 'text' : 'password'; }); 

});  
</script>


</head>
<body>
<div id="header" class="site-header">
    <nav class="navbar navbar-expand-lg my-2 my-md-0 mr-md-3">
      <a class="navbar-brand"><img src="<?php echo base_url();?>/assets/img/logo-white.svg"></a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
    </button>
    
      <div class="collapse navbar-collapse" id="navbarNav">
        
      </div>
    </nav>
</div>

<div id="content" class="login-background" >
<img src="<?php echo base_url();?>/assets/img/iqos3.jpg" class="img-fluid" alt="Responsive image" />
<?php 

if($flag==1001)
{?>

<form  action="<?php echo base_url();?>index.php/User_reg/password_update" method="post">
<div id="login" class="login-form">
<h3 class="gold-underline">Reset Password</h3>
	<div class="row">
		<div class="col-sm-8">
		    <?php 
	  if(!empty($alert_message))
			{ echo $alert_message; 
							}
							
						?>
		    <label>Current Password</label>
		    <div class="form-group pass_show">
                  <input type="hidden" id="token" name="token" value="<?php echo $token;?>">
                  <input type="hidden" id="user_id" name="user_id" value="<?php echo $user_id;?>">

				  
                <input type="password" value="" class="form-control" name="current_pwd" required> 
            </div> 
		       <label>New Password</label>
            <div class="form-group pass_show"> 
                <input type="password" value="" class="form-control" name="new_pwd" required>
            </div> 
		       <label>Confirm Password</label>
            <div class="form-group pass_show"> 
                <input type="password" value="" class="form-control" name="confrm_pwd" required> 
            </div> 
            
		</div> 
      	
	</div>
	<button type="submit" class="btn btn-primary">Submit</button>	
</div>
</form>
<?php } else{?>


<div class="container">
	<div class="row">
		<div class="col-sm-4">
		    
		 Enter Mail is Not Valid 
        
		 <form action="http://purpuligo.com/booya">
         <button type="submit" class="btn btn-primary"> Click me</button>
         </form> 
		</div> 
     </div>
</div>
<?php }?>
<footer>
  <div id="copyright">
    © 2020. Powered By iqos
  </div>
</footer>
</body>

</html>

</div>